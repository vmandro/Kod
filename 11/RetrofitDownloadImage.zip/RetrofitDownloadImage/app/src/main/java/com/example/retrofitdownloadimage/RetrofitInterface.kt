package com.example.retrofitdownloadimage

import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query
//import retrofit2.http.Streaming
import retrofit2.http.Url


interface RetrofitInterface {
    //@Streaming
    @GET
    fun getImage(@Url url: String): Call<ResponseBody?>

    @GET
    fun getStaticMap(@Url url: String,
                     @Query("center") lstlng : String,
                     @Query("zoom") zoom : String,
                     @Query("size") size : String,
                     @Query("markers") markers : String,
                     @Query("key") key : String): Call<ResponseBody?>

}
