package com.example.retrofitdownloadimage

import android.R
import android.app.IntentService
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Environment
import android.util.Log
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import okhttp3.OkHttpClient
import okhttp3.ResponseBody
import retrofit2.Retrofit
import retrofit2.http.Query
import java.io.*


@Suppress("DEPRECATION")
class BackgroundNotificationService : IntentService("Service") {
    private lateinit var notificationBuilder: NotificationCompat.Builder
    private lateinit var notificationManager: NotificationManager

    @Deprecated("Deprecated in Java")
    override fun onHandleIntent(intent: Intent?) {
        Log.d("TAG", "onHandleIntent")
        val smap = intent?.getBooleanExtra("SMAP", false)?:false
        notificationManager =
            getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationChannel =
                NotificationChannel("id", "an", NotificationManager.IMPORTANCE_LOW)
            notificationChannel.description = "no sound"
            notificationChannel.setSound(null, null)
            notificationChannel.enableLights(false)
            notificationChannel.lightColor = Color.BLUE
            notificationChannel.enableVibration(false)
            notificationManager.createNotificationChannel(notificationChannel)
        }
        notificationBuilder = NotificationCompat.Builder(this, "id")
            .setSmallIcon(R.drawable.stat_sys_download)
            .setContentTitle("Download")
            .setContentText("Downloading Image")
            .setDefaults(0)
            .setAutoCancel(true)
        notificationManager.notify(0, notificationBuilder.build())
        initRetrofit(smap)
    }

    private fun initRetrofit(smap : Boolean) {
        val client =
            OkHttpClient
            .Builder()
            .addInterceptor(BasicAuthInterceptor("java", "vaja"))
            .build()
        val retrofit =
            Retrofit
            .Builder()
            .baseUrl(if (!smap)"https://dai.fmph.uniba.sk/courses/VMA/"
                     else "http://maps.google.com/")
            .client(client)
            .build()
        val retrofitInterface = retrofit.create(RetrofitInterface::class.java)
        val request =
            //retrofitInterface.getImage("ISLAND2.JPG")
            //retrofitInterface.getImage("vlajky/svk.png")
            if (!smap) {
                Log.d("TAG", "START DOWNLOAD PICT")
                retrofitInterface.getImage("android/03Http/KOZA.JPG")
            } else {
                Log.d("TAG", "START DOWNLOAD MAP")
                retrofitInterface.getStaticMap(
                    "maps/api/staticmap",
                    "48.160020,17.075810",
                    "13",
                    "480x480",
                    "48.160020,17.075810",
                    "AIzaSyCUU53EADiCbbSzFreLbD_FzEeYuihYGL8"
                )
            }

////////////////////////////////////////////////////////////////////
//        httpParams.add(BasicNameValuePair("center", latlngString))
//        httpParams.add(BasicNameValuePair("zoom", "15"))
//        httpParams.add(BasicNameValuePair("size", "480x480"))
//        httpParams.add(BasicNameValuePair("markers", latlngString))
//        httpParams.add(BasicNameValuePair("key", "AIzaS******YGL8"))
        try {
            val body: ResponseBody? = request.execute().body()
            downloadImage(body)
        } catch (e: IOException) {
            e.printStackTrace()
            Toast.makeText(applicationContext, e.message, Toast.LENGTH_SHORT).show()
        }
    }

    private fun downloadImage(body: ResponseBody?) {
        var count = 0
        val data = ByteArray(1024 * 4)
        val fileSize = body?.contentLength()
        val inputStream = BufferedInputStream(body?.byteStream(), 1024 * 8)
        val outputFile = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "downloaded.jpg")
        val outputStream = FileOutputStream(outputFile)
        var total = 0L
        var downloadComplete = false
        while (inputStream.read(data).also({ count = it }) != -1) {
            total += count.toLong()
            val progress = ((total * 100).toDouble() / (fileSize?:100).toDouble()).toInt()
            updateNotification(progress)
            outputStream.write(data, 0, count)
            downloadComplete = true
            Log.d("TAG", "DOWNLOADED")
        }
        onDownloadComplete(downloadComplete)
        outputStream.flush()
        outputStream.close()
        inputStream.close()
    }

    private fun updateNotification(currentProgress: Int) {
        notificationBuilder.setProgress(100, currentProgress, false)
        notificationBuilder.setContentText("Downloaded: $currentProgress%")
        notificationManager.notify(0, notificationBuilder.build())
    }

    private fun sendProgressUpdate(downloadComplete: Boolean) {
        val intent = Intent("progress_update") //
        // MainActivity.PROGRESS_UPDATE)
        intent.putExtra("downloadComplete", downloadComplete)
        LocalBroadcastManager.getInstance(this@BackgroundNotificationService).sendBroadcast(intent)
    }

    private fun onDownloadComplete(downloadComplete: Boolean) {
        sendProgressUpdate(downloadComplete)
        notificationManager.cancel(0)
        notificationBuilder.setProgress(0, 0, false)
        notificationBuilder.setContentText("Image Download Complete")
        notificationManager.notify(0, notificationBuilder.build())
    }

    override fun onTaskRemoved(rootIntent: Intent) {
        notificationManager.cancel(0)
    }
}