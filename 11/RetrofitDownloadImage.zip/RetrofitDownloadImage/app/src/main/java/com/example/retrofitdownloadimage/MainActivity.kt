package com.example.retrofitdownloadimage

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.example.retrofitdownloadimage.databinding.ActivityMainBinding
import com.squareup.picasso.Picasso
import java.io.File


class MainActivity : AppCompatActivity() {
    companion object {  // static
      val PROGRESS_UPDATE = "progress_update"
    }
    private val PERMISSION_REQUEST_CODE = 777
    private lateinit var binding : ActivityMainBinding
    fun onClick(v: View) {
        val intent = Intent(this, BackgroundNotificationService::class.java)
        stopService(intent)
        if (checkPermission()) {
            startImageDownload(v == binding.downloadMapBtn)
        } else {
            requestPermission();
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.downloadImgBtn.setOnClickListener { v->onClick(v)}
        binding.downloadMapBtn.setOnClickListener { v->onClick(v)}
        registerReceiver();
    }
    //https://rohitksingh.medium.com/how-to-write-localbroadcastmanager-in-android-fa301efda00f
    private fun registerReceiver() {
        val bManager: LocalBroadcastManager = LocalBroadcastManager.getInstance(this)
        val intentFilter = IntentFilter()
        intentFilter.addAction(PROGRESS_UPDATE)
        bManager.registerReceiver(mBroadcastReceiver, intentFilter)
    }

    private val mBroadcastReceiver: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent) {
            if (intent.action == PROGRESS_UPDATE) {
                val downloadComplete =
                    intent.getBooleanExtra("downloadComplete", false)
                if (downloadComplete) {
                    Toast.makeText(
                        applicationContext,
                        "File download completed",
                        Toast.LENGTH_SHORT
                    ).show()
                    val file = File(
                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                            .getPath() + File.separator.toString() +
                                "downloaded.jpg"
                    )
                    Log.d("TAG", "Picasso: image file to ImageView ")
                    Picasso.get().load(file).into(binding.imgView)
                }
            }
        }
    }

    private fun checkPermission(): Boolean {
        val result = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        )
        return result == PackageManager.PERMISSION_GRANTED
    }

    private fun startImageDownload(smap : Boolean) {
        val intent = Intent(this, BackgroundNotificationService::class.java)
        intent.putExtra("SMAP", smap)
        Log.d("TAG", "STARTING SERVICE")
        startService(intent)
    }

    private fun requestPermission() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE,
               // Manifest.permission.POST_NOTIFICATIONS
            ),
            PERMISSION_REQUEST_CODE
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String?>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            PERMISSION_REQUEST_CODE -> if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startImageDownload(false)
            } else {
                Toast.makeText(applicationContext, "Permission Denied", Toast.LENGTH_SHORT)
                    .show()
            }
        }
    }
}