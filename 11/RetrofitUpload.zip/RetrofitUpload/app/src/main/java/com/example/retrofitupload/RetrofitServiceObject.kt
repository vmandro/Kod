package com.example.retrofitupload

import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST
import retrofit2.http.Query

// https://stackoverflow.com/questions/30701336/retrofit-image-upload-using-base64-in-android/31782409
interface RetrofitInterface {
    @FormUrlEncoded
    @POST("galeria/upload.php")
    suspend fun post(@Query("iname") iname: String, @Field("image") image: String)

}

val okHttpClientInterceptor: OkHttpClient = OkHttpClient.Builder()
    .addInterceptor(BasicAuthInterceptor("java", "vaja"))
    .build()

object RetrofitServiceObject {
    private val BASE_URL = "https://dai.fmph.uniba.sk/courses/VMA/"

    fun post(): RetrofitInterface {
        return Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .client(okHttpClientInterceptor)
            .build()
            .create(RetrofitInterface::class.java)
    }

}
