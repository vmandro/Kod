package com.example.retrofitupload



import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.BitmapDrawable
import android.location.Location
import android.location.LocationManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.*
import com.google.android.gms.maps.model.LatLng
import java.io.ByteArrayOutputStream
import java.util.*
import android.graphics.Bitmap
import android.util.Base64
import com.example.retrofitupload.databinding.ActivityMainBinding
import kotlinx.coroutines.*



private var bmp: Bitmap? = null

class MainActivity : AppCompatActivity() {
    private val REQUEST_PICK_PHOTO = 100
    private lateinit var binding: ActivityMainBinding
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private val interval = 1000
    private val fastestInterval = 1000L
    private lateinit var locationRequest: LocationRequest
    private var lastLocation: Location? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        checkPermissions()
        checkProvider()

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        locationRequest = LocationRequest.create()
            .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
            .setInterval((interval).toLong())
            .setFastestInterval((fastestInterval))
    }

    override fun onPause() {
        super.onPause()
        fusedLocationClient.removeLocationUpdates(locationCallback)
    }

    override fun onResume() {
        super.onResume()
        startLocationUpdates()
    }

    private val locationCallback = object : LocationCallback() {
        override fun onLocationResult(locationResult: LocationResult) {
            lastLocation = locationResult.lastLocation!!
        }
    }

    @SuppressLint("MissingPermission")
    private fun startLocationUpdates() {
        fusedLocationClient.requestLocationUpdates(
            locationRequest,
            locationCallback,
            Looper.getMainLooper())
    }

    private fun checkPermissions() {
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(
                    this@MainActivity,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    ),
                    0
                )
            }
        }
    }

    private fun checkProvider() {
        val locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            AlertDialog.Builder(this)
                .setMessage("Your GPS seems to be disabled, do you want to enable it?")
                .setPositiveButton("Yes") { _, _ ->
                    startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                }
                .setNegativeButton("No") { dialog, _ -> dialog.cancel() }
                .create()
                .show()
        }
    }

    fun choosePhoto(v: View) {
        val galleryIntent = Intent(
            Intent.ACTION_PICK,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        )
        startActivityForResult(galleryIntent, REQUEST_PICK_PHOTO)
    }

    // https://handyopinion.com/pick-image-from-gallery-in-kotlin-android/
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_PICK_PHOTO && resultCode == RESULT_OK) {
            binding.imageView.setImageURI(data?.data)
            bmp = (binding.imageView.drawable as BitmapDrawable).bitmap
        }
    }

    // metoda kontroluje, ci je vybrany obrazok a ci su vsetky polia vyplnene
    private fun checkNecessary(filename: String, watermark: String): Boolean {
        if (bmp == null) {
            Toast.makeText(this, "You didn't choose any image!",
                Toast.LENGTH_LONG).show()
            return false
        }

        if (filename.isEmpty()) {
            Toast.makeText(this, "You didn't set filename!",
                Toast.LENGTH_LONG).show()
            return false
        }

        if (watermark.isEmpty()) {
            Toast.makeText(this, "You didn't set any watermark!",
                Toast.LENGTH_LONG).show()
            return false
        }
        return true
    }


    fun drawTextOnBitmap(v: View) {
        val watermark = binding.watermarkInput.editText?.text.toString()
        val filename = binding.filenameInput.editText?.text.toString()
        val latLngTxt = if (lastLocation != null) {
            "${"%.3f".format(lastLocation!!.latitude)},  " +
                    "%.3f".format(lastLocation!!.longitude)
            } else "..."

        if (!checkNecessary(filename, watermark)) {
            return
        }
        // ako kreslit do obrazka:
        // https://android--code.blogspot.com/2020/06/android-kotlin-draw-text-on-bitmap.html
        bmp = bmp!!.copy(bmp!!.config, true)
        val canvas = Canvas(bmp!!)

        Paint().apply {
            flags = Paint.ANTI_ALIAS_FLAG
            this.color = Color.WHITE
            this.textSize = (canvas.width / 10).toFloat()
            typeface = Typeface.SERIF
            setShadowLayer(1f, 0f, 1f, Color.WHITE)
            val marginBottom = -50
            val marginTop = 60
            // vypise do obrazka latitude, longitude
            // treba odkomentovat ak chceme vidiet aj latitude, longitude:
            canvas.drawText(latLngTxt, (canvas.width / 10).toFloat(), marginBottom +
                    canvas.height.toFloat(), this)

            // vypise do obrazka vlastny text
            canvas.drawText(watermark, (canvas.width / 10).toFloat(),
                marginTop + (canvas.height / 10).toFloat(), this)
        }
        binding.imageView.setImageBitmap(bmp)
        postPhoto(filename)
    }

    fun postPhoto(filename: String) {
        // encoding https://stackoverflow.com/questions/39199520/bitmap-to-base64-string
        val byteArrayOutputStream = ByteArrayOutputStream()
        bmp!!.compress(Bitmap.CompressFormat.JPEG, 90, byteArrayOutputStream)
        val encodedPhoto: String = Base64.encodeToString(byteArrayOutputStream.toByteArray(),
            Base64.DEFAULT)
        val service = RetrofitServiceObject
        CoroutineScope(Dispatchers.IO).launch {
            service.post().post(filename, encodedPhoto)
            withContext(Dispatchers.Main) {
                binding.watermarkInput.editText?.text?.clear()
                binding.filenameInput.editText?.text?.clear()
                makeToast()
            }
        }
    }

    // funkcia volana z coroutiny
    private fun makeToast() {
        Toast.makeText(this, "Picture was successfully sent!",
            Toast.LENGTH_LONG).show()

    }
}

