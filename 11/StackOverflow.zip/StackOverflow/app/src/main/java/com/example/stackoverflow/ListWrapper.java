package com.example.stackoverflow;

import java.util.List;

public class ListWrapper<T> {
    List<T> items;
}