package com.example.gmap
/**
 * @author Rudyi Heorhii, 2023
 */

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.gmap.ui.theme.GmapTheme
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.rememberCameraPositionState
import retrofit2.Retrofit
import kotlinx.coroutines.launch
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.graphics.Color
import com.google.maps.android.PolyUtil
import com.google.maps.android.compose.Polyline
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : ComponentActivity() {

    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient
    private lateinit var requestPermissionLauncher: ActivityResultLauncher<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)
        requestPermissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { granted ->
            if (granted) {
                //
                getLastLocation()
            } else {
                //
            }
        }
        checkLocPermission()
    }

    private fun checkLocPermission() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
            &&
            ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        } else {
            getLastLocation()
        }
    }

    private fun getLastLocation() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        fusedLocationProviderClient.lastLocation.addOnSuccessListener { location: Location? ->
            location?.let {
                updateMapForLocation(it)
            }
        }
    }

    private fun updateMapForLocation(location: Location) {
        val currentLocation = LatLng(location.latitude, location.longitude)

        setContent {
            GmapTheme {
                MapView(this::updateMapForLocation, this::checkLocPermission)
            }
        }
    }
}

@SuppressLint("MissingPermission")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapView(upLoc: (Location) -> Unit, checkPermLoc: () -> Unit) {
    var searchText by remember { mutableStateOf("") }
    var targetLocation by remember { mutableStateOf(LatLng(0.0, 0.0)) }
    var currentLocation by remember { mutableStateOf(LatLng(0.0, 0.0)) }
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(currentLocation, 12f)
    }
    val viewModel: MainViewModel = viewModel()
    val context = LocalContext.current
    val routePoints by viewModel.routePoints.observeAsState(emptyList())

    val distText by viewModel.distToTarget.observeAsState("")
    val timeText by viewModel.timeToTarget.observeAsState("")

    LaunchedEffect(targetLocation, currentLocation) {
        when {
            targetLocation != LatLng(0.0, 0.0) -> cameraPositionState.position = CameraPosition.fromLatLngZoom(targetLocation, 12f)
            currentLocation != LatLng(0.0, 0.0) -> cameraPositionState.position = CameraPosition.fromLatLngZoom(currentLocation, 12f)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        GoogleMap(
            modifier = Modifier.matchParentSize(),
            cameraPositionState = cameraPositionState
        ) {
            val currentLocationMarkerState = remember(key1 = currentLocation) { MarkerState(position = currentLocation) }
            if (currentLocation != LatLng(0.0, 0.0)) {
                Marker(
                    state = currentLocationMarkerState,
                    title = "Current Location",
                    icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE)
                )
            }

            val targetLocationMarkerState = remember(key1 = targetLocation) { MarkerState(position = targetLocation) }
            if (targetLocation != LatLng(0.0, 0.0)) {
                Marker(
                    state = targetLocationMarkerState,
                    title = "Target Location",
                    icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)
                )
            }

            if (routePoints.isNotEmpty()) {
                Polyline(
                    points = routePoints,
                    color = Color.Blue,
                    width = 5f
                )
            }
        }

        Column {
            OutlinedTextField(
                value = searchText,
                onValueChange = { searchText = it },
                label = { Text("Input coordinate")},
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(4.dp)
                    .height(56.dp)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Button(onClick = {
                val coordinates = searchText.split(" ").map { it.toDoubleOrNull() }
                if (coordinates.size == 2 && coordinates.all { it != null }) {
                    targetLocation = LatLng(coordinates[0]!!, coordinates[1]!!)
                    val apiKey = "AIzaSyAxOzAo6fSggSbaaNgLBYjAcvZZ40GOX0c"
                    viewModel.requestRoute(currentLocation, targetLocation, apiKey)
                } else {
                    //
                }
            }, modifier = Modifier.padding(10.dp)) {
                Text("Search")
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text("Distance to target: $distText")
            Text("Time: $timeText")
        }

        FloatingActionButton(
            onClick = {
                checkPermLoc()
                LocationServices.getFusedLocationProviderClient(context).lastLocation.addOnSuccessListener {
                        location: Location? -> location?.let {
                    currentLocation = LatLng(it.latitude, it.longitude)
                    cameraPositionState.position = CameraPosition.fromLatLngZoom(currentLocation, 12f)
                    upLoc(it)
                }
                }
            },
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp)
        ) {
            Icon(Icons.Default.LocationOn, contentDescription = "Current location")
        }
    }
}


class MainViewModel: ViewModel() {
    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY))
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl("https://maps.googleapis.com/")
        .addConverterFactory(GsonConverterFactory.create()).
            client(okHttpClient)
        .build()

    private val directionsApiService = retrofit.create(DirectionsApiService::class.java)

    private val _routePoints = MutableLiveData<List<LatLng>>()
    val routePoints: LiveData<List<LatLng>> = _routePoints

    val distToTarget = MutableLiveData<String>()
    val timeToTarget = MutableLiveData<String>()

    fun requestRoute(origin: LatLng, destination: LatLng, apiKey: String) {
        viewModelScope.launch {
            val response = directionsApiService.getDirections(
                origin = "${origin.latitude},${origin.longitude}",
                destination = "${destination.latitude},${destination.longitude}",
                apiKey = apiKey
            )
            if (response.isSuccessful) {
                val jsonResponse = response.body()?.toString()
                Log.d("DirectionsApi", "Response: $jsonResponse")
                response.body()?.let { directionsResponse ->
                    if (directionsResponse.routes.isNotEmpty()) {
                        val route = directionsResponse.routes.first()
                        val leg = route.legs.firstOrNull()
                        distToTarget.value = leg?.distance?.text ?: "I cant find distance"
                        timeToTarget.value = leg?.duration?.text ?: "Time unknown"
                        val decodedPath = PolyUtil.decode(directionsResponse.routes[0].overview_polyline.points)
                        _routePoints.value = decodedPath
                    }
                }
            } else {
                //
            }
        }
    }
}




