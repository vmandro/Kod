package com.example.gmap
/**
 * @author Rudyi Heorhii, 2023
 */
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface DirectionsApiService {
    @GET("https://maps.googleapis.com/maps/api/directions/json")
    suspend fun getDirections(
        @Query("origin") origin: String,
        @Query("destination") destination: String,
        @Query("key") apiKey: String,
        @Query("mode") mode: String = "walking"
    ): Response<DirectionsResponse>
}

data class DirectionsResponse(
    val routes: List<Route>
)

data class Route(
    val legs: List<Leg>,
    val overview_polyline: OverviewPolyline
)

data class Leg(
    val steps: List<Step>,
    val distance: Distance,
    val duration: Duration
)

data class Step(
    val start_location: Location,
    val end_location: Location,
    val polyline: Polyline
)

data class Location(
    val lat: Double,
    val lng: Double
)

data class Polyline(
    val points: String
)

data class OverviewPolyline(
    val points: String
)

data class Distance(val text: String, val value: Int)
data class Duration(val text: String, val value: Int)