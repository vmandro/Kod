package com.example.httpaoc.json


import com.google.gson.annotations.SerializedName

data class X541831(
    @SerializedName("completion_day_level")
    val completionDayLevel: CompletionDayLevelXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX,
    @SerializedName("global_score")
    val globalScore: Int,
    val id: String,
    @SerializedName("last_star_ts")
    val lastStarTs: Int,
    @SerializedName("local_score")
    val localScore: Int,
    val name: String,
    val stars: Int
)