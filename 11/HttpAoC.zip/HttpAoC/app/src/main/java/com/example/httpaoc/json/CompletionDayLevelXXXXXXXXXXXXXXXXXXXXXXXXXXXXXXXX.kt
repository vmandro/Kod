package com.example.httpaoc.json


import com.google.gson.annotations.SerializedName

class CompletionDayLevelXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX(
)