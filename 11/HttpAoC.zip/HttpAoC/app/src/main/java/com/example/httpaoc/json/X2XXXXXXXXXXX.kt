package com.example.httpaoc.json


import com.google.gson.annotations.SerializedName

data class X2XXXXXXXXXXX(
    @SerializedName("get_star_ts")
    val getStarTs: String
)