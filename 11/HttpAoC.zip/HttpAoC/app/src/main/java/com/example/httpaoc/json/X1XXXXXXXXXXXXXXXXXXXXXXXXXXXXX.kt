package com.example.httpaoc.json


import com.google.gson.annotations.SerializedName

data class X1XXXXXXXXXXXXXXXXXXXXXXXXXXXXX(
    @SerializedName("1")
    val x1: X1XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX,
    @SerializedName("2")
    val x2: X2XXXXXXXXXXXXXXXXXXXXXXXXXXXXX
)