package com.example.httpaoc.json


import com.google.gson.annotations.SerializedName

data class Members(
    @SerializedName("133724")
    val x133724: X133724,
    @SerializedName("14597")
    val x14597: X14597,
    @SerializedName("205219")
    val x205219: X205219,
    @SerializedName("229344")
    val x229344: X229344,
    @SerializedName("230440")
    val x230440: X230440,
    @SerializedName("241618")
    val x241618: X241618,
    @SerializedName("253915")
    val x253915: X253915,
    @SerializedName("257369")
    val x257369: X257369,
    @SerializedName("284148")
    val x284148: X284148,
    @SerializedName("289473")
    val x289473: X289473,
    @SerializedName("289854")
    val x289854: X289854,
    @SerializedName("340516")
    val x340516: X340516,
    @SerializedName("357988")
    val x357988: X357988,
    @SerializedName("374071")
    val x374071: X374071,
    @SerializedName("381890")
    val x381890: X381890,
    @SerializedName("382474")
    val x382474: X382474,
    @SerializedName("382973")
    val x382973: X382973,
    @SerializedName("383500")
    val x383500: X383500,
    @SerializedName("387446")
    val x387446: X387446,
    @SerializedName("387557")
    val x387557: X387557,
    @SerializedName("387689")
    val x387689: X387689,
    @SerializedName("394723")
    val x394723: X394723,
    @SerializedName("398095")
    val x398095: X398095,
    @SerializedName("406017")
    val x406017: X406017,
    @SerializedName("413457")
    val x413457: X413457,
    @SerializedName("414606")
    val x414606: X414606,
    @SerializedName("425420")
    val x425420: X425420,
    @SerializedName("432600")
    val x432600: X432600,
    @SerializedName("440518")
    val x440518: X440518,
    @SerializedName("440747")
    val x440747: X440747,
    @SerializedName("442294")
    val x442294: X442294,
    @SerializedName("452327")
    val x452327: X452327,
    @SerializedName("49729")
    val x49729: X49729,
    @SerializedName("50608")
    val x50608: X50608,
    @SerializedName("541831")
    val x541831: X541831,
    @SerializedName("633816")
    val x633816: X633816,
    @SerializedName("633833")
    val x633833: X633833,
    @SerializedName("633850")
    val x633850: X633850,
    @SerializedName("635829")
    val x635829: X635829,
    @SerializedName("644573")
    val x644573: X644573,
    @SerializedName("668371")
    val x668371: X668371,
    @SerializedName("677144")
    val x677144: X677144,
    @SerializedName("727545")
    val x727545: X727545
)