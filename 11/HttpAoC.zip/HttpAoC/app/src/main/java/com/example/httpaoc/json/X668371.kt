package com.example.httpaoc.json


import com.google.gson.annotations.SerializedName

data class X668371(
    @SerializedName("completion_day_level")
    val completionDayLevel: CompletionDayLevelXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX,
    @SerializedName("global_score")
    val globalScore: Int,
    val id: String,
    @SerializedName("last_star_ts")
    val lastStarTs: String,
    @SerializedName("local_score")
    val localScore: Int,
    val name: String,
    val stars: Int
)