package com.example.httpaoc.json


import com.google.gson.annotations.SerializedName

data class X1XXX(
    @SerializedName("1")
    val x1: X1XXXX,
    @SerializedName("2")
    val x2: X2XXX
)