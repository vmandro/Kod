package com.example.httpaoc.json


import com.google.gson.annotations.SerializedName

data class CompletionDayLevelXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX(
    @SerializedName("1")
    val x1: X1XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
)