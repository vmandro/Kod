package com.example.httpaoc.json


import com.google.gson.annotations.SerializedName

data class CompletionDayLevelXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX(
    @SerializedName("1")
    val x1: X1XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX,
    @SerializedName("2")
    val x2: X2XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX,
    @SerializedName("3")
    val x3: X3XXXXXXXXXXXXX
)