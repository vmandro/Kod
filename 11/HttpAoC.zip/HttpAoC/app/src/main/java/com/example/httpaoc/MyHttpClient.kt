package com.example.httpaoc

import android.app.Activity
import android.app.ProgressDialog
import android.os.AsyncTask
import android.os.Bundle
import android.util.JsonReader
import android.util.Log
import com.google.gson.GsonBuilder
import org.apache.http.client.methods.HttpGet
import org.apache.http.client.protocol.ClientContext
import org.apache.http.impl.client.BasicCookieStore
import org.apache.http.impl.client.DefaultHttpClient
import org.apache.http.impl.cookie.BasicClientCookie
import org.apache.http.protocol.BasicHttpContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.StringReader
import com.example.httpaoc.json.*
import java.text.SimpleDateFormat
import java.util.*

class MyHttpClient : Activity() {
    lateinit var pd: ProgressDialog
    val TAG = "AoC"
    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_http_client)
        Log.d(TAG, "start")
        //HttpGetAsyncPostGetCookies()
        val result =
                "{\"owner_id\":\"229344\",\"members\":{\"633850\":{\"stars\":2,\"id\":\"633850\",\"completion_day_level\":{\"1\":{\"1\":{\"get_star_ts\":\"1575177325\"},\"2\":{\"get_star_ts\":\"1575232476\"}}},\"local_score\":64,\"name\":null,\"last_star_ts\":\"1575232476\",\"global_score\":0},\"50608\":{\"id\":\"50608\",\"completion_day_level\":{\"2\":{\"1\":{\"get_star_ts\":\"1575323440\"},\"2\":{\"get_star_ts\":\"1575324582\"}},\"1\":{\"2\":{\"get_star_ts\":\"1575234400\"},\"1\":{\"get_star_ts\":\"1575233779\"}}},\"local_score\":99,\"name\":null,\"last_star_ts\":\"1575324582\",\"global_score\":0,\"stars\":4},\"387689\":{\"completion_day_level\":{},\"id\":\"387689\",\"last_star_ts\":0,\"global_score\":0,\"name\":\"beowulf11\",\"local_score\":0,\"stars\":0},\"284148\":{\"local_score\":116,\"name\":\"Jana Lachova\",\"last_star_ts\":\"1575317389\",\"global_score\":0,\"id\":\"284148\",\"completion_day_level\":{\"1\":{\"1\":{\"get_star_ts\":\"1575190775\"},\"2\":{\"get_star_ts\":\"1575191559\"}},\"2\":{\"1\":{\"get_star_ts\":\"1575316384\"},\"2\":{\"get_star_ts\":\"1575317389\"}}},\"stars\":4},\"289473\":{\"stars\":0,\"completion_day_level\":{},\"id\":\"289473\",\"global_score\":0,\"last_star_ts\":0,\"name\":\"Michal Vido\",\"local_score\":0},\"381890\":{\"completion_day_level\":{},\"id\":\"381890\",\"last_star_ts\":0,\"name\":\"Ján Kľuka\",\"global_score\":0,\"local_score\":0,\"stars\":0},\"133669\":{\"stars\":6,\"local_score\":160,\"last_star_ts\":\"1575400260\",\"global_score\":0,\"name\":\"Zoltan Onody\",\"id\":\"133669\",\"completion_day_level\":{\"2\":{\"2\":{\"get_star_ts\":\"1575333802\"},\"1\":{\"get_star_ts\":\"1575331323\"}},\"1\":{\"1\":{\"get_star_ts\":\"1575202384\"},\"2\":{\"get_star_ts\":\"1575204753\"}},\"3\":{\"1\":{\"get_star_ts\":\"1575394347\"},\"2\":{\"get_star_ts\":\"1575400260\"}}}},\"440747\":{\"name\":\"Ivan Martynovskyi\",\"last_star_ts\":\"1575401728\",\"global_score\":0,\"local_score\":177,\"completion_day_level\":{\"2\":{\"2\":{\"get_star_ts\":\"1575310108\"},\"1\":{\"get_star_ts\":\"1575308668\"}},\"1\":{\"2\":{\"get_star_ts\":\"1575188229\"},\"1\":{\"get_star_ts\":\"1575187596\"}},\"3\":{\"2\":{\"get_star_ts\":\"1575401728\"},\"1\":{\"get_star_ts\":\"1575400101\"}}},\"id\":\"440747\",\"stars\":6},\"374071\":{\"stars\":6,\"id\":\"374071\",\"completion_day_level\":{\"3\":{\"2\":{\"get_star_ts\":\"1575376678\"},\"1\":{\"get_star_ts\":\"1575375301\"}},\"1\":{\"2\":{\"get_star_ts\":\"1575185453\"},\"1\":{\"get_star_ts\":\"1575184775\"}},\"2\":{\"2\":{\"get_star_ts\":\"1575271779\"},\"1\":{\"get_star_ts\":\"1575271476\"}}},\"local_score\":202,\"global_score\":0,\"last_star_ts\":\"1575376678\",\"name\":\"Gyorgy Tomcsanyi\"},\"635829\":{\"completion_day_level\":{\"3\":{\"1\":{\"get_star_ts\":\"1575350543\"},\"2\":{\"get_star_ts\":\"1575350619\"}},\"1\":{\"2\":{\"get_star_ts\":\"1575176838\"},\"1\":{\"get_star_ts\":\"1575176482\"}},\"2\":{\"2\":{\"get_star_ts\":\"1575265176\"},\"1\":{\"get_star_ts\":\"1575265098\"}}},\"id\":\"635829\",\"name\":\"Jozef Kubík\",\"last_star_ts\":\"1575350619\",\"global_score\":15,\"local_score\":246,\"stars\":6},\"425420\":{\"stars\":6,\"name\":\"Peter Gergeľ\",\"last_star_ts\":\"1575359599\",\"global_score\":0,\"local_score\":210,\"completion_day_level\":{\"3\":{\"2\":{\"get_star_ts\":\"1575359599\"},\"1\":{\"get_star_ts\":\"1575358938\"}},\"2\":{\"1\":{\"get_star_ts\":\"1575274108\"},\"2\":{\"get_star_ts\":\"1575274499\"}},\"1\":{\"1\":{\"get_star_ts\":\"1575184467\"},\"2\":{\"get_star_ts\":\"1575184888\"}}},\"id\":\"425420\"},\"383500\":{\"stars\":0,\"last_star_ts\":0,\"name\":\"OHUSAR\",\"global_score\":0,\"local_score\":0,\"completion_day_level\":{},\"id\":\"383500\"},\"432600\":{\"completion_day_level\":{},\"id\":\"432600\",\"last_star_ts\":0,\"name\":\"Maroš Malý\",\"global_score\":0,\"local_score\":0,\"stars\":0},\"205219\":{\"id\":\"205219\",\"completion_day_level\":{},\"local_score\":0,\"last_star_ts\":0,\"global_score\":0,\"name\":\"yoyko\",\"stars\":0},\"413457\":{\"stars\":0,\"name\":\"kkikus\",\"last_star_ts\":0,\"global_score\":0,\"local_score\":0,\"completion_day_level\":{},\"id\":\"413457\"},\"398095\":{\"last_star_ts\":0,\"name\":\"Samuel Wendl\",\"global_score\":0,\"local_score\":0,\"completion_day_level\":{},\"id\":\"398095\",\"stars\":0},\"387446\":{\"stars\":6,\"last_star_ts\":\"1575379220\",\"name\":\"F Kerak\",\"global_score\":0,\"local_score\":143,\"completion_day_level\":{\"2\":{\"2\":{\"get_star_ts\":\"1575376842\"},\"1\":{\"get_star_ts\":\"1575376511\"}},\"1\":{\"2\":{\"get_star_ts\":\"1575375755\"},\"1\":{\"get_star_ts\":\"1575375433\"}},\"3\":{\"1\":{\"get_star_ts\":\"1575378173\"},\"2\":{\"get_star_ts\":\"1575379220\"}}},\"id\":\"387446\"},\"382973\":{\"completion_day_level\":{},\"id\":\"382973\",\"last_star_ts\":0,\"name\":\"Boris Silný\",\"global_score\":0,\"local_score\":0,\"stars\":0},\"633816\":{\"stars\":6,\"completion_day_level\":{\"3\":{\"2\":{\"get_star_ts\":\"1575355116\"},\"1\":{\"get_star_ts\":\"1575353986\"}},\"2\":{\"1\":{\"get_star_ts\":\"1575264967\"},\"2\":{\"get_star_ts\":\"1575265404\"}},\"1\":{\"2\":{\"get_star_ts\":\"1575177501\"},\"1\":{\"get_star_ts\":\"1575177229\"}}},\"id\":\"633816\",\"last_star_ts\":\"1575355116\",\"global_score\":0,\"name\":null,\"local_score\":230},\"357988\":{\"last_star_ts\":\"1575384913\",\"name\":null,\"global_score\":0,\"local_score\":181,\"completion_day_level\":{\"1\":{\"2\":{\"get_star_ts\":\"1575192085\"},\"1\":{\"get_star_ts\":\"1575191610\"}},\"2\":{\"2\":{\"get_star_ts\":\"1575280368\"},\"1\":{\"get_star_ts\":\"1575279807\"}},\"3\":{\"2\":{\"get_star_ts\":\"1575384913\"},\"1\":{\"get_star_ts\":\"1575384157\"}}},\"id\":\"357988\",\"stars\":6},\"442294\":{\"stars\":0,\"local_score\":0,\"last_star_ts\":0,\"name\":\"mrkvost\",\"global_score\":0,\"id\":\"442294\",\"completion_day_level\":{}},\"257369\":{\"local_score\":0,\"last_star_ts\":0,\"global_score\":0,\"name\":\"Frantisek Drabecky\",\"id\":\"257369\",\"completion_day_level\":{},\"stars\":0},\"727545\":{\"completion_day_level\":{},\"id\":\"727545\",\"last_star_ts\":0,\"global_score\":0,\"name\":null,\"local_score\":0,\"stars\":0},\"406017\":{\"id\":\"406017\",\"completion_day_level\":{\"2\":{\"1\":{\"get_star_ts\":\"1575264301\"},\"2\":{\"get_star_ts\":\"1575264561\"}},\"1\":{\"1\":{\"get_star_ts\":\"1575176687\"},\"2\":{\"get_star_ts\":\"1575177031\"}},\"3\":{\"2\":{\"get_star_ts\":\"1575350314\"},\"1\":{\"get_star_ts\":\"1575349931\"}}},\"local_score\":249,\"global_score\":0,\"last_star_ts\":\"1575350314\",\"name\":\"Erik Szalay\",\"stars\":6},\"633833\":{\"stars\":0,\"id\":\"633833\",\"completion_day_level\":{},\"local_score\":0,\"global_score\":0,\"last_star_ts\":0,\"name\":null},\"49729\":{\"stars\":0,\"completion_day_level\":{},\"id\":\"49729\",\"name\":\"Seluwin\",\"last_star_ts\":0,\"global_score\":0,\"local_score\":0},\"452327\":{\"stars\":4,\"local_score\":89,\"global_score\":0,\"last_star_ts\":\"1575359071\",\"name\":\"Andrea Spišáková\",\"id\":\"452327\",\"completion_day_level\":{\"2\":{\"1\":{\"get_star_ts\":\"1575318972\"},\"2\":{\"get_star_ts\":\"1575359071\"}},\"1\":{\"2\":{\"get_star_ts\":\"1575316042\"},\"1\":{\"get_star_ts\":\"1575315442\"}}}},\"382474\":{\"completion_day_level\":{\"3\":{\"1\":{\"get_star_ts\":\"1575367655\"},\"2\":{\"get_star_ts\":\"1575380238\"}},\"2\":{\"1\":{\"get_star_ts\":\"1575296554\"},\"2\":{\"get_star_ts\":\"1575297391\"}},\"1\":{\"2\":{\"get_star_ts\":\"1575294741\"},\"1\":{\"get_star_ts\":\"1575290505\"}}},\"id\":\"382474\",\"last_star_ts\":\"1575380238\",\"global_score\":0,\"name\":\"linda Jurkasova\",\"local_score\":170,\"stars\":6},\"230440\":{\"local_score\":196,\"last_star_ts\":\"1575355079\",\"name\":\"Tomáš Bočinec\",\"global_score\":0,\"id\":\"230440\",\"completion_day_level\":{\"3\":{\"2\":{\"get_star_ts\":\"1575355079\"},\"1\":{\"get_star_ts\":\"1575355063\"}},\"1\":{\"1\":{\"get_star_ts\":\"1575222029\"},\"2\":{\"get_star_ts\":\"1575222656\"}},\"2\":{\"2\":{\"get_star_ts\":\"1575275021\"},\"1\":{\"get_star_ts\":\"1575274812\"}}},\"stars\":6},\"241618\":{\"id\":\"241618\",\"completion_day_level\":{\"2\":{\"1\":{\"get_star_ts\":\"1575272186\"},\"2\":{\"get_star_ts\":\"1575279106\"}},\"1\":{\"1\":{\"get_star_ts\":\"1575184259\"},\"2\":{\"get_star_ts\":\"1575184876\"}},\"3\":{\"1\":{\"get_star_ts\":\"1575369676\"},\"2\":{\"get_star_ts\":\"1575375683\"}}},\"local_score\":207,\"last_star_ts\":\"1575375683\",\"global_score\":0,\"name\":null,\"stars\":6},\"289854\":{\"last_star_ts\":\"1575375697\",\"global_score\":0,\"name\":\"Miki Hermann\",\"local_score\":206,\"completion_day_level\":{\"2\":{\"2\":{\"get_star_ts\":\"1575267648\"},\"1\":{\"get_star_ts\":\"1575265752\"}},\"1\":{\"2\":{\"get_star_ts\":\"1575185929\"},\"1\":{\"get_star_ts\":\"1575185448\"}},\"3\":{\"1\":{\"get_star_ts\":\"1575369838\"},\"2\":{\"get_star_ts\":\"1575375697\"}}},\"id\":\"289854\",\"stars\":6},\"677144\":{\"local_score\":196,\"last_star_ts\":\"1575367533\",\"name\":\"Vsetky Borufky\",\"global_score\":0,\"id\":\"677144\",\"completion_day_level\":{\"3\":{\"2\":{\"get_star_ts\":\"1575367533\"},\"1\":{\"get_star_ts\":\"1575357449\"}},\"1\":{\"2\":{\"get_star_ts\":\"1575241741\"},\"1\":{\"get_star_ts\":\"1575241062\"}},\"2\":{\"1\":{\"get_star_ts\":\"1575264300\"},\"2\":{\"get_star_ts\":\"1575267832\"}}},\"stars\":6},\"340516\":{\"stars\":6,\"id\":\"340516\",\"completion_day_level\":{\"3\":{\"1\":{\"get_star_ts\":\"1575351837\"},\"2\":{\"get_star_ts\":\"1575376586\"}},\"2\":{\"1\":{\"get_star_ts\":\"1575263547\"},\"2\":{\"get_star_ts\":\"1575263974\"}},\"1\":{\"2\":{\"get_star_ts\":\"1575182013\"},\"1\":{\"get_star_ts\":\"1575181806\"}}},\"local_score\":233,\"last_star_ts\":\"1575376586\",\"name\":\"Lukáš Gajdošech\",\"global_score\":0},\"440518\":{\"last_star_ts\":0,\"global_score\":0,\"name\":\"Marek Stachera\",\"local_score\":0,\"completion_day_level\":{},\"id\":\"440518\",\"stars\":0},\"394723\":{\"local_score\":0,\"last_star_ts\":0,\"global_score\":0,\"name\":null,\"id\":\"394723\",\"completion_day_level\":{},\"stars\":0},\"229344\":{\"stars\":6,\"id\":\"229344\",\"completion_day_level\":{\"3\":{\"2\":{\"get_star_ts\":\"1575351770\"},\"1\":{\"get_star_ts\":\"1575350735\"}},\"1\":{\"1\":{\"get_star_ts\":\"1575176691\"},\"2\":{\"get_star_ts\":\"1575177020\"}},\"2\":{\"2\":{\"get_star_ts\":\"1575264839\"},\"1\":{\"get_star_ts\":\"1575264081\"}}},\"local_score\":245,\"global_score\":0,\"last_star_ts\":\"1575351770\",\"name\":\"Peter BOROVANSKY\"},\"133724\":{\"stars\":4,\"local_score\":104,\"last_star_ts\":\"1575328931\",\"name\":\"Alexka Nyitraiová\",\"global_score\":0,\"id\":\"133724\",\"completion_day_level\":{\"1\":{\"1\":{\"get_star_ts\":\"1575210606\"},\"2\":{\"get_star_ts\":\"1575211974\"}},\"2\":{\"2\":{\"get_star_ts\":\"1575328931\"},\"1\":{\"get_star_ts\":\"1575327359\"}}}},\"644573\":{\"id\":\"644573\",\"completion_day_level\":{\"1\":{\"1\":{\"get_star_ts\":\"1575176824\"},\"2\":{\"get_star_ts\":\"1575177172\"}},\"2\":{\"1\":{\"get_star_ts\":\"1575263803\"},\"2\":{\"get_star_ts\":\"1575264338\"}},\"3\":{\"2\":{\"get_star_ts\":\"1575351620\"},\"1\":{\"get_star_ts\":\"1575351021\"}}},\"local_score\":245,\"last_star_ts\":\"1575351620\",\"name\":\"vidosuba\",\"global_score\":0,\"stars\":6},\"541831\":{\"id\":\"541831\",\"completion_day_level\":{},\"local_score\":0,\"global_score\":0,\"last_star_ts\":0,\"name\":\"Michal Knor\",\"stars\":0},\"253915\":{\"last_star_ts\":\"1575311956\",\"name\":\"Michal Winczer\",\"global_score\":0,\"local_score\":100,\"completion_day_level\":{\"2\":{\"2\":{\"get_star_ts\":\"1575311956\"},\"1\":{\"get_star_ts\":\"1575311450\"}},\"1\":{\"2\":{\"get_star_ts\":\"1575307940\"},\"1\":{\"get_star_ts\":\"1575307081\"}}},\"id\":\"253915\",\"stars\":4},\"387557\":{\"stars\":0,\"id\":\"387557\",\"completion_day_level\":{},\"local_score\":0,\"global_score\":0,\"last_star_ts\":0,\"name\":\"dobrakmato\"},\"414606\":{\"id\":\"414606\",\"completion_day_level\":{},\"local_score\":0,\"name\":null,\"last_star_ts\":0,\"global_score\":0,\"stars\":0},\"668371\":{\"last_star_ts\":\"1575318359\",\"name\":\"Matej Magat\",\"global_score\":0,\"local_score\":106,\"completion_day_level\":{\"2\":{\"1\":{\"get_star_ts\":\"1575315504\"},\"2\":{\"get_star_ts\":\"1575318359\"}},\"1\":{\"2\":{\"get_star_ts\":\"1575229904\"},\"1\":{\"get_star_ts\":\"1575228543\"}}},\"id\":\"668371\",\"stars\":4}},\"event\":\"2019\"}"
        parse(result)
    }
    var requested = false

    fun HttpGetAsyncPostGetCookies() {
        val ast =
                object : AsyncTask<String, Int, String>() {
                    override fun doInBackground(vararg params: String?): String {
                        var count = 0
                        try {
                            //if (stored_cookies == null) {
                                Log.d(TAG, "... GET ...")
                                val httpClient = DefaultHttpClient()
                                val httpget = HttpGet(params[0]!!)
                                val cookieStore = BasicCookieStore()
                                val bc1 = BasicClientCookie(
                                        "_gid", "GA1.2.12*********")  // ziskajte si vlastne
                                bc1.domain = "adventofcode.com"
                                bc1.path = "/"
                                bc1.isSecure = false
                                cookieStore.addCookie(bc1)
                                val bc2 = BasicClientCookie(
                                        "_ga", "GA1.2.117*********") // ziskajte si vlastne
                                bc2.domain = "adventofcode.com"
                                bc2.path = "/"
                                bc2.isSecure = false
                                cookieStore.addCookie(bc2)
                                val bc3 = BasicClientCookie(
                                        "session", "53616c*******")  // ziskajte si vlastne
                                bc3.domain = "adventofcode.com"
                                bc3.path = "/"
                                bc3.isSecure = false
                                cookieStore.addCookie(bc3)
                                val ctx = BasicHttpContext()
                                ctx.setAttribute(
                                        ClientContext.COOKIE_STORE,cookieStore
                                )
                                if (!cookieStore.getCookies().isEmpty()) {
                                    for (cook in cookieStore.getCookies()) {
                                        Log.d(TAG, "cookie:" + cook.getName()
                                              .toString() + " : " + cook.getValue()
                                        )
                                    }
                                }
                                val httpresponse = httpClient.execute(
                                        httpget
                                        , ctx
                                )
                                Log.d(
                                        TAG, httpresponse.getStatusLine()
                                        .toString()
                                )
                                val br = BufferedReader(
                                        InputStreamReader(
                                                httpresponse.getEntity().getContent()
                                        )
                                )
                                val result = StringBuilder()
                                while (true) {
                                    val line = br.readLine() ?: break
                                    result.append(line + "\n")
                                    publishProgress(count++)
                                }
                                return result.toString()
                            //}
                        } catch (e: Exception) {
                            Log.e(TAG, "unavailable:" + e.message)
                            e.printStackTrace()
                        }
                        return ""
                    }
                    override fun onPostExecute(resul: String?) {
                        super.onPostExecute(resul)
                        if (pd != null) pd.dismiss()
                        requested = false
                    }

                    override fun onPreExecute() {
                        super.onPreExecute()
                        if (requested) return
                        requested = true
                        pd = ProgressDialog(this@MyHttpClient)
                        pd.setProgressStyle(ProgressDialog.STYLE_SPINNER)
                        pd.max = 100
                        pd.show()
                    }
                    protected override fun onProgressUpdate(vararg values: Int?) {
                        super.onProgressUpdate(*values)
                        if (pd != null) pd.incrementProgressBy(values[0]?:0)
                    }
                }
        ast.execute("https://adventofcode.com/2019/leaderboard/private/view/229344.json")
    }
    fun parse(resul : String?) {
        // sem pride vas parser .jsonu
    }
}
