package com.example.httpaoc.json


import com.google.gson.annotations.SerializedName

data class X2XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX(
    @SerializedName("1")
    val x1: X1XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX,
    @SerializedName("2")
    val x2: X2XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
)