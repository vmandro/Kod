package com.example.httpaoc.json


import com.google.gson.annotations.SerializedName

data class CompletionDayLevelXXXXXXXXXXXXX(
    @SerializedName("1")
    val x1: X1XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX,
    @SerializedName("2")
    val x2: X2XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX,
    @SerializedName("3")
    val x3: X3XXXXXX
)