package com.example.gmapdirections
import android.Manifest
import android.annotation.SuppressLint
import android.app.ProgressDialog
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.example.gmapdirections.databinding.ActivityMapsBinding
import com.google.android.gms.maps.model.PolylineOptions
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding
    private lateinit var pDialog: ProgressDialog
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @SuppressLint("MissingPermission")
    override fun onMapReady(googleMap: GoogleMap) {
        if (ContextCompat.checkSelfPermission(
                this@MapsActivity,
                Manifest.permission.ACCESS_FINE_LOCATION
            )
            != PackageManager.PERMISSION_GRANTED
            &&
            ContextCompat.checkSelfPermission(
                this@MapsActivity,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION),
                MY_PERMISSIONS_REQUEST_FINE_LOCATION
            )
        }

        mMap = googleMap

        mMap.isMyLocationEnabled = true // zobrazi moju polohu a button na mape
        mMap.moveCamera(
            CameraUpdateFactory.newLatLngZoom(
                Centrum,
                13f
            )
        )
        GetDirection().execute()
    }
    internal inner class GetDirection : AsyncTask<String, String, List<LatLng>>() {
        override fun onPreExecute() {
            super.onPreExecute()
            pDialog = ProgressDialog(this@MapsActivity)
            pDialog.setMessage("Loading route. Please wait...")
            pDialog.isIndeterminate = false
            pDialog.setCancelable(false)
            pDialog.show()
        }

        override fun doInBackground(vararg args: String): List<LatLng>? {
            val startLocation = "Mlynska dolina, Bratislava".replace(" ", "+")
            val endLocation = "Zlate piesky, Bratislava".replace(" ", "+")
            val mode = "bicycle"
            val avoid = "highways"
            //https://maps.googleapis.com/maps/api/directions/json?origin=Mlynska+dolina,+Bratislava,+&destination=Zlate+piesky,+Bratislava,+&mode=bicycle,+&avoid=highways,+&waypoints=AGEM,+Kopcianska,+Bratislava|Alza,+Prievozska,+Bratislava,+&sensor=false&key=AIzaSyAxOzAo6fSggSbaaNgLBYjAcvZZ40GOX0c
            val via =
                "AGEM, Kopcianska, Bratislava|Alza, Prievozska, Bratislava".replace(" ", "+")
            val stringUrl = "https://maps.googleapis.com/maps/api/directions/json?" +
                    "origin=" + startLocation +
                    ",+&destination=" + endLocation +
                    ",+&mode=" + mode +
                    ",+&avoid=" + avoid +
                    ",+&waypoints=" + via +
                    ",+&sensor=false" +
                    "&key=AIzaSyAxOzAo6fSggSbaaNgLBYjAcvZZ40GOX0c"

            Log.d("MapDirection", stringUrl)
            val response = StringBuilder()
            try {
                val url = URL(stringUrl)
                val httpconn = url
                    .openConnection() as HttpURLConnection
                if (httpconn.responseCode == HttpURLConnection.HTTP_OK) {
                    val input = BufferedReader(
                        InputStreamReader(httpconn.inputStream),
                        8192
                    )
                    var strLine: String? = null
                    while (input.readLine().also { strLine = it } != null) {
                        response.append(strLine)
                    }
                    input.close()
                }
                val jsonOutput = response.toString()
                val jsonObject = JSONObject(jsonOutput)
                val routesArray = jsonObject.getJSONArray("routes")
                val route = routesArray.getJSONObject(0)
                val poly = route.getJSONObject("overview_polyline")
                Log.d("MapDirection", poly.toString())
                val polyline = poly.getString("points")
                return DecodePolyLine.decodePoly(polyline)
                //return decodePoly1(polyline)
            } catch (e: Exception) {
            }
            return null
        }

        override fun onPostExecute(points: List<LatLng>) {
            val line = mMap.addPolyline(PolylineOptions())
            mMap.addMarker(MarkerOptions().position(LatLng(48.151901, 17.068422) ))
            mMap.addMarker(MarkerOptions().position(LatLng(47.18592,15.72864) ))
            line.points = points
            line.width = 5f
            line.color = Color.RED
            line.isGeodesic = true
            pDialog.dismiss()
        }
    }
    // nefunguje, zle prelozil z Javy
    /* Method to decode polyline points */
    private fun decodePoly(encoded: String): List<LatLng> {
        val poly: MutableList<LatLng> = ArrayList()
        var index = 0
        val len = encoded.length
        var lat = 0
        var lng = 0
        while (index < len) {
            var b: Int
            var shift = 0
            var result = 0
            do {
                b = encoded[index++].toInt() - 63
                result = result or (b and 0x1f) shl shift
                shift += 5
            } while (b >= 0x20)
            val dlat = if (result and 1 != 0) (result shr 1).inv() else result shr 1
            lat += dlat
            shift = 0
            result = 0
            do {
                b = encoded[index++].toInt() - 63
                result = result or (b and 0x1f) shl shift
                shift += 5
            } while (b >= 0x20)
            val dlng = if (result and 1 != 0) (result shr 1).inv() else result shr 1
            lng += dlng
            val p = LatLng(
                lat.toDouble() / 1E5,
                lng.toDouble() / 1E5
            )
            poly.add(p)
        }
        return poly
    }// TODO Auto-generated method stub


    fun decodePoly1(encoded: String): List<LatLng>? {
        val poly: MutableList<LatLng> = ArrayList()
        var index = 0
        val len = encoded.length
        var lat = 0
        var lng = 0
        while (index < len) {
            var b: Int
            var shift = 0
            var result = 0
            do {
                b = encoded[index++].toInt() - 63
                result = result or (b and 0x1f) shl shift
                shift += 5
            } while (b >= 0x20)
            val dlat = if (result and 1 != 0) (result shr 1).inv() else result shr 1
            lat += dlat
            shift = 0
            result = 0
            do {
                b = encoded[index++].toInt() - 63
                result = result or (b and 0x1f) shl shift
                shift += 5
            } while (b >= 0x20)
            val dlng = if (result and 1 != 0) (result shr 1).inv() else result shr 1
            lng += dlng
            val p = LatLng(
                lat.toDouble() / 1E5,
                lng.toDouble() / 1E5
            )
            poly.add(p)
        }
        return poly
    }

    //@Override
    protected val isRouteDisplayed: Boolean
        protected get() =// TODO Auto-generated method stub
            false

    companion object {
        val Centrum = LatLng(48.140167, 17.10525)
        private const val MY_PERMISSIONS_REQUEST_FINE_LOCATION = 111
    }
}