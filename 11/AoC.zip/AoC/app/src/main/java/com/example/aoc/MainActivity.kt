package com.example.aoc

import android.app.ProgressDialog
import android.location.LocationManager
import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import org.apache.http.HttpResponse
import org.apache.http.client.methods.HttpGet
import org.apache.http.client.protocol.ClientContext
import org.apache.http.impl.client.BasicCookieStore
import org.apache.http.impl.client.DefaultHttpClient
import org.apache.http.impl.cookie.BasicClientCookie
import org.apache.http.protocol.BasicHttpContext
import java.io.BufferedReader
import java.io.InputStreamReader

@Suppress("DEPRECATION")
class MainActivity : AppCompatActivity() {
    lateinit var pd: ProgressDialog
    var stored_cookies: String? = null
    val TAG = "AoC"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Log.d(TAG, "start")
        HttpGetAsyncPostGetCookies()
    }
    var lastTime: Long = 0

    var requested = false

    fun HttpGetAsyncPostGetCookies() {
        val ast =
            object : AsyncTask<String, Int, String>() {
                override fun doInBackground(vararg params: String?): String {
                    var count = 0
                    try {
                        if (stored_cookies == null) {
                            Log.d(TAG, "... HTTP/GET ...")
                            val httpClient = DefaultHttpClient()
                            val httpget = HttpGet(params[0]!!)
                            val cookieStore = BasicCookieStore()
                            cookieStore.addCookie(
                                BasicClientCookie(
                                "_gid", "GA1.2.1267369824.1575127498"))
                            cookieStore.addCookie(
                                BasicClientCookie(
                                    "_ga", "GA1.2.117941379.1572787580"))
                            cookieStore.addCookie(
                                BasicClientCookie(
                                    "session", "53616c7465645f5f9d4157c5dffe1812a47fa72c18cadb2e8dfa76d7c28de16623dc1137f47c4430f4f085a70b869676"))
/* never expires
_gid = GA1.2.1267369824.1575127498
_ga = GA1.2.117941379.1572787580
session = 53616c7465645f5f9d4157c5dffe1812a47fa72c18cadb2e8dfa76d7c28de16623dc1137f47c4430f4f085a70b869676
 */
                            val ctx = BasicHttpContext()
                            ctx.setAttribute(
                                ClientContext.COOKIE_STORE,cookieStore
                            )
                            if (!cookieStore.getCookies().isEmpty()) {
                                for (cook in cookieStore.getCookies()) {
                                    Log.d(
                                        TAG, "cookie:" + cook.getName()
                                            .toString() + " : " + cook.getValue()
                                    )
                                }
                            }
                            val httpresponse = httpClient.execute(
                                httpget
                               , ctx
                            )
                            Log.d(
                                TAG, httpresponse.getStatusLine()
                                    .toString()
                            )
                            val br = BufferedReader(
                                InputStreamReader(
                                    httpresponse.getEntity().getContent()
                                )
                            )
                            val result = StringBuilder()
                            while (true) {
                                val line = br.readLine() ?: break
                                result.append(line + "\n")
                                publishProgress(count++)
                            }
                            return result.toString()
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "unavailable:" + e.message)
                        e.printStackTrace()
                    }
                    return ""
                }
                override fun onPostExecute(result: String?) {
                    super.onPostExecute(result)
                    if (result != null) Log.d(TAG, result)
                    if (pd != null) pd.dismiss()
                    requested = false
                }

                override fun onPreExecute() {
                    super.onPreExecute()
                    if (requested) return
                    requested = true
                    pd = ProgressDialog(this@MainActivity)
                    pd.setProgressStyle(ProgressDialog.STYLE_SPINNER)
                    pd.max = 100
                    pd.show()
                }
                protected override fun onProgressUpdate(vararg values: Int?) {
                    super.onProgressUpdate(*values)
                    if (pd != null) pd.incrementProgressBy(values[0]?:0)
                }
            }
        ast.execute("https://adventofcode.com/2019/leaderboard/private/view/229344.json")
    }
}
