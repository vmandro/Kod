package com.example.coroutineretrofit.view

// dorobit na List Base adapter...
//class ListAdapterBase(var staty: ArrayList<Stat>): BaseAdapter() {
//    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
//        TODO("Not yet implemented")
//    }
//
//    override fun getItem(p0: Int): Any {
//        TODO("Not yet implemented")
//    }
//
//    override fun getItemId(p0: Int): Long {
//        TODO("Not yet implemented")
//    }
//
//    override fun getCount(): Int = staty.size
//
//    fun updateCountries(newCountries: List<Stat>) {
//        staty.clear()
//        staty.addAll(newCountries)
//        notifyDataSetChanged()
//    }
//
//    override fun onCreateViewHolder(parent: ViewGroup, p1: Int) = StatViewHolder(
//        LayoutInflater.from(parent.context).inflate(R.layout.item_country, parent, false)
//    )
//
//    override fun onBindViewHolder(holder: StatViewHolder, position: Int) {
//        holder.bind(staty[position])
//    }
//
//    class StatViewHolder(view: View): RecyclerView.ViewHolder(view) {
//        private val imageView = view.imageView
//        private val stat = view.name
//        private val hlmesto = view.capital
//        private val kod = view.code
//        private val hranice = view.borders
//
//        fun bind(country: Stat) {
//            stat.text = country.countryName
//            hlmesto.text = country.capital
//            kod.text = country.code
//            hranice.text = country.borders?.joinToString(separator = ",")
//            val options = RequestOptions().error(R.mipmap.ic_launcher_round)
//            Glide.with(imageView)
//                .setDefaultRequestOptions(options)
//                .load(country.flag)
//                .into(imageView)
//        }
//    }
//}