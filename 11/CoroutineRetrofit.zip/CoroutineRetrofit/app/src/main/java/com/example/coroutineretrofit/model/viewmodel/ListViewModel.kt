package com.example.coroutineretrofit.viewmodel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.coroutineretrofit.model.Stat
import com.example.coroutineretrofit.model.RetroService
import kotlinx.coroutines.*

class ListViewModel: ViewModel() {
    private val service = RetroService.get()
    lateinit var job: Job
    val staty = MutableLiveData<List<Stat>>()

    fun fetch() {
        job = CoroutineScope(Dispatchers.IO).launch {
            val response = service.get()
            withContext(Dispatchers.Main) {
                if (response.isSuccessful)
                    staty.value = response.body()
                else
                    Log.d("MODEL", "Error: ${response.message()}")
            }
        }
    }
    override fun onCleared() {
        super.onCleared()
        job.cancel()
    }
}