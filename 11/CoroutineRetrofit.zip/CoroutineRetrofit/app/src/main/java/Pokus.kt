
import com.google.gson.annotations.SerializedName

data class Pokus(
    @SerializedName("first_name")
    val firstName: String,
    val gender: String,
    val id: String,
    @SerializedName("last_name")
    val lastName: String,
    val link: String,
    val locale: String,
    val name: String,
    val username: String
)

/*
{
 "id": "1547257485",
 "name": "Peter Borovansky",
 "first_name": "Peter",
 "last_name": "Borovansky",
 "link":"http://www.facebook.com/
	peter.borovansky",
 "username": "peter.borovansky",
 "gender": "male",
 "locale": "cs_CZ"
}


 */