package com.example.gsmretrofit

import android.util.Log
import android.widget.Toast
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RestApiService {
    val TAG = "GSM"
    suspend fun gsm2latlong(gsmRequest: GSMRequest, onResult: (GSMResponse?) -> Unit){
        val retrofit = ServiceBuilder.get()
        Log.d(TAG, "request $gsmRequest")
        retrofit.gsm2latlong(gsmRequest).enqueue(
            object : Callback<GSMResponse> {
                override fun onFailure(call: Call<GSMResponse>, t: Throwable) {
                    Log.d(TAG, "onFailure")
                    onResult(null)
                }
                override fun onResponse(call: Call<GSMResponse>, response: Response<GSMResponse>) {
                    Log.d(TAG, "onResponse")
                    val resp = response.body()
                    Log.d(TAG, "response $resp")
                    onResult(resp)
                }
            }
        )
    }
}