package com.example.gsmretrofit

data class Cell(
    val cid: Int,
    val lac: Int
)