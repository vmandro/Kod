package com.example.gsmretrofit

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.telephony.TelephonyManager
import android.telephony.gsm.GsmCellLocation
import android.util.Log
import com.example.gsmretrofit.databinding.ActivityMainBinding
import java.lang.RuntimeException
import kotlinx.coroutines.*

class MainActivity : Activity() {
    lateinit var tm: TelephonyManager
    var token_locationAPIORG : String = "95b2941777892d" // asi davno uz neplati !!!
    var token_locationAPI : String = token_locationAPIORG
    val TAG = "GSM"

    val RUNTIME_PERMISSION_REQUEST_CODE = 777
    val perms = arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.READ_PHONE_STATE
    )
    private lateinit var binding : ActivityMainBinding

    @SuppressLint("MissingPermission")
    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(
                perms,
                RUNTIME_PERMISSION_REQUEST_CODE
            )
        }
        tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        binding.tokenEdit.setText(token_locationAPIORG)
        binding.updateBtn.setOnClickListener {
            val location = tm.cellLocation as GsmCellLocation
            val cid = location.cid
            val lac = location.lac
            Log.d(TAG, "gsm cid: $cid")
            Log.d(TAG, "gsm lac: $lac")
            val networkOperator = tm.networkOperator
            Log.d(TAG, "operator: $networkOperator")
            if (networkOperator.length > 0) {
                Log.d(TAG, "network: $networkOperator")
                    val mcc = Integer.parseInt(networkOperator.substring(0, 3))
                    val mnc = Integer.parseInt(networkOperator.substring(3))
                    Log.d(TAG, "mcc: $mcc")
                    Log.d(TAG, "mnc: $mnc")
                    token_locationAPI = binding.tokenEdit.text.toString()
                    if (token_locationAPI === "")
                        token_locationAPI = token_locationAPIORG

                    val request = GSMRequest(
                        token = "95b2941777892d",
                        mcc = mcc,
                        mnc = mnc,
                        cells = listOf(Cell(lac = lac, cid = cid)),
                        address = 1
                    )
                    /*
                         * Check if the current cell is a UMTS (3G) cell. If a 3G
                         * cell the cell id padding will be 8 numbers, if not 4
                         * numbers.
                         */
                    var cellPadding = 4
                    if (tm.networkType == TelephonyManager.NETWORK_TYPE_UMTS) {
                        cellPadding = 8
                    }
                    binding.apply {
                        celIDTV.text = "CellID: ${getPaddedHex(cid, cellPadding)}, $cid"
                        lacTV.text = "Lac: ${getPaddedHex(lac, 4)},$lac"
                        mccTV.text = "Mcc: ${getPaddedInt(mcc, 3)}"
                        mncTV.text = "Mnc: ${getPaddedInt(mnc, 2)}"
                    }
                    Log.d(TAG, "request $request")
                        val apiService = RestApiService()
                        CoroutineScope(Dispatchers.IO).launch {
                            Log.d(TAG, "pred gsm2latlong")
                            val response = apiService.gsm2latlong(request) { response ->
                                if (response != null) {
                                    Log.d(TAG, "${response.lat}, ${response.lon}")
                                    //withContext(Dispatchers.Main) {
                                    CoroutineScope(Dispatchers.Main).launch {
                                        binding.latTV.text = response.lat.toString()
                                        binding.longTV.text = response.lon.toString()
                                    }
                                } else
                                    Log.d(TAG, "response is null")
                            }
                        }
                }
        }
        binding.mapButton.setOnClickListener {
            Log.d(TAG, "geo:${binding.latTV.text},${binding.longTV.text}")
            val myIntent = Intent(
                    android.content.Intent.ACTION_VIEW,
                    Uri.parse("geo:0,0?q=${binding.latTV.text},${binding.longTV.text}"))
            startActivity(myIntent)
        }
    }
    // skonveruje na HEX a doplni nulami spredu
    fun getPaddedHex(nr: Int, minLen: Int): String {
        try {
            var str: String = Integer.toHexString(nr)
            while (str.length < minLen) str = "0$str"
            return str
        } catch (e : RuntimeException) {
            return ""
        }
    }
    // doplni nulami spredu
    fun getPaddedInt(nr: Int, minLen: Int): String? {
        try {
            var str: String = Integer.toString(nr)
            while (str.length < minLen) str = "0$str"
            return str
        } catch (e : RuntimeException) {
            return ""
        }
    }

    override fun onRequestPermissionsResult(
            requestCode: Int,
            permissions: Array<String>, grantResults: IntArray
    ) {
        when (requestCode) {
            RUNTIME_PERMISSION_REQUEST_CODE -> {
                for (i in grantResults.indices) {
                    if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                        Log.d("WiFi", "GRANTED")
                    } else {  // denied
                        Log.d("WiFi", "DENIED")
                    }
                }
                return
            }
        }
    }
}