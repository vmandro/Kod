package com.example.coroutinesdb.model

object Status {
    var loggedIn = false
    var student: Student? = null

    fun logout() {
        loggedIn = false
        student = null
    }

    fun login(user: Student) {
        loggedIn = true
        this.student = user
    }


}