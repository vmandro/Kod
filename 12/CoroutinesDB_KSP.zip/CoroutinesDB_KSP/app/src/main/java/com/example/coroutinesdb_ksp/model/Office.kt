package com.example.coroutinesdb.model

import androidx.annotation.NonNull
import androidx.room.Entity

@Entity(primaryKeys = ["id", "code"])
class Office {
    val id : Int = 0

    @get:NonNull
    @NonNull
    var code: String? = null
}