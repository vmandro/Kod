package com.example.coroutinesdb_ksp.model

import androidx.lifecycle.LiveData
import androidx.room.*


@Dao
interface CompanyDao {
    @get:Query("SELECT * FROM Company")
    val allCompanies: LiveData<List<Company?>?>?

    @get:Query("SELECT * FROM Company ORDER BY name")
    val allCompaniesOrdered: LiveData<List<Company?>?>?

    @Insert
    fun insertCompany(company: Company?)

    @Query("SELECT * FROM Company WHERE name LIKE :companyName")
    fun getCompanies(companyName: String?): LiveData<List<Company?>?>?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(companies: List<Company?>?)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(vararg companies: Company?)

    @Update
    fun updateCompany(company: Company?)

    @Update
    fun updateCompanies(vararg company: Company?)

    @Delete
    fun deleteCompany(company: Company?)

    @Delete
    fun deleteCompanies(vararg company: Company?)
}
