package com.example.coroutinesdb.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Student (
    val isic: String,
    val name: String,
    val passwordHash: Int,
    val description: String) {
    @PrimaryKey(autoGenerate = true)
    var id: Long = 0
}