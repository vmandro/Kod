package com.example.fbdemo1

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class MainActivity : AppCompatActivity() {
    private var mAuth: FirebaseAuth? = null
    private val TAG = "TAGG"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        mAuth = FirebaseAuth.getInstance()
    }

    override fun onStart() {
        super.onStart()
        // Check if user is signed in (non-null) and update UI accordingly.
        //updateUI(currentUser);
        val currentUser = mAuth!!.currentUser

        val memail = "marienka12345678.hraskova@yahoo.com"
        val mpassword = "marienka12345678"
        mAuth!!.createUserWithEmailAndPassword(memail, mpassword)
            .addOnCompleteListener(
                this
            ) { task ->
                if (task.isSuccessful) {
                    // Sign in success, update UI with the signed-in user's information
                    Log.d(TAG, "createUserWithEmail:success")
                    val user = mAuth!!.currentUser
                    Toast.makeText(
                        this@MainActivity,
                        "CreateUserWithEmail success, current user is: " + user!!.email,
                        Toast.LENGTH_SHORT
                    ).show()

                    //updateUI(user);
                } else {
                    // If sign in fails, display a message to the user.
                    Log.w(TAG, "createUserWithEmail:failure", task.exception)
                    Toast.makeText(
                        this@MainActivity, "Authentication failed.",
                        Toast.LENGTH_SHORT
                    ).show()
                    //updateUI(null);
                }

                // ...
            }


//        val email = "marienka123456.hraskova@yahoo.com"
//        val password = "marienka12345"
//        //String password = "hrasko1234";
//        mAuth!!.signInWithEmailAndPassword(email, password)
//            .addOnCompleteListener(
//                this
//            ) { task ->
//                if (task.isSuccessful) {
//                    // Sign in success, update UI with the signed-in user's information
//                    Log.d(TAG, "signInWithEmail:success")
//                    val user = mAuth!!.currentUser
//                    Toast.makeText(
//                        this@MainActivity,
//                        "Authentication success, current user is: " + user!!.email,
//                        Toast.LENGTH_SHORT
//                    ).show()
//                    updateUI() // user
//                } else {
//                    // If sign in fails, display a message to the user.
//                    Log.w(TAG, "signInWithEmail:failure", task.exception)
//                    Toast.makeText(
//                        this@MainActivity, "Authentication failed.",
//                        Toast.LENGTH_SHORT
//                    ).show()
//                    //updateUI(null);
//                }
//
//                // ...
//            }
    }

    private fun updateUI() {
        // Access User information
        val user = FirebaseAuth.getInstance().currentUser
        if (user != null) {
            // Name, email address, and profile photo Url
            val name = user.displayName
            val mail = user.email
            val photoUrl = user.photoUrl

            // Check if user's email is verified
            val emailVerified = user.isEmailVerified

            // The user's ID, unique to the Firebase project. Do NOT use this value to
            // authenticate with your backend server, if you have one. Use
            // FirebaseUser.getIdToken() instead.
            val uid = user.uid
            Log.d(TAG, "current user info, name:$name")
            Log.d(TAG, "current user info, email:$mail")
            Log.d(TAG, "current user info, photo:$photoUrl")
            Log.d(TAG, "current user info, emailVerified:$emailVerified")
            Log.d(TAG, "current user info, uid:$uid")
        }
    }

}