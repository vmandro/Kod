package com.example.cviceniec

import androidx.room.*

@Dao
interface PredmetDAO {
    @Query("SELECT * FROM Predmet WHERE kod = :str")
    suspend fun getKod(str: String): Predmet?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(Predmet: Predmet): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(vararg Predmet: Predmet)

    @Query("DELETE FROM Predmet WHERE id = :id")
    suspend fun deleteID(id: Long)

    @Delete
    fun delete(Predmet: Predmet)
}