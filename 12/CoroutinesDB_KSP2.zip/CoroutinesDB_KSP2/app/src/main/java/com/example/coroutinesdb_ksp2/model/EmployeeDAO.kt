package com.example.coroutinesdb_ksp2.model

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface EmployeeDao {
    @get:Query("SELECT * FROM Employee")
    val allEmployees: LiveData<List<Employee?>?>?

    @RawQuery
    fun getAllEmployeesWithLimit(query: String?): List<Employee?>?

    @Insert
    fun insertEmployee(employee: Employee?)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(employees: List<Employee?>?)

    @Update
    fun updateEmployee(employee: Employee?)

    @Delete
    fun deleteEmployee(employee: Employee?)
}