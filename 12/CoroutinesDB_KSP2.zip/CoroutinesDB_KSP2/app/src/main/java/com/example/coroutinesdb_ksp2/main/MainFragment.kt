package com.example.coroutinesdb_ksp2.main

import android.app.AlertDialog
import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputBinding
import android.widget.Toast
import androidx.lifecycle.Observer
import com.example.coroutinesdb_ksp2.databinding.MainFragmentBinding
//import androidx.lifecycle.ViewModelProviders
//import androidx.lifecycle.observe
//import com.example.coroutinesdb.R

//import com.example.

//databinding.MainFragmentBinding
import com.example.coroutinesdb_ksp2.main.MainViewModel
//import kotlinx.android.synthetic.main.main_fragment.*

class MainFragment : Fragment() {

    companion object {
        fun newInstance() = MainFragment()
    }

    private lateinit var viewModel: MainViewModel
    private lateinit var binding: MainFragmentBinding
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {
        binding = MainFragmentBinding.inflate(inflater, container, false)
//        binding.lifecycleOwner = this
//        binding.viewModel = viewModel
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        binding.apply {
            signupBtn.setOnClickListener {
                val isic = isic.text.toString()
                val name = name.text.toString()
                val password = password.text.toString()
                val desc = description.text.toString()
                if (name.isEmpty() || password.isEmpty() || isic.isEmpty()) {
                    Toast.makeText(activity, "Please fill all fields", Toast.LENGTH_SHORT).show()
                } else {
                    viewModel.signup(isic, name, password, desc)
                }
            }
            loginBtn.setOnClickListener {
                val isic = isic.text.toString()
                val name = name.text.toString()
                val password = password.text.toString()
                if (name.isEmpty() || password.isEmpty() || isic.isEmpty()) {
                    Toast.makeText(activity, "Please fill all fields", Toast.LENGTH_SHORT).show()
                } else {
                    viewModel.login(name, password)
                }
            }
            logoutBtn.setOnClickListener {
                viewModel.signout()
            }
            deleteBtn.setOnClickListener {
                val n = name.text
                activity?.let {
                    AlertDialog.Builder(it)
                        .setTitle("Delete ?")
                        .setMessage("Are you sure you want to delete ${n}?")
                        .setPositiveButton("Yes") { p0, p1 -> viewModel.onDeleteUser() }
                        .setNegativeButton("Cancel", null)
                        .create()
                        .show()
                }
            }
        }
        fun clearFields() {
            binding.apply {
                name.setText("")
                password.setText("")
                isic.setText("")
                description.setText("")
            }
        }
        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)
        //viewModel = ViewModelProviders.of(this).get(MainViewModel::class.java)
        viewModel.signout.observe(viewLifecycleOwner, Observer {
            Toast.makeText(activity, "Logged out", Toast.LENGTH_SHORT).show()
            binding.apply {
                loggedUserTV.text = ""
                clearFields()
            }
        })
        viewModel.deleted.observe(viewLifecycleOwner, Observer {
            Toast.makeText(activity, "User deleted", Toast.LENGTH_SHORT).show()
            clearFields()
        })
        viewModel.logged.observe(viewLifecycleOwner, Observer { isComplete ->
            Toast.makeText(activity, "Login complete", Toast.LENGTH_SHORT).show()
            binding.loggedUserTV.text = binding.name.text
            clearFields()
        })
        viewModel.error.observe(viewLifecycleOwner, Observer { error ->
            Toast.makeText(activity, "Error: $error", Toast.LENGTH_SHORT).show()
        })
    }
}