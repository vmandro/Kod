package com.example.coroutinesdb_ksp2.model

object Status {
    var loggedIn = false
    var student: Student? = null

    fun logout() {
        loggedIn = false
        student = null
    }

    fun login(user: Student) {
        loggedIn = true
        this.student = user
    }


}