package com.example.coroutinesdb_ksp2.model

/*
boilerPlate code - take it as it is, replace Student...
 */
import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = arrayOf(Student::class), version = 1)
abstract class StudentDatabaseEasy: RoomDatabase() {
    abstract fun studentDAO(): StudentDAO
    fun getInstance(context: Context) = Room.databaseBuilder(
           context.applicationContext,
           StudentDatabaseEasy::class.java,
          "studentdatabase"
    ).build()
}