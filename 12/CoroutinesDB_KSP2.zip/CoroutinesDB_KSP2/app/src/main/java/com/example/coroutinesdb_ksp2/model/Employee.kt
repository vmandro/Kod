package com.example.coroutinesdb_ksp2.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import com.example.coroutinesdb_ksp2.model.Company

@Entity(foreignKeys = [ForeignKey(
        entity = Company::class,
        parentColumns = ["id"],
        childColumns = ["company_id"],
        onDelete = ForeignKey.CASCADE)])

data class Employee (
    @ColumnInfo(name = "name")
    val name: String? = null,

    @ColumnInfo(name = "company_id")
    val companyId : Int = 0)
{
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val employeeId : Int = 0
}
