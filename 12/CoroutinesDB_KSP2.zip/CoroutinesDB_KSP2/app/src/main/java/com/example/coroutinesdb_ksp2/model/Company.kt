package com.example.coroutinesdb_ksp2.model
import android.graphics.Bitmap
import android.location.Location
import androidx.room.*
import java.util.*

@Entity(tableName = "Company")
data class Company (
    @ColumnInfo(name = "name")
    val name: String? = null,

    @ColumnInfo(name = "date_updated")
    @TypeConverters(DateConverter::class)
    val itemUpdatedDate: Date? = null,

    @Embedded
    private val location: Location? = null,

    @Embedded(prefix = "hq_")
    private val headLocation: Location? = null,

    @Ignore
    val picture: Bitmap? = null
) {
    @PrimaryKey
    @ColumnInfo(name = "id")
    val companyId = 0
}
