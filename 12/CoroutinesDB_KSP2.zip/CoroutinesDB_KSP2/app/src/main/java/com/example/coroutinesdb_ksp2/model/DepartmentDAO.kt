package com.example.coroutinesdb_ksp2.model

import androidx.room.*

@Dao
abstract class DepartmentDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract fun insertAll(departments: List<Department?>?)

    @Insert
    abstract fun insert(product: Department?)

    @Delete
    abstract fun delete(product: Department?)

    @Transaction
    fun insertAndDeleteInTransaction(newDepartment: Department?, oldDepartment: Department?) {
        insert(newDepartment)
        delete(oldDepartment)
    }
}
