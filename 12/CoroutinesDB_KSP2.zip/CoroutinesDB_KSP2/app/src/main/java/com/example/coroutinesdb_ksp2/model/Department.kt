package com.example.coroutinesdb_ksp2.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "Department")
class Department(
        @ColumnInfo(name = "name")
        val name: String? = null,

        @ColumnInfo(name = "company_id")
        val companyId :Int = 0
) {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    var id = 0
}
