package com.example.coroutinesdb.model
import androidx.room.*
import androidx.room.ForeignKey.CASCADE

@Entity
data class User(
        @PrimaryKey val userId: Long,
        val name: String,
        val age: Int
)
@Entity(foreignKeys = arrayOf(ForeignKey(entity = User::class,
        parentColumns = arrayOf("userId"),
        childColumns = arrayOf("userOwnerId"),
        onDelete = CASCADE)))

data class Library(
        @PrimaryKey val libraryId: Long,
        val title: String,
        val userOwnerId: Long
)

data class UserAndLibrary(
        @Embedded val user: User,
        @Relation(
                parentColumn = "userId",
                entityColumn = "userOwnerId"
        )
        val library: Library
)

