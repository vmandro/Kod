package com.example.coroutinesdb.ui.main

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.example.coroutinesdb.model.Status
import com.example.coroutinesdb.model.Student
import com.example.coroutinesdb.model.StudentDAO
import com.example.coroutinesdb.model.StudentDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(application : Application) : AndroidViewModel(application) {
    private val coroutineScope = CoroutineScope(Dispatchers.IO)
    private val db: StudentDAO by lazy { StudentDatabase(getApplication()).studentDAO() }


    val logged = MutableLiveData<Boolean>()
    val error = MutableLiveData<String>()

    val deleted = MutableLiveData<Boolean>()
    val signout = MutableLiveData<Boolean>()
    val TAG = "MODEL"

    fun login(name: String, password: String) {
        Log.d(TAG, "login $name with $password")
        coroutineScope.launch {
            val student = db.getName(name)
            if (student == null) {
                withContext(Dispatchers.Main) {
                    Log.d(TAG, "login not found")
                    error.value = "Student not found"
                }
            } else {
                if (student.passwordHash == password.hashCode()) {
                    Status.login(student)
                    withContext(Dispatchers.Main) {
                        Log.d(TAG, "login logged")
                        logged.value = true
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        Log.d(TAG, "login incorrect")
                        error.value = "Password is incorrect"
                    }
                }
            }
        }
    }

    fun signup(isic: String, name: String, password: String, description: String) {
        Log.d(TAG, "signup $isic, $name with $password")
        coroutineScope.launch {
            if (db.getName(name) != null || db.getISIC(isic) != null) {
                withContext(Dispatchers.Main) {
                    Log.d(TAG, "signupID exists")
                    error.value = "Student already exists"
                }
            } else {
                val student = Student(isic, name, password.hashCode(), description)
                val studentId = db.insert(student)
                Log.d(TAG, "signupID $studentId")
                student.id = studentId
                Status.login(student)
                withContext(Dispatchers.Main) {
                    logged.value = true
                }
            }
        }
    }

    fun signout() {
        Log.d(TAG, "signout ${Status.student}")
        Status.logout()
        signout.value = true
    }

    fun onDeleteUser() {
        Log.d(TAG, "delete ${Status.student.toString()}")
        coroutineScope.launch {
            Status.student?.let { student ->
                db.deleteID(student.id)
            }
            withContext(Dispatchers.Main) {
                Status.logout()
                deleted.value = true
            }
        }
    }
}