package com.example.coroutinesdb.model

import androidx.room.*

@Dao
interface StudentDAO {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(student: Student): Long

    @Query("SELECT * FROM Student WHERE name = :name")
    suspend fun getName(name: String): Student?

    @Query("SELECT * FROM Student WHERE id = :id")
    suspend fun getID(id: Long): Student?

    @Query("SELECT * FROM Student WHERE isic = :isic")
    suspend fun getISIC(isic: String): Student?

    @Query("DELETE FROM Student WHERE id = :id")
    suspend fun deleteID(id: Long)

    @Insert
    fun insertAll(vararg students: Student)

    @Delete
    fun delete(student: Student)
}