package com.google.firebase.quickstart.ai.feature.media.imagen

enum class EditingMode {
    GENERATE,
    INPAINTING,
    OUTPAINTING,
    SUBJECT_REFERENCE,
    STYLE_TRANSFER,
    TEMPLATE,
}