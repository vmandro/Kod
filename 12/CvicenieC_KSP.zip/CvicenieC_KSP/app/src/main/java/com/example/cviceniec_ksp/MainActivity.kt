package com.example.cviceniec_ksp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    val TAG = "DB"
    val coroutineScope = CoroutineScope(Dispatchers.IO)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //val db = HodnotenieDB.invoke(getApplicationContext())
        val db = HodnotenieDB.getInstance(getApplicationContext())
        initZnamka(db)
        initPredmet(db)
    }
    fun initZnamka(db : HodnotenieDB) {
        coroutineScope.launch {
            db.znamkaDAO().insertAll(
                Znamka("A"),
                Znamka("B"),
                Znamka("C"),
                Znamka("D"),
                Znamka("E"),
                Znamka("Fx")
            )
            val za = db.znamkaDAO().getText("A")?.toString()
            Log.d(TAG, "znamka A: $za")
            val zq = db.znamkaDAO().getText("Q")?.toString()
            Log.d(TAG, "znamka Q: $zq")
        }
    }
    fun initPredmet(db : HodnotenieDB) {
        coroutineScope.launch {
            db.predmetDAO().insert(
                Predmet("1-AIN-472/12", "Vývoj mobilných aplikácií, zimný semester 2020/2021")
            )
            val za = db.predmetDAO().getKod("1-AIN-472/12")?.toString()
            Log.d(TAG, "predmet VMA: $za")
            val zq = db.predmetDAO().getKod("1-AIN-472")?.toString()
            Log.d(TAG, "iny predmet: $zq")
        }
    }
}