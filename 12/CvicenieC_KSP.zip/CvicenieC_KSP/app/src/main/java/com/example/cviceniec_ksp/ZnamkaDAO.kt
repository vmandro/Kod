package com.example.cviceniec_ksp

import androidx.room.*

@Dao
interface ZnamkaDAO {
    @Query("SELECT * FROM Znamka WHERE text = :str")
    suspend
    fun getText(str: String): Znamka?

    @Query("SELECT * FROM Znamka WHERE id = :id")
    suspend
    fun getID(id: Long): Znamka?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend
    fun insert(znamka: Znamka): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(vararg znamky: Znamka)

    @Query("DELETE FROM Znamka WHERE id = :id")
    suspend
    fun deleteID(id: Long)

    @Delete
    fun delete(znamka: Znamka)
}