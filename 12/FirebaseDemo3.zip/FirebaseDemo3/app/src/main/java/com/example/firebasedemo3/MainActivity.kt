package com.example.firebasedemo3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.activity_main.*
import java.util.HashMap

class MainActivity : AppCompatActivity(), View.OnClickListener {
    lateinit var firebaseAuth: FirebaseAuth
    lateinit var mAuthListener: FirebaseAuth.AuthStateListener
    lateinit var databaseReference: DatabaseReference
    lateinit var globalState: MutableMap<String, String>

    val TAG = "RealDB"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        globalState = mutableMapOf<String, String>()
        /*
        {
        "rules": {
        ".read": true,
        ".write": true
        }
        */
        //getting the database reference
        databaseReference = FirebaseDatabase.getInstance().reference
        firebaseAuth = FirebaseAuth.getInstance()

        mAuthListener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            if (user != null) { // User is signed in
                Log.d(TAG, "onAuthStateChanged:signed_in:" + user.uid)
            } else { // User is signed out
                Log.d(TAG, "onAuthStateChanged:signed_out")
            }
        }
        firebaseAuth.signInWithEmailAndPassword("vmaandroid@yahoo.com", "androidVMA2016")
            .addOnCompleteListener(this) { task ->
                Log.d(TAG, "signInWithEmail:onComplete:" + task.isSuccessful)
                if (!task.isSuccessful) {
                    Log.w(TAG, "signInWithEmail", task.exception)
                    Toast.makeText(
                        this@MainActivity, "Authentication failed.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        buttonSave.setOnClickListener(this)
        buttonLogout.setOnClickListener(this)
        buttonClear.setOnClickListener(this)
        databaseReference.addValueEventListener(object : ValueEventListener {
            override fun onCancelled(error: DatabaseError) {
                Log.w(TAG, "Failed to read value.", error.toException())
            }

            override fun onDataChange(dataSnapshot: DataSnapshot) {
                statusMemo.setText("")
                Log.e("#Children:", "" + dataSnapshot.childrenCount)
                for (postSnapshot in dataSnapshot.children) {
                    val o = postSnapshot.value
                    if (o is Pokemon)
                        statusMemo.append("Pokemon has ")
                    Log.d(TAG, postSnapshot.key)
                    statusMemo.append("changed ${postSnapshot.key} is: ${o.toString()}\n")
                }
            }
        })
    }
    public override fun onStart() {
        super.onStart()
        firebaseAuth.addAuthStateListener(mAuthListener)
    }

    public override fun onStop() {
        super.onStop()
        if (mAuthListener != null) {
            firebaseAuth.removeAuthStateListener(mAuthListener)
        }
    }
    override fun onClick(view: View) {
        if (view === buttonClear) {
            if (databaseReference != null) {
                databaseReference.removeValue()
                databaseReference.child("pikatchus").removeValue()
                databaseReference.child("statuses").removeValue()
                globalState = mutableMapOf()
                val user = firebaseAuth.currentUser
                if (user != null) {
                    databaseReference.child(user.uid).removeValue()
                }
                Toast.makeText(this, "Clear all...", Toast.LENGTH_LONG).show()
            }
        } else if (view === buttonLogout) {
            firebaseAuth.signOut()
            Toast.makeText(this, "Sign out...", Toast.LENGTH_LONG).show()
            finish()
        } else if (view === buttonSave) {
            val name = editTextName.text.toString().trim { it <= ' ' }
            val status = editTextAddress!!.text.toString().trim { it <= ' ' }
            if (databaseReference != null) {
                databaseReference.child("pikatchus").setValue(
                    Pokemon(name, status, (Math.round(100 * (48 + Math.random())) / 100).toDouble(), (Math.round(100 * (17 + Math.random())) / 100).toDouble()))
                if (globalState == null) globalState = HashMap()
                globalState[name] = status
                databaseReference.child("statuses").setValue(globalState)
                val user = firebaseAuth.currentUser
                if (user != null) {
                    databaseReference.child(user.uid).setValue(status)
                }
                Toast.makeText(this, "Saved...", Toast.LENGTH_LONG).show()
            }
        }
    }
}