package com.example.firebasedemo3

import java.io.Serializable

class Pokemon : Serializable {
    var name: String? = null
    var time: Long = 0
    var address: String? = null
    var lati = 0.0
    var longi = 0.0

    constructor() {}
    constructor(name: String?, address: String?, lati: Double, longi: Double) {
        this.name = name
        this.address = address
        this.lati = lati
        this.longi = longi
        time = System.currentTimeMillis()
    }
}