package com.example.layouts16

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.layouts16.databinding.ActivityLoginBinding

class LoginLayoutActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

    }
}
