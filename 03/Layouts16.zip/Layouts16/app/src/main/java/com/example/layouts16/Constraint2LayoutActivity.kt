package com.example.layouts16

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class Constraint2LayoutActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_constraint_layout5)
    }
}