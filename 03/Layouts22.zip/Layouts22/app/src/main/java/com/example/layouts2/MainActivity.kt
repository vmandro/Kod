package com.example.layouts2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.provider.MediaStore.ACTION_IMAGE_CAPTURE
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.CheckedTextView
import android.widget.ListAdapter
import com.example.layouts2.databinding.ActivityMainBinding
import kotlin.reflect.KClass

class MainActivity : AppCompatActivity() {
    private val klasy = arrayOf(
        GridLayoutActivity::class.java,
        FrameLayoutActivity::class.java,
        RelativeLayoutActivity::class.java,
        ConstraintLayoutActivity::class.java,
        MainLinearLayoutActivity::class.java,
        ListActivity::class.java,
        MainActivity::class.java,
        Constraint2LayoutActivity::class.java,
        Constraint9Activity::class.java
    )
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding =   ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        // vid slajd
        val kotlinClass = GridLayoutActivity::class
        val javaClass = GridLayoutActivity::class.java
        val i = Intent(this@MainActivity, javaClass)
        //val int = Intent(MediaStore.ACTION_IMAGE_CAPTURE)

        binding.listViewID.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            resources.getStringArray(R.array.activities)
//            arrayListOf(
//                "Grid layout",
//                "Frame layout",
//                "Relative layout",
//                "Constraint layout",
//                "Linear layout",
//                "List layout",
//                "Simple List layout")
        )
        binding.listViewID.setOnItemClickListener {
            adapterView, view, index, l ->
            Log.d("LISTPICK",
                "click: $index:${adapterView.getItemAtPosition(index)}")
            if (index < klasy.size)
              startActivity(Intent(this@MainActivity,klasy[index]))
        }
    }
}
