package com.example.layouts2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainLinearLayoutActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_linear_layout)
    }
}
