package com.example.layouts2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.*
import com.example.layouts2.databinding.ActivityListBinding

class ListActivity : AppCompatActivity() {
    private lateinit var binding: ActivityListBinding
    val TAG = "ZOZNAM"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupListView1()
        setupListView2()
        setupListView3()
    }
    private fun setupListView1() {
        // poker list view
        binding.listView1.adapter = ArrayAdapter(
            this,
            android.R.layout
                .simple_list_item_activated_1,
                //.simple_list_item_1,
            resources.getStringArray(R.array.poker)
        )
        binding.listView1.choiceMode = ListView.CHOICE_MODE_MULTIPLE
        binding.listView1.setOnItemClickListener { adapterView, view, index, id ->
            val hodnota = adapterView.getItemAtPosition(index)
            Log.d(TAG, "item click: $index:$hodnota")
        }
    }

    private fun setupListView2() {
        // checked box list view
        // nakup list view
        binding.listView2.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_checked,
            resources.getStringArray(R.array.nakup)
        )
        binding.listView2.setOnItemClickListener { adapterView, view, index, l ->
            val hodnota = adapterView.getItemAtPosition(index)
            (view as CheckedTextView).toggle()

            Log.d(TAG, "check click: $index:$hodnota")
        }
    }
    private fun setupListView3() {
        // beatles list view
        val pairs = listOf(
            mapOf("krstne" to "John","priezv" to "Lennon"),
            mapOf("krstne" to "Ringo","priezv" to "Star"),
            mapOf("krstne" to "Paul","priezv" to "McCartney"),
            mapOf("krstne" to "George","priezv" to "Harrison")
        )
        binding.listView3.adapter = SimpleAdapter(this, pairs,
                android.R.layout.simple_list_item_2,
                arrayOf("krstne", "priezv"),
                arrayOf(android.R.id.text1, android.R.id.text2).toIntArray()
        )
        binding.listView3.setOnItemClickListener { adapterView, view, index, l ->
            val hodnota = adapterView.getItemAtPosition(index)
            Log.d(TAG, "beatles click: $index:$hodnota:${(hodnota as Map<String, String>)["krstne"]}")
        }
    }

}