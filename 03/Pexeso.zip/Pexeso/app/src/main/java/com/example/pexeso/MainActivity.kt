package com.example.pexeso

import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.content.res.AppCompatResources.getDrawable
import androidx.core.content.ContextCompat
import com.example.pexeso.databinding.ActivityMainBinding
import kotlin.random.Random


class MainActivity : AppCompatActivity() {

    val buttons = listOf(
        R.id.button1,
        R.id.button2,
        R.id.button3,
        R.id.button4,
        R.id.button5,
        R.id.button6,
        R.id.button7,
        R.id.button8,
        R.id.button9,
        R.id.button10,
        R.id.button11,
        R.id.button12,
        R.id.button13,
        R.id.button14,
        R.id.button15,
        R.id.button16,
        R.id.button17,
        R.id.button18,
        R.id.button19,
        R.id.button20,
        R.id.button21,
        R.id.button22,
        R.id.button23,
        R.id.button24,
        R.id.button25,
        R.id.button26,
        R.id.button27,
        R.id.button28,
        R.id.button29,
        R.id.button30,
        R.id.button31,
        R.id.button32,
        R.id.button33,
        R.id.button34,
        R.id.button35,
        R.id.button36
    )
    val pikas = listOf(
        R.drawable.img1, R.drawable.img2, R.drawable.img3, R.drawable.img4,
        R.drawable.img5, R.drawable.img6, R.drawable.img7, R.drawable.img8,
        R.drawable.img9, R.drawable.img10, R.drawable.img11, R.drawable.img12,
        R.drawable.img13, R.drawable.img14, R.drawable.img15, R.drawable.img16,
        R.drawable.img17, R.drawable.img18
    )
    private lateinit var binding: ActivityMainBinding
    @SuppressLint("UseCompatLoadingForDrawables")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val rnd = Random
        for (butID in buttons) {
            val button = findViewById<ImageButton>(butID)
            val drawable = getDrawable(pikas[rnd.nextInt(pikas.size)])
            button.maxWidth = 40
            button.maxHeight = 40
            button.background = drawable
            //background = drawable
            //button.background =
            //button.setCompoundDrawables(null, null, null, drawable )
            //button.background =
                //ContextCompat.getDrawable(applicationContext, pikas[rnd.nextInt(pikas.size)])
            //resources.getDrawable(pikas[rnd.nextInt(pikas.size)], null)
        }
    }
    fun onClick(v : View) {
        for((index, butID) in buttons.withIndex()) {
            if (v.id == butID) {
                Log.d("PIKAS", "klikol si na ${index + 1}")
                Toast.makeText(this, "klikol si na ${index + 1}", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
