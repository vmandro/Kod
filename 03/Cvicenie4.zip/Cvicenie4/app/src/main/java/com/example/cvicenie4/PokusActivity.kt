package com.example.cvicenie4

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.util.Log
import com.example.cvicenie4.databinding.ActivityPokusBinding
import com.google.android.material.snackbar.Snackbar

class PokusActivity : AppCompatActivity() {
    val TAG = "POKUS"
    private lateinit var binding : ActivityPokusBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_pokus)
        binding = ActivityPokusBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val cdt = object : CountDownTimer(10000, 1000) {
            override fun onTick(zostavaDoKonca: Long) {
                runOnUiThread() {
                    binding.button2.apply{
                        setText("${zostavaDoKonca / 1000}")
                        textSize = 10*(zostavaDoKonca.toInt() / 1000).toFloat()
                    }
                }
            }
            override fun onFinish() {
                finish()
            }
        }
        binding.button2.setOnClickListener {
            Log.d(TAG, "button click")
            Snackbar.make(it, "button click", Snackbar.LENGTH_LONG)
                .show()
            cdt.start()
        }
    }
}