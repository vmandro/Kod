package com.example.cvicenie4

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.ArrayAdapter
import android.widget.CheckedTextView
import com.example.cvicenie4.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    var SIZE = 8
    lateinit var preferences : SharedPreferences
    private lateinit var binding : ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        preferences = getSharedPreferences("meno", Context.MODE_PRIVATE)
        SIZE = preferences.getInt("SIZE", 8)
        binding.list1.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            arrayOf("button chess", "imageview chess", "edittext chess")
        )
        binding.list1.setOnItemClickListener {adv, v, index, l ->
            Log.d("CHESS", "$index")
            intent.putExtra("kind", index)
            intent.putExtra("SIZE", SIZE)
            startActivity(Intent(this,com.example.cvicenie4.ChessActivity::class.java))
        }
    }
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return true
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.size6 -> SIZE = 6
            R.id.size8 -> SIZE = 8
            R.id.size10 -> SIZE = 10
            else -> super.onOptionsItemSelected(item)
        }
        return true
    }

    override fun onPause() {
        super.onPause()
        val editor = preferences.edit()
        editor.putInt("SIZE", SIZE)
        editor.apply()
    }
}