package com.example.cvicenie4

import android.content.Context
import android.graphics.Color
import android.util.Log
import android.view.ViewGroup
import android.widget.ImageView
import androidx.core.content.ContextCompat
import androidx.core.view.marginLeft

data class ChessImage(val ctx : Context, val row : Int, val col : Int, val black : Boolean) :
    androidx.appcompat.widget.AppCompatImageView(ctx) {

    init {
        this.id = 1000+10*row+col
        this.contentDescription = "$row$col"

        val buttonSize =   resources.getDimension(R.dimen.buttonSize).toInt()
        val bmargin = resources.getDimension(R.dimen.buttonMargin).toInt()
        val marginLayoutParams = ViewGroup.MarginLayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT)
        marginLayoutParams.width = buttonSize
        marginLayoutParams.height = buttonSize
        marginLayoutParams.width = buttonSize
        marginLayoutParams.height = buttonSize
        marginLayoutParams.leftMargin = bmargin
        marginLayoutParams.rightMargin = bmargin
        marginLayoutParams.topMargin = bmargin
        marginLayoutParams.bottomMargin = bmargin
        this.layoutParams = marginLayoutParams

        this.setImageDrawable(
            ContextCompat.getDrawable(ctx,
                if (black) R.drawable.ic_launcher_background else R.drawable.ic_launcher_foreground
            ))
        this.setBackgroundColor(if (black) Color.BLACK else Color.WHITE)
        this.setOnClickListener { v ->
            Log.d("CHESS", "${v.id}")
        }
    }
}