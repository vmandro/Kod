package com.example.cvicenie4

import android.content.Context
import android.graphics.Color
import android.util.Log
import android.view.ViewGroup

data class ChessButton(val ctx : Context, val row : Int, val col : Int, val black : Boolean) :
    androidx.appcompat.widget.AppCompatButton(ctx) {

    init {
        this.id = 1000+10*row+col
        this.text = "$row$col"

        // precitanie z dimens.xml
        val buttonSize =   resources.getDimension(R.dimen.buttonSize).toInt()
        val bmargin = resources.getDimension(R.dimen.buttonMargin).toInt()
        val marginLayoutParams = ViewGroup.MarginLayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT)
        marginLayoutParams.width = buttonSize
        marginLayoutParams.height = buttonSize
        marginLayoutParams.leftMargin = bmargin
        marginLayoutParams.rightMargin = bmargin
        marginLayoutParams.topMargin = bmargin
        marginLayoutParams.bottomMargin = bmargin
        this.layoutParams = marginLayoutParams

        this.setBackgroundColor(if (black) Color.BLACK else Color.WHITE)
        this.setTextColor(if (!black) Color.BLACK else Color.WHITE)

        this.setOnClickListener { v ->
            Log.d("CHESS", "${v.id}")
        }
    }
}