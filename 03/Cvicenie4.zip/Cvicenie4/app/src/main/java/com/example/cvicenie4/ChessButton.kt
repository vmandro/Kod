package com.example.cvicenie4

import android.content.Context
import android.graphics.Color
import android.util.Log
import android.view.ViewGroup
import android.widget.Button

data class ChessButton(
        val ctx : Context,
        val row : Int, val col : Int, val bsize : Int, val black : Boolean) :
        androidx.appcompat.widget.AppCompatButton(ctx) {
    val CHTAG = "CHESS"

    init {
        id = 100*row+col
        text = "$row$col"
        //textSize = 7.toFloat()
        //val buttonSize = resources.getDimension(R.dimen.buttonSize).toInt()
        val marginSize = resources.getDimension(R.dimen.marginSize).toInt()
        val buttonSize = bsize-2*marginSize
        val marginLayoutParams = ViewGroup.MarginLayoutParams (
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        marginLayoutParams.width = buttonSize
        marginLayoutParams.height = buttonSize
        marginLayoutParams.leftMargin = marginSize
        marginLayoutParams.topMargin = marginSize
        marginLayoutParams.bottomMargin = marginSize
        marginLayoutParams.rightMargin = marginSize
        layoutParams = marginLayoutParams
        setBackgroundColor(if (black) Color.BLACK else Color.WHITE)
        setTextColor(if (!black) Color.BLACK else Color.WHITE)
        setOnClickListener {
            Log.d(CHTAG, "klikol si na ${it.id}")
        }
    }
}