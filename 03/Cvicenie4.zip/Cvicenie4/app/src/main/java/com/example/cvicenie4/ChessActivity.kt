package com.example.cvicenie4

import android.os.Bundle
import android.os.PersistableBundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.ViewGroup
import android.widget.GridLayout
import androidx.appcompat.app.AppCompatActivity
import com.example.cvicenie4.databinding.ActivityChessBinding

class ChessActivity : AppCompatActivity() {
    private lateinit var binding : ActivityChessBinding
    var SIZE = 8
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_chess)
        val binding = ActivityChessBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //val bsize = Math.min(window.decorView.width, window.decorView.height)/SIZE
        //val bsize = Math.min(binding.koren.measuredHeight, binding.koren.measuredWidth)/SIZE
        val metrics = resources.displayMetrics
        val bsize = Math.min(metrics.widthPixels,metrics.heightPixels)/SIZE
        Log.d("CHESS", "$bsize")
        val grid = GridLayout(this)

        val marginLayoutParams = ViewGroup.MarginLayoutParams (
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        grid.layoutParams = marginLayoutParams
        grid.columnCount = SIZE
        grid.rowCount = SIZE
        for (row in 0 until SIZE) {
            for (col in 0 until SIZE) {
                grid.addView(ChessButton(this, row, col, bsize, (row+col)%2 == 0))
            }
        }
        binding.koren.addView(grid)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        Log.d("CHESS", "onRestoreInstanceState")
        SIZE = savedInstanceState.getInt("velkost")
    }


    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        Log.d("CHESS", "onSaveInstanceState")
        outState.putInt("velkost", SIZE)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        super.onCreateOptionsMenu(menu)
        menuInflater.inflate(R.menu.menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        super.onOptionsItemSelected(item)
        SIZE = when(item.itemId) {
                    R.id.size6 -> 6
                    R.id.size8 -> 6
                    R.id.size10 -> 10
                    else -> 4
                }
        return true
    }
}