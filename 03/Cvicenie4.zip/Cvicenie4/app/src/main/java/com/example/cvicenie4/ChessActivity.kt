package com.example.cvicenie4

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.PersistableBundle
import android.util.Log
import android.view.ViewGroup
import android.widget.GridLayout
import com.example.cvicenie4.databinding.ActivityChessBinding

class ChessActivity : AppCompatActivity() {
    var SIZE = 8
    private lateinit var binding : ActivityChessBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChessBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val kind = intent.getIntExtra("kind", 0)
        SIZE = intent.getIntExtra("SIZE", 8)
        //val SIZE = 8
        val grid = GridLayout(this)
        grid.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT)

        grid.columnCount = SIZE
        grid.rowCount = SIZE
        for (row in 0 until SIZE) {
            for (col in 0 until SIZE) {
                grid.addView(when(kind) {
                        0 ->    ChessButton(this, row, col, (row + col) % 2 == 1)
                        1 ->    ChessImage(this, row, col, (row + col) % 2 == 1)
                        else -> ChessTv(this, row, col, (row + col) % 2 == 1)
                    })
            }
        }
        val binding =
        binding.ll.addView(grid)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        Log.d("CHESS", "onSavedInstance")
        outState.putInt("VELKOST", SIZE)
    }
    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        Log.d("CHESS", "onRestoreInstance")
        SIZE = savedInstanceState.getInt("VELKOST")
    }
}