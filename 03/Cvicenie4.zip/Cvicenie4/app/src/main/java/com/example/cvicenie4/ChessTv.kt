package com.example.cvicenie4

import android.content.Context
import android.graphics.Color
import android.os.Build
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.EditText

data class ChessTv(val ctx : Context, val row : Int, val col : Int, val black : Boolean) :
    androidx.appcompat.widget.AppCompatEditText(ctx) {

    init {
        this.id = 1000+10*row+col
        this.setText("$row$col")

        // precitanie z dimens.xml
        val buttonSize =   resources.getDimension(R.dimen.buttonSize).toInt()
        val bmargin = resources.getDimension(R.dimen.buttonMargin).toInt()
        val marginLayoutParams = ViewGroup.MarginLayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT)
        marginLayoutParams.width = buttonSize
        marginLayoutParams.height = buttonSize
        marginLayoutParams.leftMargin = bmargin
        marginLayoutParams.rightMargin = bmargin
        marginLayoutParams.topMargin = bmargin
        marginLayoutParams.bottomMargin = bmargin
        this.layoutParams = marginLayoutParams

        this.setBackgroundColor(if (black) Color.BLACK else Color.WHITE)
        this.setTextColor(if (!black) Color.BLACK else Color.WHITE)
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            this.focusable = View.NOT_FOCUSABLE
//        }
        this.setOnClickListener { v ->
            Log.d("CHESS", "${v.id}")
        }
        this.setOnEditorActionListener { v, actionID, event ->
            Log.d("CHESS", "odklepol si hodnotu ${text} v policku ${v.id}, ${actionID}, ${event}")
            true
        }
    }
}