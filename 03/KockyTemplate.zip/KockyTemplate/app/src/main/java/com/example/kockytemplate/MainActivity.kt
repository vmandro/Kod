package com.example.kockytemplate

import android.os.Bundle
import android.os.CountDownTimer
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.kockytemplate.R
import com.example.kockytemplate.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var dice = 0

    //    private var plus = ""
    private val dices = listOf(
        R.drawable.dice1, R.drawable.dice2, R.drawable.dice3,
        R.drawable.dice4, R.drawable.dice5, R.drawable.dice6
    )
//    private val maximum = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.apply {
            imageView.setOnClickListener {
                dice = (1..6).random()
                imageView.animate().apply {
                    duration = 500
                    alpha(0.5f)
                    scaleXBy(-0.9f)
                    scaleYBy(-0.9f)
                }.withEndAction {
                    imageView.setImageDrawable(
                        ContextCompat.getDrawable(applicationContext, dices[dice - 1])
                    )
                    imageView.animate().apply {
                        duration = 500
                        alpha(1f)
                        scaleXBy(0.9f)
                        scaleYBy(0.9f)
                    }
                }
            }
            nextBtn.setOnClickListener {
            }
            newBtn.setOnClickListener {}
        }
    }
    private fun setNextPlayer(delay : Long = 0) {
        object : CountDownTimer(delay, 1000) {
            override fun onTick(millisUntilFinished: Long) { }
            override fun onFinish() {
                dice = 1
                binding.imageView.setImageDrawable(
                    ContextCompat.getDrawable(applicationContext, dices[dice-1]))
            }
        }.start()
    }
}