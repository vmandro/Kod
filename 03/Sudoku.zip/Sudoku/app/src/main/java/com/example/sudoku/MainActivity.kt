package com.example.sudoku

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.GridLayout
import com.example.sudoku.databinding.ActivityMaindynamicBinding
//import com.example.sudoku.databinding.ActivityMainstaticBinding

class MainActivity : AppCompatActivity() {
    //private lateinit var binding : ActivityMainstaticBinding
    private lateinit var binding : ActivityMaindynamicBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //binding = ActivityMainstaticBinding.inflate(layoutInflater) // inflate the layout
        binding = ActivityMaindynamicBinding.inflate(layoutInflater) // inflate the layout
        setContentView(binding.root) // set the content view
        val SIZE = 3

        val bigGrid = GridLayout(this)
        bigGrid.columnCount = SIZE
        bigGrid.rowCount = SIZE
        bigGrid.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT)
        for (rowb in 0 until bigGrid.rowCount) {
            for (colb in 0 until bigGrid.columnCount) {
                val smallGrid = GridLayout(this)
                smallGrid.columnCount = SIZE
                smallGrid.rowCount = SIZE
                val margin = resources.getDimension(R.dimen.boxmargin).toInt()
                val smallGridParams = ViewGroup.MarginLayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT)
                smallGridParams.leftMargin = margin
                smallGridParams.rightMargin = margin
                smallGridParams.topMargin = margin
                smallGridParams.bottomMargin = margin
                smallGrid.layoutParams = smallGridParams

                for (row in 0 until smallGrid.rowCount) {
                    for (col in 0 until smallGrid.columnCount) {
                        val button = Button(this)
                        button.id = 10000 + 3*3*3*rowb + 3*3*row + 3*colb + col
                        button.text = "."
                        val buttonSize = resources.getDimension(R.dimen.buttonSize).toInt()
                        val buttonParams = ViewGroup.MarginLayoutParams(buttonSize,buttonSize)
                        val bmargin = resources.getDimension(R.dimen.buttonmargin).toInt()
                        buttonParams.leftMargin = bmargin
                        buttonParams.rightMargin = bmargin
                        buttonParams.topMargin = bmargin
                        buttonParams.bottomMargin = bmargin
                        button.layoutParams = buttonParams
                        button.setOnClickListener { onClick(it) }
                        smallGrid.addView(button)
                    }
                }
                bigGrid.addView(smallGrid)
            }
        }
        binding.ll.addView(bigGrid)
    }

    fun onClick(v: View) {
        Log.d("SUDOKU", "clicked on ${v.id}")
    }
}