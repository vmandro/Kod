package com.example.cvicenie7

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import androidx.annotation.RequiresApi
import com.example.cvicenie7.databinding.ActivityMainBinding
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    val READ_EXTERNAL_STORAGE_REQUEST_CODE = 777
    val perms = arrayOf(
        android.Manifest.permission.READ_EXTERNAL_STORAGE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //setContentView(R.layout.activity_main)
        if(applicationContext.checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                perms,
                READ_EXTERNAL_STORAGE_REQUEST_CODE)
        }

        Log.i("FOTO", "@@@@")

//        if (savedInstanceState == null) {
//            supportFragmentManager
//                .beginTransaction()
//                .replace(R.id.settings, SettingsFragment())
//                .commit()
//        }
//        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        //button.setOnClickListener {
            hladanieFotiek()
        //}

    }

    //------------------------------------------
    @SuppressLint("SetTextI18n")
    fun hladanieFotiek() {
        Log.i("FOTO", "hladanie fotiek")

        // android:requestLegacyExternalStorage="true"
        val file = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)

        Log.i("FOTO", file.absolutePath)
        val files = file.listFiles()
        if (files != null) {
            Log.i("FOTO", "obrazkov ${files.size}")
            files.forEach { f ->
                if (f != null && f.isFile && f.extension in listOf("jpg", "png")) {
                    Log.i("FOTO", "obrazok ${f.name}")
                    val exif = ExifInterface(f.absolutePath)
                    var details = ""
                    listOf(
                        ExifInterface.TAG_APERTURE_VALUE,
                        ExifInterface.TAG_COMPRESSION,
                        ExifInterface.TAG_EXPOSURE_TIME,
                        ExifInterface.TAG_GPS_LATITUDE,
                        ExifInterface.TAG_GPS_LONGITUDE,
                        ExifInterface.TAG_DATETIME
                    ).forEach {
                        tag -> exif.getAttribute(tag)?.let {
                            details += "${f.name}, $tag=$it"
                        }
                    }
                    Log.i("FOTO", "obrazok ${details}")
                    binding.textView.setText("${binding.textView.text.toString()}$details\\n")
                }
            }
        }


    }
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when(requestCode) {
            READ_EXTERNAL_STORAGE_REQUEST_CODE -> {
                for(i in grantResults.indices) {
                    if(grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                        Log.i("FOTO", "${perms[i]} granted")
                    }
                    else {
                        Log.i("FOTO", "${perms[i]} denied")
                    }
                }
            }
        }
    }
}