package com.example.cvicenie7

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.preference.*

class SettingsFragment : PreferenceFragmentCompat() {
    lateinit var replyList : ListPreference
    lateinit var signatureText : EditTextPreference
    lateinit var sync : SwitchPreferenceCompat
    lateinit var checked : CheckBoxPreference
    val TAG = "PREFS"

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.root_preferences, rootKey)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        replyList = preferenceManager.findPreference<ListPreference>("reply")!!
        replyList.setOnPreferenceChangeListener {
                preference, newValue ->
                Log.d(TAG, "reply changed to ${newValue}")
                true
        }
        signatureText = preferenceManager.findPreference<EditTextPreference>("signature")!!
        signatureText.setOnPreferenceChangeListener {
                preference, newValue ->
            Log.d(TAG, "signature changed to ${newValue}")
            true
        }
        sync = preferenceManager.findPreference<SwitchPreferenceCompat>("sync")!!
        sync.setOnPreferenceChangeListener {
                preference, newValue ->
            Log.d(TAG, "sync changed to ${newValue}")
            true
        }
        checked = preferenceManager.findPreference<CheckBoxPreference>("checkbox")!!
        checked.setOnPreferenceChangeListener {
                preference, newValue ->
            Log.d(TAG, "checked changed to ${newValue}")
            true
        }

        return super.onCreateView(inflater, container, savedInstanceState)
    }
}