package com.example.fragmentpikas

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.*
import android.widget.ImageView
import androidx.fragment.app.Fragment
import com.example.fragmentpikas.databinding.FragmentImageBinding


class FragmentImage : Fragment() {
    var controller: MainActivity? = null
    var container: ViewGroup? = null
    lateinit var iv : ImageView
    private var i = 0
    val TAG = "Fragment"
    private lateinit var binding : FragmentImageBinding
    init {
        Log.i(TAG, "new FragmentImage")
        i = 0
    }
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        Log.i(TAG, "onCreated FragmentImage")
        this.container = container
        setHasOptionsMenu(true)
        binding = FragmentImageBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        Log.i(TAG, "onActivityCreated FragmentImage")
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        Log.i("Canvas", "createOptionMenu")
        inflater.inflate(R.menu.activity_fragmentimage, menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.prev) {
            prevPicture()
            return true
        } else if (item.itemId == R.id.next) {
            nextPicture()
            return true
        } else
            return super.onOptionsItemSelected(item)
    }

    override fun onStart() {
        super.onStart()
        Log.i(TAG, "onStart FragmentImage")
        iv = binding.imageView
        updatePicture()
    }

    fun updatePicture() {
        Log.i(TAG, "update FragmentImage $i")
        if (controller != null) {
            i = i % controller!!.pikas.size
            iv.setImageDrawable(controller!!.pikas[i])
        }
    }
    fun nextPicture() {
        Log.i(TAG, "next FragmentImage")
        if (controller != null)
            i = (i + 1) % controller!!.pikas.size
        updatePicture()
    }

    fun prevPicture() {
        Log.i(TAG, "prev FragmentImage")
        if (controller != null) {
            i--
            if (i < 0)
                i = controller!!.pikas.size - 1
        }
        updatePicture()
    }
    override fun onAttach(activity: Activity) {
        super.onAttach(activity)
        Log.i(TAG, "onAttach FragmentImage")
        controller = activity as MainActivity
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        Log.i(TAG, "onAttach FragmentImage")
        controller = activity as MainActivity
    }
}
