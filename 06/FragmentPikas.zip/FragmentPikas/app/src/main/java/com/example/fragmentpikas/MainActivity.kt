package com.example.fragmentpikas

import android.graphics.drawable.Drawable
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import com.example.fragmentpikas.databinding.ActivityFragmentBinding

class MainActivity : FragmentActivity(), FragmentButtons.Updater    {
    private lateinit var binding: ActivityFragmentBinding
    lateinit var fr1: FragmentButtons
    lateinit var fr2: FragmentImage
    var pikas = ArrayList<Drawable>()
    val TAG = "Fragment"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i(TAG, "onCreate in FragmentActivity")
        binding = ActivityFragmentBinding.inflate(layoutInflater)
        //setContentView(R.layout.activity_fragment)
        setContentView(binding.root)
        pikas.add(resources.getDrawable(R.drawable.pika) as Drawable)
        pikas.add(resources.getDrawable(R.drawable.pok0) as Drawable)
        pikas.add(resources.getDrawable(R.drawable.pok1) as Drawable)
        pikas.add(resources.getDrawable(R.drawable.pok2) as Drawable)
        pikas.add(resources.getDrawable(R.drawable.pok3) as Drawable)
        pikas.add(resources.getDrawable(R.drawable.pok4) as Drawable)

        fr2 = FragmentImage()
        fr1 = FragmentButtons()
        binding.fragment1Btn.setOnClickListener {
            Log.i(TAG, "open Fragment 1")
            val fm = supportFragmentManager
            val fragmentTransaction = fm.beginTransaction()
            fragmentTransaction.replace(R.id.fragment_place, fr1)
                                // .add(R.id.fragment_place, fr1);
                                //.addToBackStack(null)
                                .commit()
        }
        binding.fragment2Btn.setOnClickListener {
            Log.i(TAG, "open Fragment 2")
            val fm = supportFragmentManager
            val fragmentTransaction = fm.beginTransaction()
            fragmentTransaction.replace(R.id.fragment_place, fr2)
            //fragmentTransaction.addToBackStack(null)
            fragmentTransaction.commit()
        }
    }

    override fun onAttachFragment(fragment: Fragment) {
        super.onAttachFragment(fragment)
        Log.i(TAG, "onAttachFragemnt in FragmentActivity " + fragment.javaClass.name)
    }

    override fun onResume() {
        super.onResume()
        Log.i(TAG, "onResume in FragmentActivity")
    }

    override fun onStart() {
        super.onStart()
        Log.i(TAG, "onStart in FragmentActivity")
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
    }

    override fun quit() {
        Log.i(TAG, "quit in FragmentActivity")
        finish()
    }

    override fun next() {
        Log.i(TAG, "next in FragmentActivity")
        fr2.nextPicture()
    }

    override fun prev() {
        Log.i(TAG, "prev in FragmentActivity")
        fr2.prevPicture()
    }
}
