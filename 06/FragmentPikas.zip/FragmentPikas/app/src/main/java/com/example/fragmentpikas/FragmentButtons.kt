package com.example.fragmentpikas

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.fragmentpikas.databinding.FragmentButtonsBinding

class FragmentButtons : Fragment() {
    interface Updater {
        fun quit()
        fun next()
        fun prev()
    }
    //lateinit var controller: MainActivity
    lateinit var controller: Updater
    private var container: ViewGroup? = null
    val TAG = "Fragment"
//    private var _binding: FragmentButtonsBinding? = null
//    private val binding get() = _binding!!

    private lateinit var binding : FragmentButtonsBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        Log.i(TAG, "onCreated in FragmentButtons")
        this.container = container
        //return inflater.inflate(R.layout.fragment_buttons, container, false)
//        _binding = FragmentButtonsBinding.inflate(inflater, container, false)
        binding = FragmentButtonsBinding.inflate(inflater, container, false)
        return binding.root
    }

//    override fun onAttach(activity: Activity) {
//        super.onAttach(activity)
//        Log.i(TAG, "onAttach in FragmentButtons")
//        controller = activity as MainActivity
//    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        Log.i(TAG, "onAttach in FragmentButtons")
        controller = context as Updater
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        Log.i(TAG, "onActivityCreated in FragmentButtons")
    }

    init {
        Log.i(TAG, "new of FragmentButtons")
    }

    override fun onStart() {
        super.onStart()
        Log.i(TAG, "onStart in FragmentButtons")
        binding.prevBtn.setOnClickListener { controller.prev() }
        binding.nextBtn.setOnClickListener { controller.next() }
        binding.quitBtn.setOnClickListener { controller.quit() }
    }

    override fun onResume() {
        super.onResume()
        Log.i(TAG, "onResume in FragmentButtons")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        Log.i(TAG, "onSaveInstance in FragmentButtons")
    }

    override fun onDetach() {
        super.onDetach()
        Log.i(TAG, "onDetach in FragmentButtons")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i(TAG, "onDestroy in FragmentButtons")
    }
}
