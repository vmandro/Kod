package com.example.fragmentdialog

import android.app.Activity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.DialogFragment

class YesNoDialog : DialogFragment() {
    lateinit var updater : Updater

    override fun onAttach(activity: Activity) {
        super.onAttach(activity)
        updater = activity as Updater
    }

    override fun onCreateView(inflater: LayoutInflater,
                              container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        isCancelable = false   // neda sa zrusit dialog
        val view = inflater.inflate(R.layout.yes_no_layout, container, false)
        //yesBtn
        (view.findViewById(R.id.yesBtn) as Button)
                .setOnClickListener {
                    updater.sendMessage("yes pressed")
                    dismiss()  // zmizne dialog
                }
        //NoBtn
        (view.findViewById(R.id.NoBtn) as Button)
                .setOnClickListener {
                    updater.sendMessage("no pressed")
                    dismiss()  // zmizne dialog
                }
        return view
    }
    interface Updater {
        fun sendMessage(msg: String)
    }
}
