package com.example.fragmentdialog

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity(), YesNoDialog.Updater {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inFlater = menuInflater
        inFlater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.StartID -> {
                val builder = AlertDialog.Builder(this@MainActivity)
                builder.setTitle("Ano či nie ?")
                        .setMessage("Do you really want to start ?")
                        .setIcon(R.mipmap.ic_launcher_round)
                        .setCancelable(false)
                        .setPositiveButton(R.string.yesText) { dialogInterface, i -> Toast.makeText(this@MainActivity, "Start it", Toast.LENGTH_SHORT).show() }
                        .setNegativeButton(R.string.noText) { dialogInterface, i -> Toast.makeText(this@MainActivity, "DO NOT Start it", Toast.LENGTH_SHORT).show() }
                        .setNeutralButton(R.string.whoKnowsText) { dialogInterface, i -> Toast.makeText(this@MainActivity, "DO NOTHING", Toast.LENGTH_SHORT).show() }
                val alertDialog = builder.create()
                alertDialog.show()
                return true
            }
            R.id.StopID -> {
                YesNoDialog().show(supportFragmentManager, "Yes or No ?")
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun sendMessage(msg: String) {
        if (msg == "yes pressed")
            this@MainActivity.finish()
    }
}
