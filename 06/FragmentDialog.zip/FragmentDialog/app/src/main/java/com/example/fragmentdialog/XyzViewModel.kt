package com.example.fragmentdialog

import androidx.lifecycle.ViewModel

class XyzViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}