package com.example.fragmentlifecycle

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment

class BlankFragment : Fragment() {
    private val TAG = "Life"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i(TAG, "onCreate in fragment")
        savedInstanceState?.getString("frkey", "value")
        savedInstanceState?.getInt("frscore", 123)
        savedInstanceState?.getLong("frtime", 123456L)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        Log.i(TAG, "onCreateView in fragment")
        return inflater.inflate(R.layout.fragment_blank, container, false)
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        Log.i(TAG, "onAttach in fragment")
    }

//    override fun onAttach(activity: Activity) {
//        super.onAttach(activity)
//        Log.i(TAG, "onAttachActivity in fragment")
//    }

    override fun onDetach() {
        super.onDetach()
        Log.i(TAG, "onDetach in fragment")
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        Log.i(TAG, "onActivityCreated in fragment")
    }

    override fun onStart() {
        super.onStart()
        Log.i(TAG, "onStart in fragment")
    }

    override fun onResume() {
        super.onResume()
        Log.i(TAG, "onResume in fragment")
    }

    override fun onPause() {
        super.onPause()
        Log.i(TAG, "onPause in fragment")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        Log.i(TAG, "onSaveInstance in fragment")
        outState.putString("frkey", "value")
        outState.putInt("frscore", 123)
        outState.putLong("frtime", 123456L)
    }

    override fun onStop() {
        super.onStop()
        Log.i(TAG, "onStop in fragment")
    }

    override fun onDestroyView() {
        super.onDestroyView()
        Log.i(TAG, "onDestroyedView in fragment")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i(TAG, "onDestroy in fragment")
    }
}
