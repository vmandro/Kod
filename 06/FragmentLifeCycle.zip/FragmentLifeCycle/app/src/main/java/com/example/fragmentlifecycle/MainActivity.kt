package com.example.fragmentlifecycle

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity

class MainActivity : FragmentActivity() {
    private val TAG = "Life"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.e(TAG, "onCreate in Activity")
        setContentView(R.layout.activity_main)
        savedInstanceState?.getString("key", "value")
        savedInstanceState?.getInt("score", 123)
        savedInstanceState?.getLong("time", 123456L)

    }
    override fun onStart() {
        super.onStart()
        Log.e(TAG, "onStart in Activity")
    }

    override fun onAttachFragment(fragment: Fragment) {
        super.onAttachFragment(fragment)
        Log.e(TAG, "onAttachFragment in Activity")
    }
    override fun onResume() {
        super.onResume()
        Log.e(TAG, "onResume in Activity")
    }
    override fun onDestroy() {
        super.onDestroy()
        Log.e(TAG, "onDestroy in Activity")
    }
    override fun onStop() {
        super.onStop()
        Log.e(TAG, "onStop in Activity")
    }
    override fun onPause() {
        super.onPause()
        Log.e(TAG, "onPause in Activity")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        Log.e(TAG, "onSaveInstance in Activity")
        outState.putString("key", "value")
        outState.putInt("score", 123)
        outState.putLong("time", 123456L)
    }
}
