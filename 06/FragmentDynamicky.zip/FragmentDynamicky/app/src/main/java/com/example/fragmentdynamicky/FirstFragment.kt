package com.example.fragmentdynamicky
import android.app.Activity
import androidx.fragment.app.Fragment
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.fragmentdynamicky.databinding.FragmentFirstBinding


class FirstFragment : Fragment() {
    lateinit var mainActivity: Updater
    private var state = 0
    private lateinit var binding: FragmentFirstBinding

    interface Updater {
        fun update(s: String)    // medzi aktivitami chceme posielat string
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        binding = FragmentFirstBinding.inflate(inflater, container, false)
        return binding.root
        //return inflater.inflate(R.layout.fragment_first, container, false)
    }

    // deprecated in API level 23
    override fun onAttach(act: Activity) {
        super.onAttach(act)
        state = arguments?.getInt("init", 0)?:0
        mainActivity = act as Updater
    }

    // from in API level 23
    override fun onAttach(context: Context) {
        super.onAttach(context)
        state = arguments?.getInt("init", 0)?:0
        mainActivity = context as Updater
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        binding.button.setOnClickListener { mainActivity.update("state:" + state++) }
    }

    override fun onDetach() {
        super.onDetach()
        //mainActivity = null
    }
}
