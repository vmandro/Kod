package com.example.fragmentdynamicky

import androidx.fragment.app.Fragment
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.example.fragmentdynamicky.databinding.FragmentSecondBinding

class SecondFragment : Fragment() {
    lateinit var mainActivity: MainActivity
    private lateinit var binding: FragmentSecondBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        //return inflater.inflate(R.layout.fragment_second, container, false)
        binding = FragmentSecondBinding.inflate(inflater, container, false)
        return binding.root
    }
    fun setFText(s: String) {
        binding.largeTextView.text = s
    }
    override fun onAttach(context: Context) {
        super.onAttach(context)
        mainActivity = context as MainActivity
    }
}
