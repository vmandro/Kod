package com.example.fragmentdynamicky

import android.os.Bundle
import androidx.fragment.app.FragmentActivity
import com.example.fragmentdynamicky.databinding.ActivityMainBinding


/* prva moznost
interface Updater {
    public void update(String s);   // medzi aktivitami chceme posielat string
}
*/

class MainActivity : FragmentActivity(), FirstFragment.Updater {
    private lateinit var binding: ActivityMainBinding
    override fun update(s: String) {
        binding.textView.text = s
//        val sfr = supportFragmentManager.findFragmentById(R.id.frameLayout2) as SecondFragment
//        sfr.setFText(s)
        val sfr1 = supportFragmentManager.findFragmentByTag("tag2") as SecondFragment
        sfr1.setFText(s)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //setContentView(R.layout.activity_main)
        val firstFragment = FirstFragment()
        val bundle = Bundle()
        bundle.putInt("init", 10)
        firstFragment.arguments = bundle
        val ft = supportFragmentManager.beginTransaction()
        ft.apply {
            add(R.id.frameLayout1, firstFragment, "tag1")
//            replace(R.id.frameLayout1, firstFragment, "tag1")
//            remove(firstFragment)
            add(R.id.frameLayout2, SecondFragment(), "tag2")
            commit()
        }
    }
}
