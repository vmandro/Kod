package com.example.fragmentstaticky

import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity()
        , BlankFragment1.OnFragmentInteractionListener {
    override fun onFragmentInteraction(uri: Uri) {  TODO()  }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)  // vytvorenie activity, ktora staticky
        // obsahuje dva fragmenty
        //val bf = BlankFragment1.newInstance("a", "b")
    }
}
