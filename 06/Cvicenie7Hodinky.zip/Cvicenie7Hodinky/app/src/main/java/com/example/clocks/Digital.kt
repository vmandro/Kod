package com.example.clocks

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Digital : Fragment() {
    private lateinit var textDigitalClock: TextView
    private lateinit var buttonSyncDigital: Button
    private val handler = Handler(Looper.getMainLooper())
    private var currentTime = System.currentTimeMillis()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_digital, container, false)
        textDigitalClock = view.findViewById(R.id.textDigital)
        buttonSyncDigital = view.findViewById(R.id.buttonSyncDigital)
        buttonSyncDigital.setOnClickListener {
            (activity as MainActivity).syncTimeFromDigital(currentTime)
        }

        return view
    }

    override fun onResume() {
        super.onResume()
    }

    override fun onPause() {
        super.onPause()
    }

    private fun updateTime() {
    }

    fun syncTime(time: Long) {
    }

    companion object {
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            Digital().apply {
                arguments = Bundle()
            }
    }
}