package com.example.cvicenie7hodinky

import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.cvicenie7hodinky.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var digitalClockFragment: Digital
    private lateinit var analogClockFragment: Analog

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        digitalClockFragment = Digital()
        analogClockFragment = Analog()
        supportFragmentManager.beginTransaction()
            .add(R.id.fragmentContainerView, digitalClockFragment)
            .add(R.id.fragmentContainerView2, analogClockFragment)
            .commit()

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        binding.sync.setOnClickListener {
            Log.i("HODINKY", "analog/digital Sync button clicked")
            syncToCurrentTime()
        }
    }

    private fun syncToCurrentTime() {
        val currentTime = System.currentTimeMillis()
        digitalClockFragment.syncTime(currentTime)
        analogClockFragment.syncTime(currentTime)
    }

    fun syncTimeFromDigital(time: Long) {
        analogClockFragment.syncTime(time)
    }

    fun syncTimeFromAnalog(time: Long) {
        digitalClockFragment.syncTime(time)
    }

}