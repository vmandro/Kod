package com.example.clocks

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import java.util.Calendar

class AnalogView(context: Context, attrs: AttributeSet?) : View(context, attrs) {


    private var timeInMillis: Long = System.currentTimeMillis()

    override fun onDraw(canvas: Canvas) {
    }

    fun updateTime(time: Long) {
        timeInMillis = time
        invalidate()
    }
}