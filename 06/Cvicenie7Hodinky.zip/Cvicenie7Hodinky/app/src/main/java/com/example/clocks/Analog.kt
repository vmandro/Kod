package com.example.clocks

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import com.example.clocks.databinding.ActivityMainBinding

class Analog : Fragment() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var analogClockView: AnalogView
    private lateinit var buttonSyncAnalog: Button
    private val handler = Handler(Looper.getMainLooper())
    private var currentTime = System.currentTimeMillis()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_analog, container, false)
        analogClockView = view.findViewById(R.id.analogView)
        buttonSyncAnalog = view.findViewById(R.id.buttonSyncAnalog)
        buttonSyncAnalog.setOnClickListener {
            (activity as MainActivity).syncTimeFromAnalog(currentTime)
        }
        return view
    }

    override fun onResume() {
        super.onResume()
    }

    override fun onPause() {
        super.onPause()
    }

    private fun updateAnalogClock() {
    }

    fun syncTime(time: Long) {
        currentTime = time
    }

    companion object {
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            Analog().apply {
                arguments = Bundle()
            }
    }
}