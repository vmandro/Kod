package com.example.fragmentcourses
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioGroup
import androidx.fragment.app.Fragment
import com.example.fragmentcourses.databinding.FragmentListBinding

class ListFragment : Fragment(), RadioGroup.OnCheckedChangeListener {
    private val TAG = "Course"
    internal interface Updater {
        fun update(selectedIndex: Int)
    }
    override fun onCheckedChanged(group: RadioGroup, checkedId: Int) {
        var selectedIndex = -1
        when (checkedId) {
            R.id.prog1ID -> selectedIndex = 0
            R.id.prog2ID -> selectedIndex = 1
            R.id.prog3ID -> selectedIndex = 2
            R.id.prog4ID -> selectedIndex = 3
            R.id.prog5ID -> selectedIndex = 4
            R.id.adsID   -> selectedIndex = 5
        }
        val listener = activity as Updater
        listener.update(selectedIndex)
    }
    private lateinit var binding: FragmentListBinding
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        Log.d(TAG, "onCreateView")
        binding = FragmentListBinding.inflate(inflater, container, false)
        binding.selectGroup.setOnCheckedChangeListener(this)
        return binding.root
    }
}
