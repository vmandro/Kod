package com.example.fragmentcourses

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.example.fragmentcourses.databinding.ActivityDescriptionBinding

class DescriptionActivity : AppCompatActivity() {
    private val TAG = "Course"
    private lateinit var binding : ActivityDescriptionBinding
    private var index = -1
    override fun onCreate(savedInstanceState: Bundle?) {
        Log.i(TAG, "onCreate in DescriptionActivity")
        super.onCreate(savedInstanceState)
        binding = ActivityDescriptionBinding.inflate(layoutInflater)
        setContentView(binding.root)
        index = intent.getIntExtra("selectedIndex", -1)
    }
    override fun onResume() {
        super.onResume()
        val descriptionFragment = supportFragmentManager.findFragmentById(R.id.fragmentDescription) as DescriptionFragment
        descriptionFragment.setDetail(index)
    }
}
