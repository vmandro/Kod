package com.example.fragmentcourses

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.fragmentcourses.databinding.FragmentDescriptionBinding

class DescriptionFragment : Fragment() {
    private var _binding : FragmentDescriptionBinding? = null
    private val binding get() = _binding!!
    private val TAG = "Course"

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {
        Log.i(TAG, "onCreateView in DescriptionFragment")
        _binding = FragmentDescriptionBinding.inflate(inflater, container, false)
        return binding.root
    }

    fun setDetail(index: Int) {
        Log.i(TAG, "setDetail in DescriptionFragment $index")
        val descriptions = resources.getStringArray(R.array.course_full_descriptions)
        binding.descriptionID.text = descriptions[index]
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}
