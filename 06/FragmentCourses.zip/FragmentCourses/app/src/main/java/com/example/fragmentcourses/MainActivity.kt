package com.example.fragmentcourses

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity(), ListFragment.Updater {
    private var mCreating = true
    private val TAG = "Course"

    override fun update(selectedIndex: Int) {
        Log.i(TAG, "update $selectedIndex")
        val descriptionFragment = supportFragmentManager.findFragmentById(R.id.fragmentDescription)
                as? DescriptionFragment
        if ((descriptionFragment == null) || !descriptionFragment.isVisible) {
            if (!mCreating) {
                val intent = Intent(this, DescriptionActivity::class.java)
                intent.putExtra("selectedIndex", selectedIndex)
                startActivity(intent)
            }
        } else {
            descriptionFragment.setDetail(selectedIndex)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Log.i(TAG, "onCreate in MainActivity")
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity__main)
    }

    override fun onResume() {
        super.onResume()
        mCreating = false
    }
}
