package com.example.fragmentslider

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SeekBar
import androidx.fragment.app.Fragment
import com.example.fragmentslider.databinding.FragmentSlajderBinding
import java.lang.ClassCastException

class SlajderFragment : Fragment() {
    var slajder = 50

    private lateinit var binding: FragmentSlajderBinding

    interface Listener {
        fun onButtonClick(postion: Int, text : String)
    }
    lateinit var activityCallBack : Listener
    override fun onAttach(context: Context) {
        super.onAttach(context)
        try {
            activityCallBack = context as Listener
        } catch (e : ClassCastException) {
            throw ClassCastException(context.toString() + " does not implement Listener")
        }
    }
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
//        val view = inflater.inflate(R.layout.fragment_slajder,
//                                    container,
//                                    false)
//        return view
        binding = FragmentSlajderBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.apply {
            seekBar.setProgress(slajder)
            seekBar.setOnSeekBarChangeListener(
                object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                        slajder = progress
                    }

                    override fun onStartTrackingTouch(p0: SeekBar?) {}
                    override fun onStopTrackingTouch(p0: SeekBar?) {}
                }
            )
            button.setOnClickListener { v ->
                activityCallBack.onButtonClick(
                    slajder,
                    editText.text.toString()
                )
            }
        }
    }
}