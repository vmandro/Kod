package com.example.fragmentslider

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.fragmentslider.databinding.FragmentTextBinding

class TextViewFragment : Fragment() {
    private lateinit var binding: FragmentTextBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
//        return inflater.inflate(R.layout.fragment_text,
//            container,
//            false)

        binding = FragmentTextBinding.inflate(inflater, container, false)
        return binding.root

    }
    fun changeText(fontsize : Int, text : String) {
        binding.textView.textSize = fontsize.toFloat()
        binding.textView.text = text
    }
}