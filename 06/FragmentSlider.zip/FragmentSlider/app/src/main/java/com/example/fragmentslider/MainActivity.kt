package com.example.fragmentslider

import android.os.Bundle
import androidx.fragment.app.FragmentActivity
import com.example.fragmentslider.databinding.ActivityMainBinding
import com.example.fragmentslider.databinding.FragmentSlajderBinding

class MainActivity : FragmentActivity(), SlajderFragment.Listener {
    lateinit var binding : ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //binding = ActivityMainBinding.inflate(layoutInflater)
        //setContentView(binding.root)
    }

    override fun onButtonClick(fontSize: Int, text: String) {
        val textViewFragment =
            supportFragmentManager.findFragmentById(R.id.fragmentTextView) as TextViewFragment
        //binding.fragmentTextView
        textViewFragment.changeText(5*fontSize, text)
    }
}