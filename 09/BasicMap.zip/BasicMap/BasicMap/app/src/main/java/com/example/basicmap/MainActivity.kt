package com.example.basicmap

import android.graphics.drawable.BitmapDrawable
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.mapbox.geojson.Point
import com.mapbox.maps.MapView
import com.mapbox.maps.MapboxMap
import com.mapbox.maps.Style
import com.mapbox.maps.plugin.annotation.AnnotationPlugin
import com.mapbox.maps.plugin.annotation.annotations
import com.mapbox.maps.plugin.annotation.generated.PointAnnotationOptions
import com.mapbox.maps.plugin.annotation.generated.createPointAnnotationManager
import com.mapbox.maps.plugin.gestures.addOnMapClickListener
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var mapView: MapView
    private lateinit var mapboxMap: MapboxMap
    private lateinit var annotationPlugin: AnnotationPlugin

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mapView = findViewById(R.id.mapView)
        mapboxMap = mapView.getMapboxMap()

        mapboxMap.loadStyleUri(Style.OUTDOORS)

        annotationPlugin = mapView.annotations

        val pointManager = annotationPlugin.createPointAnnotationManager()
        val icon = (resources.getDrawable(R.drawable.red_marker) as BitmapDrawable).bitmap

        val pointOptions = PointAnnotationOptions()
            .withPoint(Point.fromLngLat(17.1722, 48.1682))
            .withIconImage(icon)
        pointManager.create(pointOptions)

        val elevationJsonName = "srtm_parsed.json"
        val elevationDataString = application.assets.open(elevationJsonName).bufferedReader().use{
            it.readText()
        }
        val elevationJson = JSONObject(elevationDataString)

        mapboxMap.addOnMapClickListener{p ->
            val clickedPointOtions = PointAnnotationOptions()
                .withPoint(Point.fromLngLat(p.longitude(), p.latitude()))
                .withIconImage(icon)

            pointManager.create(clickedPointOtions)

            val lng = floorToSeconds(p.longitude())
            val lat = floorToSeconds(p.latitude())

            val elevation:String = if(elevationJson.has(lng) && elevationJson.getJSONObject(lng).has(lat)){
                elevationJson.getJSONObject(lng).get(lat).toString()
            }else{
                "No elevation data"
            }

            Toast.makeText(this, "$lng $lat $elevation", Toast.LENGTH_SHORT).show()

            true
        }
    }

    fun floorToSeconds(i: Double):String{
        val h = i.toInt()
        val m = (i-h.toFloat())*60
        val s = (m-m.toInt())*60

        val resString = (h+m.toInt()/60f+s.toInt()/60f/60f).toString()
        return resString.substring(0, minOf(7, resString.length))
    }
}