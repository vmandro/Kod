Treba zmenit:
- strings.xml: <string name="mapbox_access_token">your public key</string>
- gradle.properties: MAPBOX_DOWNLOADS_TOKEN=your secret key