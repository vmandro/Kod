package com.example.cvicenie09

import android.os.Bundle
import android.os.PersistableBundle
import android.preference.PreferenceActivity

@Suppress("DEPRECATION")
class SettingActivity : PreferenceActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        addPreferencesFromResource(R.xml.settings)
    }
}