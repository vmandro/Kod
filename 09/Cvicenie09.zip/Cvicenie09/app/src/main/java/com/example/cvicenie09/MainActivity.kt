package com.example.cvicenie09

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.*
import android.content.pm.PackageManager
import android.location.Criteria
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.wifi.WifiManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.preference.PreferenceManager.getDefaultSharedPreferences
import android.telephony.SmsManager
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.annotation.RequiresApi
import kotlinx.android.synthetic.main.activity_main.*
import java.lang.Exception
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() , LocationListener {
    val TAG = "SOS"
    // callback codes
    val REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS = 777
    // GPS
    lateinit var lm : LocationManager
    lateinit var provider : String
    lateinit var lastLocation : Location
    // WiFi
    lateinit var wifiManager : WifiManager

    // -- wifi broadcast receiver
    val broadcastReceiver = object : BroadcastReceiver () {
        override fun onReceive(context: Context?, intent: Intent?) {
              val scanList = wifiManager.scanResults
              wifiTV.text = scanList
                  .map { it.SSID }
                  .filter { it.isNotEmpty() }
                  .toSet()
                  .joinToString (separator = ", ")
        }
    }

    // shared preferences
    lateinit var sharedPrefs : SharedPreferences
    val userNameSPKey = "username"
    val userNameSPDefaultValue = "NULL"

    val phoneNumberSPKey = "phonenumber"
    val phoneNumberSPDefaultValue = "123"

    val useWifiSPKey = "useWifi"
    val useGPSSPKey = "useGPS"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // ----- Preferences & Settings
        sharedPrefs = getDefaultSharedPreferences(this)

        // ----- permissions
        addPermissions()

        // ----- GPS
        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        provider = LocationManager.GPS_PROVIDER
        displayPreferences()

        // ----- WIFI
        if (sharedPrefs.getBoolean(useWifiSPKey, true)) {
            wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            if (!wifiManager.isWifiEnabled) {
                wifiManager.isWifiEnabled = true
            }
            registerReceiver(broadcastReceiver, IntentFilter(
                WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)
            )
        }

    }

    // Setting menu ------------------------------
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.settings, menu)
        return true
    }
    val RESULT_SETTINGS = 999
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // start activity SettingActivity. .................
        when (item.itemId) {
            R.id.menu_settings -> {
                val i = Intent(this, SettingActivity::class.java)
                startActivityForResult(i, RESULT_SETTINGS)
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            // result from settings ...
            RESULT_SETTINGS -> {
                displayPreferences()
            }
            // result from pick contacts ...
        }
    }

    fun displayPreferences() {
        sharedPrefs = getDefaultSharedPreferences(this)
        val uname = sharedPrefs.getString(userNameSPKey, userNameSPDefaultValue)
        val pnumber = sharedPrefs.getString(phoneNumberSPKey, phoneNumberSPDefaultValue)
        iceTV.text = "ICE: $uname/$pnumber"
        scanWifiBtn.visibility = if (sharedPrefs.getBoolean(useWifiSPKey, true)) View.VISIBLE else View.GONE
        setupLocationManager()
        locateGpsBtn.text = provider
    }
    @SuppressLint("MissingPermission")
    fun setupLocationManager() {
        val criteria = Criteria()
        criteria.isAltitudeRequired = false
        criteria.accuracy = Criteria.ACCURACY_COARSE
        criteria.powerRequirement = Criteria.POWER_LOW
        criteria.isBearingRequired = false
        criteria.isSpeedRequired = false
        if (sharedPrefs.getBoolean(useGPSSPKey, true)) {
            provider = LocationManager.GPS_PROVIDER
        } else {
            provider = lm.getBestProvider(criteria, false) ?: LocationManager.GPS_PROVIDER
        }
        if (!lm.isProviderEnabled(provider)) {
            val gpsSettingIntent =
                Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            startActivity(gpsSettingIntent)
        }
        try {
            val loc = lm.getLastKnownLocation(provider)
            if (loc != null)
                lastLocation = loc
            Log.d(TAG, "$lastLocation")
        } catch (e: Exception) {
            Log.e(TAG, e.toString())
        }

    }
    // --- permissions
    private val permissions = mapOf(
        "GPS-F" to Manifest.permission.ACCESS_FINE_LOCATION,
        "SMS"   to Manifest.permission.SEND_SMS,
        "WIFI1" to Manifest.permission.ACCESS_WIFI_STATE,
        "WIFI2" to Manifest.permission.CHANGE_NETWORK_STATE,
        "INTERNET" to Manifest.permission.INTERNET
    )

    private fun addPermissions() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return

        val permissionList = mutableListOf<String>()
        val permissionNeeded = mutableListOf<String>()
        for ((pname, pvalue) in permissions) {
            if (addPermission(permissionList, pvalue))
                permissionNeeded.add(pname)
        }
        if (permissionList.size > 0) {
            if (permissionNeeded.size > 0) {
                showMessageOKCancel(
                    "You need to grant access to: ${permissionNeeded.joinToString(separator = ", ")}",
                    DialogInterface.OnClickListener { dialog, which ->
                        requestPermissions(permissionList.toTypedArray<String>(),
                            REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS)
                    })
                return

            }
        }
    }
    private fun showMessageOKCancel(message: String, okListener: DialogInterface.OnClickListener) {
        AlertDialog.Builder(this@MainActivity)
            .setMessage(message)
            .setPositiveButton("OK", okListener)
            .setNegativeButton("Cancel", null)
            .create()
            .show()
    }
    @RequiresApi(Build.VERSION_CODES.M)
    private fun addPermission(
        permissionsList: MutableList<String>,
        permission: String
    ): Boolean {
        if (applicationContext.checkSelfPermission(permission)
            != PackageManager.PERMISSION_GRANTED) {
            permissionsList.add(permission)
            if (!shouldShowRequestPermissionRationale(permission)) return true
        }
        return false
    }

    // ---- GPS
    fun Location.display() {
       lastLocationTV.text = "${"%.4f".format(latitude)}, ${"%.4f".format(longitude)}/$provider"
    }
    override fun onLocationChanged(loc: Location) {
        lastLocation = loc
        Log.d(TAG, "onLocationChanged:$loc")
        lastLocation.display()
    }
    override fun onProviderDisabled(arg0: String) {
        Log.d(TAG, "onProviderDisabled:$arg0")
    }

    override fun onProviderEnabled(arg0: String) {
        Log.d(TAG, "onProviderEnabled:$arg0")
    }

    override fun onStatusChanged(arg0: String, arg1: Int, arg2: Bundle) {
        Log.d(TAG, "onStatusChanged")
    }
    // --- activity life cycle
    @SuppressLint("MissingPermission")
    override fun onResume() {
        super.onResume()
        lm.requestLocationUpdates(provider, 2000, 10f, this)
    }
    override fun onPause() {
        super.onPause()
        lm.removeUpdates(this)
    }

    // UI onClickListeners
    // --- SMS
    fun sendSmsClicked(v : View) {
        val smsManager = SmsManager.getDefault()
        sharedPrefs = getDefaultSharedPreferences(this)
        val uname = sharedPrefs.getString(userNameSPKey, userNameSPDefaultValue)
        val pnumber = sharedPrefs.getString(phoneNumberSPKey, phoneNumberSPDefaultValue)
        repeat ((sharedPrefs.getString("repCount", "0")?:"0").toInt()) {
            val message = "$it...Ahoj $uname, moja poloha " +
                    "v case ${getCurrentDateTime().toString("yyyy/MM/dd HH:mm:ss")} " +
                    "je: ${lastLocation.latitude}, ${lastLocation.longitude}"
            smsManager.sendTextMessage(pnumber, null, message, null, null)
        }
    }
    // --- GPS
    @SuppressLint("MissingPermission")
    fun gpsClicked(v : View) {
        val loc = lm.getLastKnownLocation(provider)
        Toast.makeText(this@MainActivity, loc.toString(), Toast.LENGTH_SHORT).show()
        if (loc != null) {
            lastLocation = loc
            lastLocation.display()
        }
    }
    // --- WiFi
    fun scanWifiClicked(v : View) {
        wifiManager.startScan()
    }
    // --- Contact Picker
    fun contactPickerClicked(v : View) {

    }
    // Utils - co fakt nechcete objavovat znova...
    // praca s datumom a casom
    fun Date.toString(format: String, locale: Locale = Locale.getDefault()): String {
        val formatter = SimpleDateFormat(format, locale)
        return formatter.format(this)
    }

    fun getCurrentDateTime(): Date {
        return Calendar.getInstance().time
    }
}