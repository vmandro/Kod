package com.example.gmap

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Criteria
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContextCompat
import android.location.LocationListener
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.example.gmap.databinding.ActivityMapsBinding
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.api.GoogleApiClient
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.CircleOptions
import com.google.android.gms.maps.model.Polyline
import com.google.android.gms.maps.model.PolylineOptions

import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationServices
import java.util.Locale


class MapsActivityWithGoogleAPI : AppCompatActivity(),
    OnMapReadyCallback,
//    GoogleApiClient.ConnectionCallbacks,
//    GoogleApiClient.OnConnectionFailedListener,
    LocationListener,
    com.google.android.gms.location.LocationListener {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding


    lateinit var clickedLine: Polyline
    //internal var polyLocations = PolylineOptions()
    internal var colors = intArrayOf(Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW, Color.rgb(90, 60, 90))

    lateinit var lm: LocationManager
    lateinit var provider: String
    internal var lastGPSLocation: Location? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (checkSelfPermission(
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                MY_PERMISSIONS_REQUEST_FINE_LOCATION)
        }

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)




        // location GPS - klasicky GPS senzor
        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val cr = Criteria()
        cr.isAltitudeRequired = false
        cr.accuracy = Criteria.ACCURACY_COARSE
        cr.powerRequirement = Criteria.POWER_LOW
        cr.isSpeedRequired = false
        provider = LocationManager.GPS_PROVIDER
        mapFragment.getMapAsync(this)
        // location od Google Maps
//        mGoogleApiClient = GoogleApiClient.Builder(this@MapsActivity)
//            .addApi(LocationServices.API)
//            .addConnectionCallbacks(this)
//            .addOnConnectionFailedListener(this)
//            .build()

    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */

    @SuppressLint("MissingPermission")
    override fun onMapReady(gmap: GoogleMap) {
        mMap = gmap
//    }
//    fun continuation() {
        // vygenerovane demo
        // Add a marker in Sydney and move the camera
        val sydney = LatLng(-34.0, 151.0)
        mMap.addMarker(MarkerOptions().position(sydney).title("Marker in Sydney"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney))



//        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//            // TODO: Consider calling
//            //    ActivityCompat#requestPermissions
//            // here to request the missing permissions, and then overriding
//            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
//            //                                          int[] grantResults)
//            // to handle the case where the user grants the permission. See the documentation
//            // for ActivityCompat#requestPermissions for more details.
//            return
//        }

//        map.uiSettings.isMyLocationButtonEnabled = false
//        map.uiSettings.isCompassEnabled = false
//        map.uiSettings.isRotateGesturesEnabled = false
//        map.uiSettings.isScrollGesturesEnabled = false
//        map.uiSettings.isScrollGesturesEnabledDuringRotateOrZoom = false
//        map.uiSettings.isZoomGesturesEnabled =  false
//        map.uiSettings.isTiltGesturesEnabled = false
//        map.uiSettings.isMapToolbarEnabled = false


        val loc = lm.getLastKnownLocation(provider)
        // -----------------------------------------

        //------------------------------------------
        //   mMap.mapType =
        //GoogleMap.MAP_TYPE_SATELLITE
        //    GoogleMap.MAP_TYPE_TERRAIN
        /*
        map.setMapType(GoogleMap.MAP_TYPE_NONE);
        map.addTileOverlay(new TileOverlayOptions().tileProvider(new CustomMapTileProvider(getResources().getAssets(), getApplicationContext())));
*/

        mMap.isMyLocationEnabled = true // zobrazí moju polohu a button na mape
        val mff = LatLng(48.151901, 17.068422)
        val MFF = mMap.addMarker(MarkerOptions().position(mff) // žiadne
            .icon(
                BitmapDescriptorFactory // ikona markera
                    .fromResource(R.drawable.andro_cube)).draggable(true) // vieme
            // marker
            // posúvať
            .alpha(0.5f) // 0-1, 0=transparent, 1=fully opaque.
            .flat(true) // marker sa nezoomuje s mapou, zostáva rovnaký
            .title("MFF") // popis markera
            .anchor(0.0f, 1.0f) // pozícia ikony relatívne k latlong
            .snippet("Kockáči") // popis
            .rotation(90.0f) // natočenie
        )
        val fei = LatLng(48.152516, 17.073827)
        val FEI = mMap.addMarker(MarkerOptions().title("FEI")
            .icon(BitmapDescriptorFactory.fromResource(R.drawable.cw))
            .position(fei).flat(false))

        mMap.isBuildingsEnabled = true
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(mff, 6f))
        mMap.animateCamera(CameraUpdateFactory.zoomIn())
        mMap.animateCamera(CameraUpdateFactory.zoomTo(13f), 2000, null)


        val cameraPosition = CameraPosition.Builder()
            .target(mff)      // kamera smer
            .zoom(17f)         // zoom level
            .bearing(90f)      // azimut kamery, výchdod
            //.bearing(00)      // azimut kamery, sever
            //.tilt(60)         // horizontalne natočenie 0-90
            //.tilt(30)         // horizontalne natočenie 0-90
            //.tilt(0)         // 0 z vrchu...
            //.tilt(10)         // horizontalne natočenie 0-90
            .tilt(40f)         // horizontalne natočenie 0-90
            .build()
        mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition))

        clickedLine = mMap.addPolyline(PolylineOptions())

        mMap.setOnMapLongClickListener { latlng ->
            Log.d("MapV2", "#LONG" + latlng.latitude + ":" + latlng.longitude)
        }
        mMap.setOnMapClickListener { latlng ->
            Log.d("MapV2", "#" + latlng.latitude + ":" + latlng.longitude)
            val clickedPoints = clickedLine.points
            clickedPoints.add(latlng)
            clickedLine.points = clickedPoints
            clickedLine.color = colors[clickedPoints.size % colors.size]
            clickedLine.width = (1 + 5 * clickedPoints.size).toFloat()
            mMap.addMarker(MarkerOptions()
                .title("" + clickedPoints.size)
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.marker))
                .anchor(0.0f, 1.0f)
                .position(latlng))
            try {
                if (Geocoder.isPresent()) {

                    val gc = Geocoder(baseContext, Locale.getDefault())
                    //if (gc != null) {
                    val addrs = gc.getFromLocation(
                        latlng.latitude, latlng.longitude, 2)
                    for (ad in addrs?: emptyList()) {
                        var address = ad.countryName
                        for (i in 0 until ad.maxAddressLineIndex)
                            address += " ," + ad.getAddressLine(i)
                        Log.d("MapV2", address + "#" + ad.latitude + ":" + ad.longitude)
                    }

                    //}
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    override fun onProviderDisabled(provider: String) {}

    override fun onProviderEnabled(provider: String) {}

    override fun onStatusChanged(provider: String, status: Int, extras: Bundle) {}
    override fun onLocationChanged(loc: Location) {
        Log.d("MapV2", "onLocationChanged:" + loc.latitude + ":" + loc.longitude)
        lastGPSLocation = loc

        val latlng = LatLng(loc.latitude, loc.longitude)
        //if (mMap != null) {
        val circle = mMap.addCircle(
            CircleOptions()
                .center(latlng)
                .radius(25.0)
                .strokeColor(Color.GREEN)
                .fillColor(Color.YELLOW))
        circle.zIndex = System.currentTimeMillis().toFloat()

        // novy nahlad
        val bounds = this.mMap.projection.visibleRegion.latLngBounds
        if (!bounds.contains(LatLng(loc.latitude, loc.longitude))) {
            mMap.animateCamera(CameraUpdateFactory.newLatLng(latlng))
        }
        //}
    }

    public override fun onResume() {
        super.onResume()
        // lm.requestLocationUpdates(provider, 1000, 2, this);
        if (checkSelfPermission( Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission( Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return
        }
        lm.requestLocationUpdates(provider, 0, 0f, this)
    }

    public override fun onPause() {
        super.onPause()
        lm.removeUpdates(this)
//        if (mGoogleApiClient != null)
//            LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient!!, this@MapsActivity)
    }

//    override fun onStart() {
//        super.onStart()
//        mGoogleApiClient!!.connect()
//    }

//    override fun onStop() {
//        LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient!!, this)
//        // only stop if it's connected, otherwise we crash
//        if (mGoogleApiClient != null) {
//            mGoogleApiClient!!.disconnect()
//        }
//        super.onStop()
//    }

//    @SuppressLint("MissingPermission")
//    override fun onConnected(bundle: Bundle?) {
//        val mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient!!)
//        if (mLastLocation != null) {
//            Log.d("MapV2", "last location, lat = " + mLastLocation.latitude.toString() + ", long = " + mLastLocation.longitude.toString())
//        }
//
//
//        val request = LocationRequest.create()
//            .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
//            //                                              LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY;
//            //                                              LocationRequest.PRIORITY_HIGH_ACCURACY;
//            .setInterval((5 * 1000).toLong()  /* 5 secs */)
//            .setFastestInterval((2 * 1000).toLong() /* 2 sec */)
//
//        LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient!!, request) {
//                location ->
//            val latLng = LatLng(location.latitude, location.longitude)
//            Log.d("MapV2", "GMAP Location: ${java.lang.Double.toString(location.latitude)}, ${java.lang.Double.toString(location.longitude)}")
//            val circle = mMap.addCircle(
//                CircleOptions()
//                .center(latLng)
//                .radius(15.0)
//                .strokeColor(Color.BLUE)
//                .fillColor(Color.RED))
//            if (location != null && lastGPSLocation != null)
//                Log.d("MapV2", "DIFFERENCE [m]:" + location.distanceTo(lastGPSLocation!!))
//        }
//    }

//    override fun onConnectionSuspended(i: Int) {
//        if (i == GoogleApiClient.ConnectionCallbacks.CAUSE_SERVICE_DISCONNECTED) {
//            Toast.makeText(this, "Disconnected. Please re-connect.", Toast.LENGTH_SHORT).show()
//        } else if (i == GoogleApiClient.ConnectionCallbacks.CAUSE_NETWORK_LOST) {
//            Toast.makeText(this, "Network lost. Please re-connect.", Toast.LENGTH_SHORT).show()
//        }
//    }

//    override fun onConnectionFailed(connectionResult: ConnectionResult) {
//
//    }

    companion object {

        //private var mGoogleApiClient: GoogleApiClient? = null
        /**
         * Manipulates the map once available.
         * This callback is triggered when the map is ready to be used.
         * This is where we can add markers or lines, add listeners or move the camera. In this case,
         * we just add a marker near Sydney, Australia.
         * If Google Play services is not installed on the device, the user will be prompted to install
         * it inside the SupportMapFragment. This method will only be triggered once the user has
         * installed Google Play services and returned to the app.
         */

        private val MY_PERMISSIONS_REQUEST_FINE_LOCATION = 111
    }
}
