package com.example.gmapsos

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Looper
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.example.gmapsos.databinding.ActivityMapsBinding
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.location.*

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding
    private val MY_PERMISSIONS_REQUEST_FINE_LOCATION = 111
    private lateinit var fusedLocationProviderClient : FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback
    private lateinit var savedLastLocation : Location
    val TAG = "FUSED"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // permissions
        if (ContextCompat.checkSelfPermission(this@MapsActivity,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this, // Activity
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION),
                MY_PERMISSIONS_REQUEST_FINE_LOCATION)
        }
        // setup View
        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.sendSosBTN.setOnClickListener {
            val sendIntent = Intent(Intent.ACTION_VIEW)
            sendIntent.data = Uri.parse("sms:")
            sendIntent.putExtra("sms_body",
                "My location at \nLatitude: ${savedLastLocation.latitude} \n" +
                        "Longitude: ${savedLastLocation.longitude}")
            startActivity(sendIntent)
        }

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        // fused Location

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this@MapsActivity)
        GoogleApiAvailability.getInstance()
            .checkApiAvailability(fusedLocationProviderClient)
            .onSuccessTask { _ ->
                fusedLocationProviderClient.lastLocation.addOnSuccessListener {
                        location : Location -> run {
                        savedLastLocation = location
                        Log.w(TAG, "last location= ${location.latitude}, ${location.longitude}")
                    }
                }
                fusedLocationProviderClient.lastLocation
            }
            .addOnFailureListener { _ -> Log.d(TAG, "Location unavailable.")}

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                //locationResult ?:        return
                for (location in locationResult.locations){
                    Log.w(TAG, "onLocationResult= ${location?.latitude}, ${location?.longitude}")
                    val savedLastLocation = LatLng(location.latitude, location.longitude)
                    val options = MarkerOptions()
                        .position(savedLastLocation)
                        .title("I am here!")
                    mMap.addMarker(options)
                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(savedLastLocation, 15f))
                }
            }
        }
    }
    @SuppressLint("MissingPermission")
    override fun onResume() {
        super.onResume()

        val interval = (10 * 1000).toLong()   // 10 seconds, in milliseconds
        val fastestInterval = (1 * 1000).toLong()  // 1 second, in milliseconds
        val minDisplacement = 0f

        // Create the LocationRequest object
        val mLocationRequest = LocationRequest.create()
            .setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY)
            .setInterval(interval)
            .setFastestInterval(fastestInterval)
            .setSmallestDisplacement(minDisplacement)

        fusedLocationProviderClient.requestLocationUpdates(mLocationRequest,
            locationCallback,
            Looper.getMainLooper())

    }
    override fun onPause() {
        super.onPause()
        fusedLocationProviderClient.removeLocationUpdates(locationCallback)
    }
    //---- permission callback
    // Get permission result
    override fun onRequestPermissionsResult(requestCode: Int,
                                            permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            MY_PERMISSIONS_REQUEST_FINE_LOCATION -> {
                if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permission was granted
                    // TODO...
                } else {
                    // permission was denied
                    // TODO...
                }
                return
            }
        }
    }
    //-------------------------------------------------- auto generated code
    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        // Add a marker in Sydney and move the camera
        val sydney = LatLng(-34.0, 151.0)
        mMap.addMarker(MarkerOptions().position(sydney).title("Marker in Sydney"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney))
    }
}