package com.example.cvicenie9gmap

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.location.Location
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Looper
import android.util.Log
import android.widget.Toast
import androidx.core.app.ActivityCompat

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.example.cvicenie9gmap.databinding.ActivityMapsBinding
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import kotlin.random.Random

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding

    // permissions
    private val MY_PERMISSIONS_REQUEST_FINE_LOCATION = 111
    // fused location provider
    private lateinit var fusedLocationProviderClient : FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback
    private lateinit var savedLastLocation : Location
    val TAG = "FUSED"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        // fused location provider
        // https://developers.google.com/location-context/fused-location-provider
        // add dependency to build.gradle (Module: app)
        //     implementation("com.google.android.gms:play-services-location:21.0.1")

        // add permissions (ACCESS_FINE_LOCATION) ACCESS_COARSE_LOCATION to AndroidManifest.xml

        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            Toast.makeText(this, "No permissions", Toast.LENGTH_SHORT).show()
            ActivityCompat.requestPermissions(
                this, // Activity
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION),
                MY_PERMISSIONS_REQUEST_FINE_LOCATION)
        }

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this@MapsActivity)
        GoogleApiAvailability.getInstance()
            .checkApiAvailability(fusedLocationProviderClient)
            .onSuccessTask { _ ->
                fusedLocationProviderClient.lastLocation.addOnSuccessListener {
                        location : Location -> run {
                    savedLastLocation = location
                    Log.w(TAG, "last location= ${location.latitude}, ${location.longitude}")
                    Toast.makeText(this, "last location= ${location.latitude}," +
                            " ${location.longitude}", Toast.LENGTH_SHORT).show()
                    }
                }
                fusedLocationProviderClient.lastLocation
            }
            .addOnFailureListener { _ -> Log.d(TAG, "Location unavailable.")}

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                for (location in locationResult.locations){
                    Log.w(TAG, "onLocationResult= ${location?.latitude}, ${location?.longitude}")
                    val savedLastLocation = LatLng(location.latitude
                            + Random.nextDouble()/1000, // ked nechces mockovanie
                        location.longitude
                                + Random.nextDouble()/1000// ked nechces mockovanie
                    )
                    val options = MarkerOptions()
                        .position(savedLastLocation)
                        .title("I am here!")
                    mMap.addMarker(options)
                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(savedLastLocation, 15f))
                }
            }
        }
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        // Add a marker in Sydney and move the camera
//        val sydney = LatLng(-34.0, 151.0)
//        mMap.addMarker(MarkerOptions().position(sydney).title("Marker in Sydney"))
//        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney))
    }

    @SuppressLint("MissingPermission")
    override fun onResume() {
        super.onResume()
        // Create the LocationRequest object
        val mLocationRequest = LocationRequest.create().apply {
            priority = LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY
            interval = (10 * 1000).toLong()   // 10 seconds, in milliseconds
            fastestInterval = (1 * 1000).toLong()  // 1 second, in milliseconds
            smallestDisplacement = 0f
        }
        fusedLocationProviderClient.requestLocationUpdates(mLocationRequest,
            locationCallback, Looper.getMainLooper())

    }
    override fun onPause() {
        super.onPause()
        fusedLocationProviderClient.removeLocationUpdates(locationCallback)
    }
    //---------------------------------------------------------------
    override fun onRequestPermissionsResult(requestCode: Int,
                                            permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            MY_PERMISSIONS_REQUEST_FINE_LOCATION -> {
                if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permission was granted
                    // TODO...
                } else {
                    // permission was denied
                    // TODO...
                }
                return
            }
        }
    }

}