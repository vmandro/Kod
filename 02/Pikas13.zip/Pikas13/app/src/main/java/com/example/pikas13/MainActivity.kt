package com.example.pikas13

import android.graphics.drawable.Drawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.example.pikas13.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar
import kotlin.system.exitProcess


class MainActivity : AppCompatActivity() {
    val TAG = "PIKAS"
    var i = 0
    var cas = 0
    var imgs: Array<Drawable?> = arrayOf<Drawable?>()
    private lateinit var binding : ActivityMainBinding
    val handler = Handler(Looper.getMainLooper())
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //setContentView(R.layout.activity_main) // toto tu bolo
        imgs = arrayOf(
            ContextCompat.getDrawable(applicationContext, R.drawable.butterfree),
            ContextCompat.getDrawable(applicationContext, R.drawable.golbat),
            ContextCompat.getDrawable(applicationContext, R.drawable.kakuna),
            ContextCompat.getDrawable(applicationContext, R.drawable.raichu),
            ContextCompat.getDrawable(applicationContext, R.drawable.venomoth),
            ContextCompat.getDrawable(applicationContext, R.drawable.venusaur)
        )
        binding.imageView2.setImageDrawable(imgs[i])
        binding.prevBtn2.setOnClickListener {
            Toast.makeText(this, "prev...", Toast.LENGTH_SHORT).show()
            Log.i(TAG, "prev...")
            Snackbar.make(it, "prev...", Snackbar.LENGTH_SHORT)
                .setAction("Action", null).show()
            if (--i < 0) i += imgs.size
            binding.imageView2.setImageDrawable(imgs[i])
        }
        // alebo
        binding.apply {
            imageView2.setImageDrawable(imgs[i])
            prevBtn2.setOnClickListener {
                Toast.makeText(this@MainActivity, "prev...", Toast.LENGTH_SHORT).show()
                Log.i(TAG, "prev...")
                Snackbar.make(it, "prev...", Snackbar.LENGTH_SHORT)
                    .setAction("Action", null).show()
                if (--i < 0) i += imgs.size
                imageView2.setImageDrawable(imgs[i])
            }
        }
//        binding.prevBtn2.setOnClickListener { v:View ->
//            Toast.makeText(this, "prev...", Toast.LENGTH_SHORT).show()
//            Log.i(TAG, "prev...")
//            Snackbar.make(v, "prev...", Snackbar.LENGTH_SHORT).setAction("Action", null).show()
//            if (--i < 0) i += imgs.size
//            binding.imageView2.setImageDrawable(imgs[i])
//        }

        object: CountDownTimer(20000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                Log.i(TAG, "onTICK")
                //runOnUiThread { time.setText("Cas: ${millisUntilFinished/1000}") }
                binding.time.setText("Cas: ${millisUntilFinished/1000}")
            }
            override fun onFinish() {
                Log.i(TAG, "onFinish")
                //exitProcess(-1)
                //finish()
                exitProcess(0)
            }
        }.start()
//
//        val timer = Timer("tik-tak").schedule(
//            object : TimerTask() {
//                override fun run() {
//                    Log.i(TAG, "onTICK")
//                    cas++
//                    runOnUiThread { binding.time.setText("Cas: $cas") }
//                }
//            },
//            1000, 1000
//        )
//        timer.run {  }

//        val runnable = Runnable {
//            cas += 100
//            binding.time.setText("Cas: $cas")
//        }
//        //handler.postDelayed(runnable, 5000)
//        val now = SystemClock.uptimeMillis()
//        val uptime = now + (15*1000-now % (15*1000)) // 15 sec
//        Log.i(TAG, "now = $now, uptime = $uptime")
//        handler.postAtTime(runnable, uptime)

//        Timer("tik-tak").schedule(1000,1000) {
//            Log.i(TAG, "onTICK")
//            cas++
//            runOnUiThread { time.setText("Cas: $cas") }
//        }.run()
    }
    // prepojene na property android:onClick="nextOnClickListener"
    fun nextOnClickListener(v: View) {
        Toast.makeText(this, "next...", Toast.LENGTH_LONG).show()
        Snackbar.make(v, "next...", Snackbar.LENGTH_LONG)
            .setAction(R.string.action,
                { nextOnClickListener(it) }).show()
        Log.i(TAG, "next...")
        i = (++i) % imgs.size
        binding.imageView2.setImageDrawable(imgs[i])
    }
    // prepojene na property android:onClick="quitOnClickListener"
    fun quitOnClickListener(v: View) {
        Toast.makeText(this, "quit...", Toast.LENGTH_LONG).show()
        Snackbar.make(v, "quit...", Snackbar.LENGTH_LONG).setAction("Action", null).show()
        Log.i(TAG, "quit...")
        exitProcess(-1)
    }

}