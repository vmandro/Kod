package com.example.anagrams

import android.util.Log
import java.io.BufferedReader
import java.io.Reader

class Dictionary(reader: Reader) {
    val dict = BufferedReader(reader).readLines()

    /**
     * slovo sa nachadza v prilozenom slovniku words.txt
     */
    fun isCorrect(word: String): Boolean =
        false // doprogramuj

    /**
     * vrati vsetky anagramy daneho slova, ktore sa nachadzaju v slovniku
     */
    fun anagrams(word: String): List<String> =
        emptyList() // doprogramuj

    /**
     * vrati vsetky anagramy, ktore su v slovniku
     */
    fun allAnagrams(): List<String> =
        emptyList() // doprogramuj

    /**
     * pre dane slovo vrati vsetky slova, ktore sa od neho lisia v jedinom pismene
     * jedno pismeno povodneho slova mozete zmenit, alebo vymazat, alebo vsunutm,
     * aby ste dostali vysledne slovo, ktore ovsem musi byt zo slovnika
     */
    fun mistake1(word : String) : List<String> =
        emptyList()  // doprogramuj
}
