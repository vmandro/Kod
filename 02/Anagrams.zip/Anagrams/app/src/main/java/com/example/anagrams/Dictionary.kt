package com.example.anagrams

import android.util.Log
import java.io.BufferedReader
import java.io.Reader

class Dictionary(reader: Reader) {
    val dict = BufferedReader(reader).readLines()

    /**
     * slovo sa nachadza v prilozenom slovniku words.txt
     */
    fun isCorrect(word: String): Boolean =
        //dict.contains(word)
        word in dict

    /**
     * vrati vsetky anagramy daneho slova, ktore sa nachadzaju v slovniku
     */
    fun anagrams(word: String): List<String> =
        dict.filter {
           it.length == word.length && it != word &&
           it.toList().sorted()  == word.toList().sorted()
        }
        //emptyList() // doprogramuj
    /**
     * vrati vsetky anagramy, ktore su v slovniku
     */
    fun allAnagrams(): List<String> =
        dict.groupBy { it.toList().sorted()} .values.filter {it.size > 1}.flatten()
        //emptyList() // doprogramuj

    /**
     * pre dane slovo vrati vsetky slova, ktore sa od neho lisia v jedinom pismene
     * jedno pismeno povodneho slova mozete zmenit, alebo vymazat, alebo vsunutm,
     * aby ste dostali vysledne slovo, ktore ovsem musi byt zo slovnika
     */

    private fun insert(x:String, y:String) : Boolean =
        x.length + 1 == y.length &&
                (1..x.length).any { i->
                    x.substring(0,i-1) == y.substring(0,i-1)    &&
                    x.substring(0,i) == y.substring(0,i+1)
                }

    private fun replace(x:String, y:String) : Boolean =
        x.length == y.length &&
                (0..x.length).any { i->
                    x.substring(0,i-1) == y.substring(0,i-1)    &&
                            x.substring(0,i+1) == y.substring(0,i+1)
                }
    fun mistake1(word : String) : List<String> =
        dict.filter { insert(word,it) 
                || replace(word,it)
                || insert(it, word) }

}
