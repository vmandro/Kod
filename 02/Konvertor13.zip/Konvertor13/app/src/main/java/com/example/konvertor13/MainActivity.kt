package com.example.konvertor13

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import com.example.konvertor13.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //setContentView(R.layout.activity_main)
        binding.eur2usd.isChecked = true

//        very old fashion
        var cBtn = findViewById<Button>(R.id.convertBtn)
        // cBtn.setOnClickListener( { v -> convert(v) } )
        cBtn.setOnClickListener { convert(it) }


//        old fashion
        //convertBtn.setOnClickListener { v -> convert(v) }
        binding.convertBtn.setOnClickListener { convert(it) }

    }
    fun convert(v: View) {
        Toast.makeText(this, "convert", Toast.LENGTH_SHORT).show();
        binding.apply {
            if (inputText.text.isNotEmpty()) {
                val exchangeRate = 1.12f
                val input = inputText.text.toString().toFloat();
                var output = input
                if (eur2usd.isChecked) output = exchangeRate * output
                if (usd2eur.isChecked) output = output / exchangeRate
                outputText.setText("${output.format(2)}")
            }
        }
    }
    fun Float.format(digits: Int) =
        java.lang.String.format("%.${digits}f", this)
}
