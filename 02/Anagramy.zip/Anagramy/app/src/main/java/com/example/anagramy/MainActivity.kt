package com.example.anagramy

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.annotation.RequiresApi
import com.example.anagramy.databinding.ActivityMainBinding
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Random
import java.util.stream.Collectors


class MainActivity : AppCompatActivity() {
    private lateinit var englishWords : List<String>
    private lateinit var allButtons : List<Button>
    private lateinit var buttons : List<Button>
    private val minLength = 4
    private val maxLength = 7
    private lateinit var binding : ActivityMainBinding

    @RequiresApi(Build.VERSION_CODES.N)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.apply {
            allButtons = listOf(
                letterBtn0,
                letterBtn1,
                letterBtn2,
                letterBtn3,
                letterBtn4,
                letterBtn5,
                letterBtn6
            )
            val inps = resources.openRawResource(R.raw.knuth_words)
            val br = BufferedReader(InputStreamReader(inps))
            englishWords = br.lines()
                .collect(Collectors.toList())
                .filter { it.isCorrectAsExtensionFunction() }

            Toast.makeText(this@MainActivity, "hotovo ${englishWords.size}", Toast.LENGTH_SHORT).show()
            newBtn.setOnClickListener {
                //Toast.makeText(this, "next pressed", Toast.LENGTH_LONG).show()
                // vygeneruj nove slovo a znova
                init();
            }
            checkBtn.setOnClickListener {
                //Toast.makeText(this, "check pressed", Toast.LENGTH_SHORT).show()
                if (isOkay(composedWord.text.toString(), initWord.text.toString())) {
                    resultView.append("${composedWord.text}\n")
                    composedWord.text = ""
                    buttons.forEach {
                        it.visibility = View.VISIBLE
                    }
                }
            }
            backBtn.setOnClickListener {
                Toast.makeText(this@MainActivity, "back pressed", Toast.LENGTH_SHORT).show()
                // asi som sa pomylil, chce to nejake undo
                // skuste dorobit
            }
        }
        init();
    }

    @SuppressLint("SetTextI18n")
    private fun init() {
        val rnd = Random().nextInt(englishWords.size)
        val s = englishWords[rnd]
        buttons = allButtons.take(s.length)
        binding.resultView.text = "#anagrams: ${numberOfAnagrams(s)}\n"
        binding.initWord.text = s
        allButtons.forEach { it.visibility = View.GONE }
        val shuffled = s.toList().shuffled().joinToString(separator = "")
        for ((i,ch) in shuffled.withIndex()) {
            buttons[i].apply {
                text = "$ch"
                visibility = View.VISIBLE
                setBackgroundColor(Color.GREEN)
            }
            buttons[i].setOnClickListener {
                val button = it as Button
                binding.composedWord.setText(binding.composedWord.text.toString() + button.text)
                button.visibility = View.GONE
            }
        }
    }
    private fun isCorrect(w : String) : Boolean =
        w.all { it.isLetter() } && w.length in minLength..maxLength

    private fun String.isCorrectAsExtensionFunction() : Boolean =
        all { it.isLetter() } && length in minLength..maxLength

    private fun isOkay(w : String, originalWord : String) : Boolean {
        return true // dorobit
    }
    private fun numberOfAnagrams(w : String) =  // dorobit
        9999 // pocet anagramov slova w v anlickom slovniku
}