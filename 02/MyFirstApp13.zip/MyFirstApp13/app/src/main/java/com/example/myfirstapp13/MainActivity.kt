package com.example.myfirstapp13

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import com.example.myfirstapp13.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //setContentView(R.layout.activity_main)
        //val startBtn = findViewById<Button>(R.id.startBtn)
        //val iv = findViewById<ImageView>(R.id.imageView)

        val sBtn = binding.startBtn
        val iv = binding.imageView

        binding.apply {
            startBtn.setOnClickListener {
                imageView.setImageResource(R.drawable.ic_launcher_foreground)
            }
        }
    }
}
