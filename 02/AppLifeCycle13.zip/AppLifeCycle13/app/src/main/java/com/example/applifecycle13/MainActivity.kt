package com.example.applifecycle13
import android.app.Activity
import android.content.SharedPreferences
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.PersistableBundle
import android.util.Log
import android.view.View
import android.widget.Toast
import com.google.android.material.snackbar.Snackbar
import android.content.Context
import androidx.core.content.edit
import com.example.applifecycle13.databinding.ActivityMainBinding

//import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    private val TAG = "CYKLUS"
    private var globalCounter = 0  // uloží hodnotu pri onSaveInstance
    private var localCounter = 0  // neuloží hodnotu, klasická lokálna premenná
    private var sharedCounter = 0  // ulozi hodnotu do sharedPreferences, nacita pri restarte applikacie
    private lateinit var preferences: SharedPreferences
    //private var preferences : SharedPreferences? = null
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //setContentView(R.layout.activity_main)
        Log.i(TAG, "onCreate")
        Toast.makeText(this, "onCreate" + globalCounter, Toast.LENGTH_SHORT).show()
        showSnackBar(this, "onCreate" + globalCounter,"Action",
            View.OnClickListener { System.out.println("Snackbar Set Action - onPause." + globalCounter) }, Snackbar.LENGTH_SHORT)

        preferences = getSharedPreferences("lifecycle", Context.MODE_PRIVATE)
    }

    override fun onCreate(savedInstanceState: Bundle?, persistentState: PersistableBundle?) {
        super.onCreate(savedInstanceState, persistentState)
        Log.i(TAG, "onCreate")
        Toast.makeText(this, "onCreate" + globalCounter, Toast.LENGTH_SHORT).show()
        showSnackBar(this, "onCreate" + globalCounter,"Action",
            View.OnClickListener { System.out.println("Snackbar Set Action - onPause." + globalCounter) }, Snackbar.LENGTH_SHORT)
    }

    fun showSnackBar(activity: Activity, message: String, action: String? = null,
                     actionListener: View.OnClickListener? = null, duration: Int = Snackbar.LENGTH_SHORT) {
        val snackBar = Snackbar.make(activity.findViewById(android.R.id.content), message, duration)
            .setActionTextColor(Color.parseColor("#906090"))
        snackBar.view.setBackgroundColor(Color.parseColor("#609060"))
        if (action != null && actionListener!=null) {
            snackBar.setAction(action, actionListener)
        }
        snackBar.show()
    }

    override fun onPause() {
        super.onPause()
        Log.i(TAG, "onPause")
        Toast.makeText(this, "onPause" + globalCounter, Toast.LENGTH_SHORT).show()
        showSnackBar(this, "onPause" + globalCounter,"Action",
            View.OnClickListener { System.out.println("Snackbar Set Action - onPause." + globalCounter) }, Snackbar.LENGTH_SHORT)
        localCounter++
        globalCounter++
        sharedCounter++
        preferences.edit {
            putInt("kluc", sharedCounter)
            apply()
        }
        val editor = preferences.edit()
        editor.putInt("kluc", sharedCounter)
        editor.apply()
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i(TAG, "onDestroy" + globalCounter)
        Toast.makeText(this, "onDestroy" + globalCounter, Toast.LENGTH_SHORT).show()
        showSnackBar(this, "onDestroy" + globalCounter,"Action",
            View.OnClickListener { System.out.println("Snackbar Set Action - onDestroy." + globalCounter) }, Snackbar.LENGTH_SHORT)
    }

    override fun onStart() {
        super.onStart()
        Log.i(TAG, "onStart" + globalCounter)
        Toast.makeText(this, "onStart" + globalCounter, Toast.LENGTH_SHORT).show()
        showSnackBar(this, "onStart" + globalCounter,"Action",
            View.OnClickListener { System.out.println("Snackbar Set Action - onStart." + globalCounter) }, Snackbar.LENGTH_SHORT)
    }

    override fun onResume() {
        super.onResume()
        Log.i(TAG, "onResume" + globalCounter)
        Toast.makeText(this, "onResume" + globalCounter, Toast.LENGTH_SHORT).show()
        showSnackBar(this, "onResume" + globalCounter,"Action",
            View.OnClickListener { System.out.println("Snackbar Set Action - onResume." + globalCounter) }, Snackbar.LENGTH_SHORT)
        sharedCounter = preferences.getInt("kluc",0)
        binding.globalTV.text = "global: $globalCounter"
        binding.localTV.text = "local: $localCounter"
        binding.sharedTV.text = "shared: ${sharedCounter}"
    }

    override fun onStop() {
        super.onStop()
        Log.i(TAG, "onStop" + globalCounter)
        Toast.makeText(this, "onStop" + globalCounter, Toast.LENGTH_SHORT).show()
        showSnackBar(this, "onStop" + globalCounter,"Action",
            View.OnClickListener { System.out.println("Snackbar Set Action - onStop." + globalCounter) }, Snackbar.LENGTH_SHORT)
    }

    override fun onRestart() {
        super.onRestart()
        Log.i(TAG, "onRestart" + globalCounter)
        Toast.makeText(this, "onRestart" + globalCounter, Toast.LENGTH_SHORT).show()
        showSnackBar(this, "onRestart" + globalCounter,"Action",
            View.OnClickListener { System.out.println("Snackbar Set Action - onRestart." + globalCounter) }, Snackbar.LENGTH_SHORT)
    }

    override fun onSaveInstanceState(outState: Bundle, outPersistentState: PersistableBundle) {
        super.onSaveInstanceState(outState, outPersistentState)
        outState?.putInt("COUNTER", globalCounter)
        Log.i(TAG, "onSaveInstanceState" + globalCounter)
        Toast.makeText(this, "onSaveInstanceState" + globalCounter, Toast.LENGTH_SHORT).show()
        showSnackBar(this, "onSaveInstanceState","Action",
            View.OnClickListener { System.out.println("Snackbar Set Action - onSaveInstanceState." + globalCounter) }, Snackbar.LENGTH_SHORT)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        Log.i(TAG, "onRestoreInstanceState" + globalCounter)
        Toast.makeText(this, "onRestoreInstanceState" + globalCounter, Toast.LENGTH_SHORT).show()
        showSnackBar(this, "onRestoreInstanceState" + globalCounter,"Action",
            View.OnClickListener { System.out.println("Snackbar Set Action - onRestoreInstanceState." + globalCounter) }, Snackbar.LENGTH_SHORT)
//        if (savedInstanceState  == null) {
//            globalCounter = 0
//        } else {
//            globalCounter = savedInstanceState.getInt("COUNTER")
//        }
        globalCounter = savedInstanceState?.getInt("COUNTER")?:0
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putInt("COUNTER", globalCounter)
        Log.i(TAG, "onSaveInstanceState" + globalCounter)
        Toast.makeText(this, "onSaveInstanceState" + globalCounter, Toast.LENGTH_SHORT).show()
        showSnackBar(this, "onSaveInstanceState","Action",
            View.OnClickListener { System.out.println("Snackbar Set Action - onSaveInstanceState." + globalCounter) }, Snackbar.LENGTH_SHORT)
        super.onSaveInstanceState(outState)
    }
}
