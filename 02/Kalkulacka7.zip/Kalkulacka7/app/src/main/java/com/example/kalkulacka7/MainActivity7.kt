package com.example.kalkulacka7

import android.content.Intent
import android.content.pm.ActivityInfo
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Toast
import com.example.kalkulacka7.databinding.ActivityMain7Binding

class MainActivity7 : AppCompatActivity() {
    private lateinit var binding: ActivityMain7Binding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        binding = ActivityMain7Binding.inflate(layoutInflater)
        setContentView(binding.root)
    }
    fun clickedButton(v : View) {
        Log.d("SNEH", "clikol si na button ${(v as Button).text}")
        Toast.makeText(this, "klikol si na button ${(v as Button).text}", Toast.LENGTH_SHORT).show()
        if (v.id == binding.button3.id) {  // preklopenie do desiatkovej kalkulacky
            intent = Intent(this, MainActivity10::class.java)
            startActivity(intent)
        }
    }
}