package com.example.kalkulacka7

import android.content.Intent
import android.content.pm.ActivityInfo
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import com.example.kalkulacka7.databinding.ActivityMain10Binding
import com.example.kalkulacka7.databinding.ActivityMain7Binding

class MainActivity10 : AppCompatActivity() {
    private lateinit var binding: ActivityMain10Binding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        binding = ActivityMain10Binding.inflate(layoutInflater)
        setContentView(binding.root)
    }
    fun clickedButton(v : View) {
        Log.d("SNEH", "clikol si na button ${v.id}")
        Toast.makeText(this, "klikol si na button ${v.id}", Toast.LENGTH_SHORT).show()
        if (v.id == binding.button3.id) { // preklopenie do sedmickovej kalkulacky
            intent = Intent(this, MainActivity7::class.java)
            startActivity(intent)
        }
    }
}