package com.example.textviewdemo13

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import com.example.textviewdemo13.databinding.ActivityMainBinding
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //setContentView(R.layout.activity_main)
        binding.apply {
            val emailTV_ = findViewById<TextInputEditText>(R.id.emailTV)

            emailTV.setText("")
            passwordTV.setText("")
            userTV.setText("")
            val textWatcher = object : TextWatcher {
                override fun beforeTextChanged(
                    s: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                }

                override fun afterTextChanged(s: Editable?) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    //button.visibility = if (s?.isEmpty()?:true) View.INVISIBLE else View.VISIBLE
                    //button.isEnabled = s?.isNotEmpty()?:false
                    button.isEnabled =
                        emailTV.text?.isNotEmpty() ?: false &&
                                userTV.text?.isNotEmpty() ?: false &&
                                passwordTV.text?.isNotEmpty() ?: false

                    button.isEnabled =
                        if (emailTV.text != null && userTV.text != null && passwordTV.text != null)
                            emailTV.text!!.isNotEmpty() && userTV.text!!.isNotEmpty() && passwordTV.text!!.isNotEmpty()
                        else
                            false

                    button.isEnabled =
                        if (emailTV.text != null)
                            emailTV.text!!.isNotEmpty() &&
                                    if (userTV.text != null)
                                        userTV.text!!.isNotEmpty() &&
                                                if (passwordTV.text != null)
                                                    passwordTV.text!!.isNotEmpty()
                                                else false
                                    else false
                        else false
                }
            }
            emailTV.addTextChangedListener(textWatcher)
            userTV.addTextChangedListener(textWatcher)
            passwordTV.addTextChangedListener(textWatcher)
        }
    }
    fun loginPressed(v: View) {
        binding.apply {
            Log.d(
                "TAG",
                "email=${emailTV.text.toString()}, " +
                        "user=${userTV.text.toString()}, " +
                        "password=${passwordTV.text.toString()}" +
                        "novy = ${novyTV.text.toString()}"
            )
        }
    }
}