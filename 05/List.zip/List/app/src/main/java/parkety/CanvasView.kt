package com.example.parkety

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

class CanvasView(context: Context, attrs: AttributeSet) : View(context, attrs), View.OnTouchListener {
    lateinit var scena : Scena
    internal var m: Mreza? = null

    init {
        setOnTouchListener(this)
    }

    override fun onTouch(view: View, motionEvent: MotionEvent): Boolean {
        if (scena.onTouched(motionEvent))
            invalidate()
        return true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        c = canvas
        if (m == null) {
            scena = Scena(listOf(
                Tvar(listOf(Stvorcek(7, 7, 1, 1, Color.BLUE), Stvorcek(8, 7, 1, 1, Color.BLUE))),
                Tvar(listOf(Stvorcek(5, 5, 1, 1, Color.GRAY), Stvorcek(5, 6, 1, 1, Color.GRAY), Stvorcek(6, 5, 1, 1, Color.GRAY))),
                Tvar(listOf(Stvorcek(2, 2, 1, 1, Color.YELLOW), Stvorcek(2, 3, 1, 1, Color.YELLOW), Stvorcek(3, 2, 1, 1, Color.YELLOW), Stvorcek(3, 3, 1, 1, Color.YELLOW))),
                Tvar(listOf(Stvorcek(0, 0, 1, 1, Color.RED), Stvorcek(1, 0, 1, 1, Color.RED), Stvorcek(1, 1, 1, 1, Color.RED), Stvorcek(1, 2, 1, 1, Color.RED)))
            ))
            m = Mreza()
        }
        m?.onDraw()
        scena.onDraw()
    }

    companion object {
        var c: Canvas? = null
        val SIZE = 10
        // transformacie -------------------------------------------------
        fun minSize(): Float {
            return Math.min(c!!.width, c!!.height).toFloat()
        }

        fun toPixelX(x: Int): Float {
            return x * minSize() / SIZE
        }

        fun toPixelY(y: Int): Float {
            return y * minSize() / SIZE
        }

        fun toLogicX(x: Float): Int {
            return Math.floor((x / (minSize() / SIZE)).toDouble()).toInt()
        }

        fun toLogicY(y: Float): Int {
            return Math.floor((y / (minSize() / SIZE)).toDouble()).toInt()
        }
    }
}
