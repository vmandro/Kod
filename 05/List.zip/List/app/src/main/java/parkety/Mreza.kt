package com.example.parkety

import android.graphics.Color
import android.graphics.Paint

class Mreza {

    fun onDraw() {
        val p = Paint()
        p.color = Color.BLACK
        p.strokeWidth = 3f
        for (i in 0..CanvasView.SIZE) {
            CanvasView.c!!.drawLine(CanvasView.toPixelX(i), CanvasView.toPixelY(0),
                    CanvasView.toPixelX(i), CanvasView.toPixelY(CanvasView.SIZE), p)  // zvisle
            CanvasView.c!!.drawLine(CanvasView.toPixelX(0), CanvasView.toPixelY(i),
                    CanvasView.toPixelX(CanvasView.SIZE), CanvasView.toPixelY(i), p) // vodorovne
        }
    }
}
