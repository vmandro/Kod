package com.example.list

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.ContextMenu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView.AdapterContextMenuInfo
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.list.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {

    val TAG = "ParketyActivity"
    lateinit var la:ArrayAdapter<String>
    lateinit var actList: MutableList<String>
    private lateinit var binding : ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        //setContentView(R.layout.activity_main)
        setContentView(binding.root)
        actList = resources.getStringArray(R.array.listofallact).toMutableList()
        la = ArrayAdapter<String>(
            this,
            android.R.layout.simple_list_item_1,
            actList
        )
        binding.listView1.adapter = la
        binding.listView1.setOnItemClickListener {
            adapterView, view, index, l ->
                val hodnota = adapterView.getItemAtPosition(index)
                Log.i(TAG, "list item click: $index:$hodnota")
                val klasa = Class.forName("com.example.list.$hodnota").kotlin
                //val intent = Intent(this, IntroActivity::class.java)
                val str: String? = klasa.qualifiedName
                Log.i(TAG, "class name: ${klasa.qualifiedName}")
                val intent = Intent(klasa.qualifiedName)
                startActivity(intent)
        }
        registerForContextMenu(binding.listView1)
    }

    override fun onCreateContextMenu(
        menu: ContextMenu?, v: View?, menuInfo: ContextMenu.ContextMenuInfo? ) {
        super.onCreateContextMenu(menu, v, menuInfo)
        getMenuInflater().inflate(R.menu.list_menu, menu)
    }
    override fun onContextItemSelected(item: MenuItem): Boolean {
        val info = item.getMenuInfo() as AdapterContextMenuInfo
        val className = actList.get(info.id.toInt())
        when (item.getItemId()) {
            R.id.remove -> {
                Toast.makeText(
                    this@MainActivity, "remove:$className, ${info.id.toInt()}",
                    Toast.LENGTH_LONG
                ).show()
                actList.removeAt(info.id.toInt())
                la.notifyDataSetChanged()
                return true
            }
            R.id.run -> {
                Toast.makeText(this@MainActivity, "run:$className", Toast.LENGTH_LONG)
                    .show()
                try {
                    val klasa = Class.forName("com.example.list.$className").kotlin
                    //val intent = Intent(this, IntroActivity::class.java)
                    Log.i(TAG, "class name: ${klasa.qualifiedName}")
                    val intent = Intent(klasa.qualifiedName)
                    startActivity(intent)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                return true
            }
            R.id.stop -> return true
            else -> return super.onContextItemSelected(item)
        }
    }
//    override fun onPause() {
//        super.onPause()
//        finish()
//    }

}
