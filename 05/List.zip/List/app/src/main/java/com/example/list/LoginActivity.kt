package com.example.list

import android.app.AlertDialog
import android.content.DialogInterface
import android.os.Bundle
import android.preference.PreferenceManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.edit
import com.example.list.databinding.ActivityLoginBinding


class LoginActivity : AppCompatActivity() {
    val LOGIN_ENTRY_KEY = "prefLogin"
    val PASSWORD_ENTRY_KEY = "prefPass"
    val SUCCLOGS_ENTRY_KEY = "prefSUCC"
    val FAILEDLOGS_ENTRY_KEY = "prefFAILED"
    var SuccessfulLogins = 0
    var FailedLogins = 0
    private lateinit var binding : ActivityLoginBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //setContentView(R.layout.activity_login)
        binding.apply {
            loginBtn.setOnClickListener {
                if (emailtv.getText().toString() == passwdtv.getText()
                        .toString()
                ) { // silna kontrola passwordu :-)
                    SuccessfulLogins++; // uloz nastavenia
                    saveLoginPassword(false);
                    // gratuluj
                    val welcomeDialog = AlertDialog.Builder(this@LoginActivity).create();
                    welcomeDialog.setTitle("Welcome, you are IN !");
                    welcomeDialog.setMessage("Success: $SuccessfulLogins, failed: $FailedLogins")
                    welcomeDialog.setButton("OK",
                        DialogInterface.OnClickListener { dialog: DialogInterface, which: Int ->
                            {
                                Toast.makeText(
                                    getApplicationContext(),
                                    "are you OK?", Toast.LENGTH_SHORT
                                ).show();
                            }
                        });
                    welcomeDialog.show();
                } else {
                    FailedLogins++; // uloz nastavenia
                    saveLoginPassword(true);
                    // gratuluj
                    val welcomeDialog = AlertDialog.Builder(this@LoginActivity).create();
                    welcomeDialog.setTitle("Sorry, you are OUT !");
                    welcomeDialog.setMessage("Success: $SuccessfulLogins, failed: $FailedLogins")
                    welcomeDialog.setButton("FAIL",
                        DialogInterface.OnClickListener { dialog: DialogInterface, which: Int ->
                            {
                                Toast.makeText(
                                    getApplicationContext(),
                                    "are you OK?", Toast.LENGTH_SHORT
                                ).show();
                            }
                        });
                    welcomeDialog.show();
                }
                forgetBtn.setOnClickListener {
                    emailtv.setText("")
                    passwdtv.setText("")
                    //getPreferences(     )
                    //getSharedPreferences()
                    val state = PreferenceManager.getDefaultSharedPreferences(this@LoginActivity)
                    //state.getString(LOGIN_ENTRY_KEY,"")

                    state.edit() {
                        remove(LOGIN_ENTRY_KEY)
                        remove(PASSWORD_ENTRY_KEY)
                        remove(SUCCLOGS_ENTRY_KEY)
                        remove(FAILEDLOGS_ENTRY_KEY)
                        commit()
                    }
                };
                val state = PreferenceManager.getDefaultSharedPreferences(this@LoginActivity)
                state.edit() {
                    putString(LOGIN_ENTRY_KEY, "")
                    putString(PASSWORD_ENTRY_KEY, "")
                }
                SuccessfulLogins = state.getInt(SUCCLOGS_ENTRY_KEY, 0);
                FailedLogins = state.getInt(FAILEDLOGS_ENTRY_KEY, 0);
            }
        }
    }
    fun saveLoginPassword(countsOnly: Boolean) {
        val state = PreferenceManager.getDefaultSharedPreferences(this)
        binding.apply {
            state.edit() {
                if (!countsOnly) {
                    putString(LOGIN_ENTRY_KEY, emailtv.text.toString())
                    putString(PASSWORD_ENTRY_KEY, passwdtv.text.toString())
                }
                putInt(SUCCLOGS_ENTRY_KEY, SuccessfulLogins)
                putInt(FAILEDLOGS_ENTRY_KEY, FailedLogins)
                commit()
            }
        }
    }
    override fun onPause() {
        super.onPause()
        saveLoginPassword(true)
    }
}