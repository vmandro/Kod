package com.example.list

import android.content.Context
import android.content.res.AssetFileDescriptor
import android.media.AudioManager
import android.media.SoundPool
import android.util.Log
import java.io.IOException
import android.media.AudioAttributes




class SoundPlayer(context: Context) {
    //private val soundPool: SoundPool = SoundPool(10, AudioManager.STREAM_MUSIC, 0)

    var audioAttrib = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
    val soundPool = SoundPool.Builder()
                    .setAudioAttributes(audioAttrib)
                    .setMaxStreams(10)
                    .build()

    companion object {
        var shootID = -1
        //var tadaID = -1
    }
    init {
        try {
            val assetManager = context.assets
            //var descriptor: AssetFileDescriptor
            // adresar assets
            val descriptor = assetManager.openFd("shoot.ogg")
            shootID = soundPool.load(descriptor, 0)

//            descriptor = assetManager.openFd("tada.wav")
//            tadaID = soundPool.load(descriptor, 0)
        } catch (e: IOException) {
            Log.e("SoundPlayer", "sound file not found")
        }
        soundPool.setOnLoadCompleteListener (
            { soundPool, sampleID, status ->
                soundPool.play(sampleID, 1f,1f,1, 1, 1f)
            }
        )
    }
}