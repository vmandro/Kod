package com.example.list

import android.app.Activity
import android.app.Fragment
//import androidx.fragment.app.Fragment
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import com.example.list.databinding.FragmentButtonsBinding

class FragmentButtons : Fragment() {
    private lateinit var controller: FragmentActivity
    private var container: ViewGroup? = null
    val TAG = "Fragment"

    private lateinit var binding : FragmentButtonsBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        Log.i(TAG, "onCreated in FragmentButtons")
        this.container = container
        //return inflater.inflate(R.layout.fragment_buttons, container, false)
        binding = FragmentButtonsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onAttach(activity: Activity) {
        super.onAttach(activity)
        Log.i(TAG, "onAttach in FragmentButtons")
        controller = activity as FragmentActivity
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        Log.i(TAG, "onActivityCreated in FragmentButtons")
    }

    init {
        Log.i(TAG, "new of FragmentButtons")
    }

    override fun onStart() {
        super.onStart()
        Log.i(TAG, "onStart in FragmentButtons")
        binding.prevBtn.setOnClickListener { controller.prev() }
        binding.nextBtn.setOnClickListener { controller.next() }
        binding.quitBtn.setOnClickListener { controller.quit() }

//        val prev = container!!.findViewById(R.id.prevBtn) as Button
//        prev.setOnClickListener { controller?.prev() }
//        val next = container!!.findViewById(R.id.nextBtn) as Button
//        next.setOnClickListener { controller?.next() }
//        val quit = container!!.findViewById(R.id.quitBtn) as Button
//        quit.setOnClickListener { controller?.quit() }
//
    }

    override fun onResume() {

        super.onResume()
        Log.i(TAG, "onResume in FragmentButtons")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        Log.i(TAG, "onSaveInstance in FragmentButtons")
    }

    override fun onDetach() {
        super.onDetach()
        Log.i(TAG, "onDetach in FragmentButtons")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i(TAG, "onDestroy in FragmentButtons")
    }
}
