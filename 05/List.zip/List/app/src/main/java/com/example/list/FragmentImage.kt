package com.example.list

import android.app.Activity
import android.os.Bundle
import android.util.Log
import android.view.*
import android.app.Fragment
import com.example.list.databinding.FragmentImageBinding

class FragmentImage : Fragment() {
    private var controller: FragmentActivity? = null
    internal var container: ViewGroup? = null
    private lateinit var binding : FragmentImageBinding

    private var i = 0
    val TAG = "Fragment"

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        Log.i(TAG, "onCreated FragmentImage")
        this.container = container
        setHasOptionsMenu(true)
        binding = FragmentImageBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        Log.i(TAG, "onActivityCreated FragmentImage")
    }

    init {
        Log.i(TAG, "new FragmentImage")
        i = 0
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        Log.i("Canvas", "createOptionMenu")
        inflater.inflate(R.menu.activity_fragmentimage, menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.prev) {
            prevPicture()
            return true
        } else if (item.itemId == R.id.next) {
            nextPicture()
            return true
        } else
            return super.onOptionsItemSelected(item)
    }

    override fun onStart() {
        super.onStart()
        Log.i(TAG, "onStart FragmentImage")
        updatePicture()
    }

    fun updatePicture() {
        Log.i(TAG, "update FragmentImage $i")
        if (controller != null) {
            i = i % controller!!.pikas.size
            val imageView = binding.imageView
            imageView.setImageDrawable(controller!!.pikas[i])
        }
    }

    fun nextPicture() {
        Log.i(TAG, "next FragmentImage")
        if (controller != null)
            i = (i + 1) % controller!!.pikas.size
        updatePicture()
    }

    fun prevPicture() {
        Log.i(TAG, "prev FragmentImage")
        if (controller != null) {
            i--
            if (i < 0)
                i = controller!!.pikas.size - 1
        }
        updatePicture()
    }

    override fun onAttach(activity: Activity) {
        super.onAttach(activity)
        Log.i(TAG, "onAttach FragmentImage")
        controller = activity as FragmentActivity
    }

    override fun onResume() {
        super.onResume()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        Log.i(TAG, "onSaveInstance FragmentImage")
    }

    override fun onDetach() {
        super.onDetach()
        Log.i(TAG, "onDetach FragmentImage")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i(TAG, "onDestroy FragmentImage")
    }

    override fun onPause() {
        Log.i(TAG, "onPause FragmentImage")
        super.onPause()
    }
}
