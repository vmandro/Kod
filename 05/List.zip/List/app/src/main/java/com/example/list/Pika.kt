package com.example.list

import android.graphics.Bitmap
import android.graphics.Canvas
import java.util.*

class Pika(var bitmap: Bitmap) {
    val RIGHT = 1
    val LEFT = -1
    val UP = -1
    val DOWN = 1

    var x: Float = 0F
    var y: Float = 0F
    var dx = RIGHT.toFloat()
    var dy = DOWN.toFloat()

    var touched = false
    var killed = false

    init {
        val rnd = Random()
        x = 30F + rnd.nextInt(600)
        y = 80F + rnd.nextInt(600)
        dx = (if (rnd.nextInt(3) == 0) -1 else 1).toFloat()
        dy = (if (rnd.nextInt(3) == 0) -1 else 1).toFloat()
    }

    fun draw(canvas: Canvas) {
        if (killed)
            return
        canvas.drawBitmap(
            bitmap, (x - bitmap.width / 2).toFloat(),
            (y - bitmap.height / 2).toFloat(), null
        )
    }

    fun update(width: Int, height: Int) {
        if (killed)
            return
        if (x + bitmap.width / 2 >= width)
        // narazil na pravy okraj
            dx = -dx
        if (x - bitmap.width / 2 <= 0)
        // narazil na lavy okraj
            dx = -dx
        if (y + bitmap.height / 2 >= height)
        // narazil na spodny okraj
            dy = -dy
        if (y - bitmap.height / 2 <= 40)
        // narazil na vrchny okraj
            dy = -dy
        if (!touched) {
            x += dx.toInt()
            y += dy.toInt()
        }
    }

    fun handleActionDown(eventX: Int, eventY: Int) {
        if (killed) return
        touched = (eventX >= x - bitmap.width / 2
                && eventX <= x + bitmap.width / 2 && eventY >= y - bitmap
            .height / 2 && y <= y + bitmap.height / 2)
    }
}