package com.example.list

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class ParketyActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_parkety)
    }
}
