package com.example.runtimepermissions

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.Manifest
import android.content.DialogInterface
import android.content.pm.PackageManager
import android.util.Log
import android.widget.Button
import android.app.AlertDialog;
import androidx.core.app.ActivityCompat
import com.example.runtimepermission.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
    val RUNTIME_PERMISSION_REQUEST_CODE = 777
    val perms = arrayOf(
        Manifest.permission.WRITE_CONTACTS,
        Manifest.permission.CAMERA,
        Manifest.permission.ACCESS_FINE_LOCATION
    )
    val TAG = "Permissions"
    private lateinit var binding : ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //setContentView(R.layout.activity_main)
        Log.i(TAG, "askPermission started")
        val ask = binding.askButtonID // findViewById(R.id.askButtonID) as Button
        ask.setOnClickListener { view ->
            Log.i(TAG, "ask for runtime permission")
            if (applicationContext.checkSelfPermission(Manifest.permission.READ_CONTACTS) !=
                PackageManager.PERMISSION_GRANTED) {
                Log.i(TAG, "shows an explanation for why permission is needed")
                if (//false &&
                    shouldShowRequestPermissionRationale(Manifest.permission.READ_CONTACTS)) {
                    Log.i(TAG, "explain")
                    val builder = AlertDialog.Builder(this@MainActivity)
                    builder.setMessage("kto sa vela pyta, vela sa dozvie... !")
                    builder.setPositiveButton(android.R.string.ok,
                        DialogInterface.OnClickListener { dialog, which ->
                            requestPermissions(
                                perms,
                                RUNTIME_PERMISSION_REQUEST_CODE
                            )
                        }
                    )
                    builder.create().show()
                } else {
                    Log.i(TAG, "request")
                    ActivityCompat.requestPermissions(
                        this@MainActivity, perms,
                        RUNTIME_PERMISSION_REQUEST_CODE
                    )
                }
            } else {
                Log.i(TAG, "INTERNET granted")
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            RUNTIME_PERMISSION_REQUEST_CODE -> {
                for (i in grantResults.indices) {
                    if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                        Log.i(TAG, "GRANTED")
                    } else {  // denied
                        Log.i(TAG, "DENIED")
                    }
                }
                return
            }
        }
    }
}