package com.example.photodir

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.DocumentsContract
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.view.menu.MenuBuilder
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.photodir.databinding.ActivityMainBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MainActivity : AppCompatActivity() {

    private lateinit var imagesView: RecyclerView
    private var images: MutableList<ImageItem> = mutableListOf()
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        AppCompatDelegate.setDefaultNightMode(
            AppCompatDelegate.MODE_NIGHT_NO
        )


        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        val actionBar: ActionBar? = getSupportActionBar()
        if (actionBar != null) {
            actionBar.setDisplayShowTitleEnabled(false)
        }



        imagesView = binding.imgsView
        imagesView.layoutManager = LinearLayoutManager(this)
        imagesView.adapter = CustomAdapter(images) {
                pos -> deleteImage(pos) }

        startActivityForResult(
            Intent(Intent.ACTION_OPEN_DOCUMENT_TREE),
            rCode)

    }
    private val rCode = 999
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == rCode) {
            if (resultCode == RESULT_OK) {
                data?.let {
                    Toast.makeText(this, it.toString(), Toast.LENGTH_LONG).show()
                }
            }
        }
    }
    private fun deleteImage(pos:Int) {
        showDeleteDialog {
            if (DocumentsContract.deleteDocument(contentResolver, images[pos].uri)) {
                Toast.makeText(
                    this,
                    resources.getString(R.string.delete_image_success_message),
                    Toast.LENGTH_LONG
                ).show()

                images.removeAt(pos)
                imagesView.adapter?.notifyItemRemoved(pos)
            } else {
                Toast.makeText(
                    this,
                    resources.getString(R.string.delete_image_failure_message),
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
    private fun showDeleteDialog(posAnswerHandler: () -> Unit) {
        MaterialAlertDialogBuilder(this)
            .setTitle(resources.getString(R.string.delete_image_title))
            .setMessage(resources.getString(R.string.delete_image_message))
            .setPositiveButton(resources.getString(R.string.delete_image_accept)) { _, _ ->
                posAnswerHandler()
            }.setNegativeButton(resources.getString(R.string.delete_image_decline)) { _, _ -> }
            .show()
    }


    @SuppressLint("RestrictedApi")
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.image_context_menu, menu)
        (menu as? MenuBuilder)?.setOptionalIconsVisible(true)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        binding.apply {
            when (item.getItemId()) {
                R.id.deleteItem -> {
                    Log.i("TAG", "pause")
                    deleteImage(item.itemId)
                    return true
                }
                else -> return super.onOptionsItemSelected(item)
            }
        }
    }


}