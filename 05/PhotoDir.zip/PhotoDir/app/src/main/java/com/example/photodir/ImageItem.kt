package com.example.photodir

import android.net.Uri

data class ImageItem(val name: String, val lastModified: Long, val uri: Uri)
