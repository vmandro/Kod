package com.example.photodir

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.MenuInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.text.SimpleDateFormat
//import coil.load

class CustomAdapter(
    private val data: List<ImageItem>,
    private val deleteImage: (Int) -> Unit
): RecyclerView.Adapter<CustomAdapter.CustomViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CustomViewHolder =
        CustomViewHolder(
            LayoutInflater.from(parent.context)
                .inflate(R.layout.image_item, parent, false),
            deleteImage
        )

    @SuppressLint("SimpleDateFormat")
    override fun onBindViewHolder(holder: CustomViewHolder, position: Int) {
        val imgItem = data[position]
        // ??? holder.imageView.load(imgItem.uri)
        // https://developer.android.com/jetpack/compose/graphics/images/loading
        holder.nameView.text = imgItem.name
        holder.dateView.text =
            SimpleDateFormat("dd. MM. yyyy HH:mm").format(imgItem.lastModified)
    }

    override fun getItemCount(): Int = data.size

    class CustomViewHolder(view: View, deleteImage: (Int) -> Unit): RecyclerView.ViewHolder(view) {

        val imageView: ImageView = view.findViewById(R.id.imageView)
        val nameView: TextView = view.findViewById(R.id.imageNameView)
        val dateView: TextView = view.findViewById(R.id.imageDateView)

        init {
            view.setOnCreateContextMenuListener { menu, v, _ ->
                MenuInflater(v.context).inflate(R.menu.image_context_menu, menu)
                menu.getItem(0).setOnMenuItemClickListener {
                    deleteImage(adapterPosition)
                    return@setOnMenuItemClickListener true
                }
            }
        }
    }
}