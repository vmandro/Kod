package com.example.list

class SurfaceEmptyThread(val surfaceEmptyExample: SurfaceEmptyExample) : Thread() {
    var running = false
    private var paused = false
    private var stopped = false
    private val TAG = "SurfaceEmptyThread"

    override fun run() {
        val surfaceHolder = surfaceEmptyExample.holder
        while (running) {
            if (!paused) {
                if (!surfaceHolder.surface.isValid) {
                    continue
                }
                val canvas = surfaceHolder.lockCanvas()
                surfaceEmptyExample.draw(canvas)
                surfaceHolder.unlockCanvasAndPost(canvas)
            }
        }
    }


}