package com.example.list

import android.content.Context
import android.view.SurfaceHolder
import android.view.SurfaceView

class SurfaceEmptyExample(context: Context) : SurfaceView(context) , SurfaceHolder.Callback  {
    lateinit  var thread : SurfaceEmptyThread

    init {
        holder.addCallback(this)
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        thread.start()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        TODO("Not yet implemented")
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        var retry = true;
        thread.running = false;
        while (retry) {
            try {
                thread.join()
                retry = false
            } catch (e :InterruptedException) {
            }
        }
    }
}