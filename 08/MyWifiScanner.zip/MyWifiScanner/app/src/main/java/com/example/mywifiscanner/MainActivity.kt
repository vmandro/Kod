package com.example.mywifiscanner

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.TextView
import android.widget.Toast
import com.example.mywifiscanner.databinding.ActivityMainBinding

class MainActivity : Activity() {
    lateinit var wifiManager: WifiManager
    lateinit var broadcastReciever: BroadcastReceiver
    val TAG = "WiFi"
    val RUNTIME_PERMISSION_REQUEST_CODE = 777
    private lateinit var binding: ActivityMainBinding
    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "#0")
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        Log.d(TAG, "askPermission started")
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
            &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
            !=
            PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(
                Manifest.permission.ACCESS_WIFI_STATE,
                Manifest.permission.CHANGE_NETWORK_STATE,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION),
                RUNTIME_PERMISSION_REQUEST_CODE)
        }

        Log.d(TAG, "#1")
        wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        if (!wifiManager.isWifiEnabled) {
            wifiManager.setWifiEnabled(true)
        }
        Log.d(TAG, "#2")
        broadcastReciever = object : BroadcastReceiver() {
            //override fun onReceive(context: Context?, intent: Intent?) {
            override fun onReceive(context: Context, intent: Intent) {
                Toast.makeText(context,"#onreceive", Toast.LENGTH_SHORT).show()
                Log.d(TAG, "onReceive")
                val scanList = wifiManager.scanResults
                val wifis = arrayOfNulls<String>(scanList.size)
//                var i = 0
//                for (sr in scanList) {
//                    wifis[i++] = sr.SSID + // network name
//                            "," + sr.BSSID + // mac addr
//                            "," + sr.capabilities + // authent, key,
//                            // encryption
//                            // ","+sr.frequency + // channel in MHz
//                            "," + sr.level // db
//                }
                //Toast.makeText(context,"$#wifis${scanList.indices.count()}", Toast.LENGTH_SHORT).show()
                for (i in scanList.indices) {
                    val sr: ScanResult = scanList[i]
                    //Toast.makeText(context,"${sr.SSID}", Toast.LENGTH_SHORT).show()
                    wifis[i] = sr.SSID + // network name
                            "," + sr.BSSID + // mac addr
                            "," + sr.capabilities + // authent, key,
                            // encryption
                            // ","+sr.frequency + // channel in MHz
                            "," + sr.level // db
                }
                binding.listView1.adapter = object : ArrayAdapter<String>(
                    applicationContext,
                    android.R.layout.simple_list_item_1,
                    wifis) {
                    override fun getView(
                        position: Int,
                        convertView: View?,
                        parent: ViewGroup
                    ): View {
                        val view = super.getView(position, convertView, parent)
                        val tv = view.findViewById<TextView>(android.R.id.text1)
                        tv.setTextColor(Color.BLACK)
                        return view
                    }
                }

                (binding.listView1.adapter as BaseAdapter).notifyDataSetChanged()
                binding.listView1.postInvalidate()
            }
        }
        Toast.makeText(this,"#register", Toast.LENGTH_SHORT).show()
        registerReceiver(broadcastReciever, IntentFilter(
            WifiManager.SCAN_RESULTS_AVAILABLE_ACTION))
        Log.d(TAG, "registerReceiver")
        binding.button.setOnClickListener {
            Log.d(TAG, "start scanning")
            Toast.makeText(this,"#start scanning", Toast.LENGTH_SHORT).show()
            wifiManager.startScan()
        }
    }
    override fun onRequestPermissionsResult(requestCode: Int,
                                            permissions: Array<String>, grantResults: IntArray) {
        when (requestCode) {
            RUNTIME_PERMISSION_REQUEST_CODE -> {
                for (i in grantResults.indices) {
                    if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                        Log.d(TAG, "GRANTED")
                        Toast.makeText(this,"#GRANTED", Toast.LENGTH_SHORT).show()
                    } else {  // denied
                        Log.d(TAG, "DENIED")
                        Toast.makeText(this,"#DENIED", Toast.LENGTH_SHORT).show()
                    }
                }
                return
            }
        }
    }
    override fun onPause() {
        unregisterReceiver(broadcastReciever)
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
    }
}