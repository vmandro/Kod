package com.example.mygsmlocation

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.AsyncTask
import android.os.Bundle
import android.telephony.TelephonyManager
import android.telephony.gsm.GsmCellLocation
import android.util.JsonReader
import android.util.JsonWriter
import android.util.Log
import android.widget.Button
import android.widget.TextView
import com.example.mygsmlocation.databinding.ActivityMainBinding
//import kotlinx.android.synthetic.main.activity_main.*
import java.io.*
import java.lang.RuntimeException
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {
    lateinit var tm: TelephonyManager
    var token_locationAPIORG : String = "95b2941777892d" // asi davno uz neplati !!!
    var token_locationAPI : String = token_locationAPIORG
    val TAG = "MyGSMLocation"
    var mcc = 0
    var mnc = 0
    var cid = 0
    var lac = 0
    var lat = 0.0
    var lng = 0.0

    val RUNTIME_PERMISSION_REQUEST_CODE = 777
    val perms = arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.READ_PHONE_STATE
    )
    private lateinit var binding: ActivityMainBinding

    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        requestPermissions(
                perms,
                RUNTIME_PERMISSION_REQUEST_CODE
        )

        tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        binding.tokenEdit.setText(token_locationAPIORG)
            if (applicationContext.checkSelfPermission("") == PackageManager.PERMISSION_GRANTED) {
                val ci = tm.allCellInfo
            }
            binding.UpdateCellButton.setOnClickListener {
                val location = tm.cellLocation as GsmCellLocation
                cid = location.cid
                lac = location.lac
                Log.d(TAG, "gsm cid: $cid")
                Log.d(TAG, "gsm lac: $lac")
                val networkOperator = tm.networkOperator
                Log.d(TAG, "operator: $networkOperator")
                if (networkOperator.length > 0) {
                    Log.d(TAG, "network: $networkOperator")
                    try {
                        mcc = Integer.parseInt(networkOperator.substring(0, 3))
                        mnc = Integer.parseInt(networkOperator.substring(3))
                        Log.d(TAG, "mcc: $mcc")
                        Log.d(TAG, "mnc: $mnc")
                        token_locationAPI = binding.tokenEdit.text.toString()
                        if (token_locationAPI === "")
                            token_locationAPI = token_locationAPIORG
                        getLocationApiORGCellID()
                        /*
                             * Check if the current cell is a UMTS (3G) cell. If a 3G
                             * cell the cell id padding will be 8 numbers, if not 4
                             * numbers.
                             */
                        var cellPadding = 4
                        if (tm.networkType == TelephonyManager.NETWORK_TYPE_UMTS) {
                            cellPadding = 8
                        }
                        binding.apply {
                            textview01.text =
                                "CellID: ${getPaddedHex(cid, cellPadding)}, $cid"
                            textview02.text = "Lac: ${getPaddedHex(lac, 4)},$lac"
                            textview03.text = "Mcc: ${getPaddedInt(mcc, 3)}"
                            textview04.text = "Mnc: ${getPaddedInt(mnc, 2)}"
                        }
                    } catch (e: NumberFormatException) {
                    }
                }
            }
            val mapButton = findViewById(R.id.mapButton) as Button
            mapButton.setOnClickListener {
                Log.d(TAG, "geo:$lat,$lng")
                val myIntent = Intent(
                        android.content.Intent.ACTION_VIEW,
                        Uri.parse("geo:0,0?q=$lat,$lng"))
                startActivity(myIntent)
            }
    }
    // skonveruje na HEX a doplni nulami spredu
    fun getPaddedHex(nr: Int, minLen: Int): String {
        try {
            var str: String = Integer.toHexString(nr)
            while (str.length < minLen) str = "0$str"
            return str
        } catch (e : RuntimeException) {
            return ""
        }
    }
    // doplni nulami spredu
    fun getPaddedInt(nr: Int, minLen: Int): String {
        try {
            var str: String = Integer.toString(nr)
            while (str.length < minLen) str = "0$str"
            return str
        } catch (e : RuntimeException) {
            return ""
        }
    }

    @SuppressLint("StaticFieldLeak")
    private fun getLocationApiORGCellID() {
        val ast = object : AsyncTask<String, Int, String>() {
            override fun doInBackground(vararg params: String): String? {
                try {
                    val sw = StringWriter()
                    val jw = JsonWriter(sw)
                    try {
                        jw.beginObject()
                        jw.name("token").value(token_locationAPI)
                        jw.name("mcc").value(mcc.toLong())
                        jw.name("mnc").value(mnc.toLong())
                        jw.name("cells")
                        jw.beginArray().beginObject()
                        jw.name("cid").value(cid.toLong())
                        jw.name("lac").value(lac.toLong())
                        jw.name("signal").value(-60)
                        jw.name("tA").value(13)
                        jw.endObject().endArray().endObject()
                    } finally {
                        try {
                            jw.close()
                        } catch (ioe: IOException) {
                        }

                        try {
                            sw.close()
                        } catch (ioe: IOException) {
                        }
                    }
                    val JsonParams = sw.toString()
                    Log.d(TAG, JsonParams)
                    val locationapiUrl = params[0] // "http://locationapi.org/v2/process.php"
                    val url = URL(locationapiUrl)
                    val httpClient  = url.openConnection() as HttpURLConnection
                    httpClient.requestMethod = "POST"
                    httpClient.setRequestProperty("Accept", "application/json")
                    httpClient.setRequestProperty("Content-type", "application/json")
                    val wr = OutputStreamWriter(httpClient.getOutputStream())
                    wr.write(JsonParams);
                    wr.flush();
                    Log.d(TAG, "URL : $url")
                    httpClient.connect()
                    Log.d(TAG,
                            "statusLine:" + httpClient.responseCode)
                    if (httpClient.responseCode == HttpURLConnection.HTTP_OK) {
                        val br = BufferedReader(
                                InputStreamReader(httpClient.inputStream))
                        val result = StringBuilder()
                        br.forEachLine { result.append(it) }
                        StringBuilder()
                        Log.d(TAG, result.toString())
                        return result.toString()
                    } else
                        return null
                } catch (e: Exception) {
                    Log.e(TAG,
                            "Error in http-post connection " + e.message)
                    e.printStackTrace()
                    return null
                }
            }

            override fun onPostExecute(result: String?) {
                super.onPostExecute(result)
                if (result != null) {
                    try {
                        val sr = StringReader(result)
                        val jr = JsonReader(sr)
                        jr.beginObject()
                        Log.d(TAG, jr.nextName())
                        Log.d(TAG, jr.nextString())

                        Log.d(TAG, jr.nextName())
                        Log.d(TAG, "balance:" + jr.nextInt())

                        Log.d(TAG, jr.nextName())
                        // Log.d(TAG,jr.nextDouble);
                        lat = jr.nextDouble()
                        Log.d(TAG, "" + lat)
                        (findViewById(R.id.textview06) as TextView).text = "Lat: $lat"

                        Log.d(TAG, jr.nextName())
                        lng = jr.nextDouble()
                        (findViewById(R.id.textview07) as TextView).text = "Long: $lng"

                        Log.d(TAG, jr.nextName())
                        (findViewById(R.id.textview08) as TextView).text = "Range: ${jr.nextInt()}"
                    } catch (e: Exception) {
                        Log.e(TAG,
                                "Error onExecute " + e.message)
                        e.printStackTrace()
                    }

                }

            }

            override fun onPreExecute() {
                super.onPreExecute()
            }
        }
        ast.execute("https://locationapi.org/v2/process.php")
    }

    override fun onRequestPermissionsResult(
            requestCode: Int,
            permissions: Array<String>, grantResults: IntArray
    ) {
        when (requestCode) {
            RUNTIME_PERMISSION_REQUEST_CODE -> {
                for (i in grantResults.indices) {
                    if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                        Log.d("WiFi", "GRANTED")
                    } else {  // denied
                        Log.d("WiFi", "DENIED")
                    }
                }
                return
            }
        }
    }
}