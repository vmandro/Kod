package com.example.mylocation2

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Criteria
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.example.mylocation2.databinding.ActivityMainBinding

import java.util.ArrayList
import java.util.Date
import java.util.HashMap

class MainActivity : Activity(), LocationListener {
    lateinit var lm: LocationManager
    lateinit var provider: String

    internal val REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS = 777
    private lateinit var binding: ActivityMainBinding

    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        addPermissions()

        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager

        val cr = Criteria()
        cr.isAltitudeRequired = false
        cr.accuracy = Criteria.ACCURACY_COARSE // hruba presnost
        // cr.setAccuracy(Criteria.ACCURACY_FINE); // fajnova presnost
        cr.powerRequirement = Criteria.POWER_LOW
        cr.isSpeedRequired = false

        Log.d("MyLoc", "all providers:${lm.allProviders}")

        provider = LocationManager.GPS_PROVIDER
        // lm.NETWORK_PROVIDER;
        //lm.getBestProvider(cr, false); // get all providers enabled or disables
        //lm.getBestProvider(cr, true); // get all enabled providers
        if (provider == LocationManager.GPS_PROVIDER) {
            val gpsEnabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER)
            if (!gpsEnabled) {
                val settingsIntent = Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                startActivity(settingsIntent)
            } else
                Log.d("MyLoc", "GPS is enabled")
        }
        try {
            if (provider != null) {
                val loc = lm.getLastKnownLocation(provider)
                updateLocation(loc)
            }
        } catch (e: SecurityException) {
            Log.e("MyLoc", "security exception: " + e.message)
        }

    }

    fun updateLocation(loc: Location?) {
        if (loc != null) {
            Log.d("MyLoc","Location: ${loc.latitude}:${loc.longitude}")
            binding.apply {
                tvLati.text = "Lat: ${loc.latitude}"
                tvLongi.text = "Long: ${loc.longitude}"
                tvAccur.text = "Accur: ${loc.accuracy}"
                tvProvider.text = "Provider: ${loc.provider}"
                tvAltit.text = "Altitude: ${loc.altitude}"
                tvSpeed.text = "Speed: ${loc.speed}"
                tvBearing.text = "Bearing: ${loc.bearing}"
                tvTime.text = "Time: ${loc.time} ... ${Date(loc.time).toLocaleString()}"
            }
        } else {
            Log.d("MyLoc", "unknown location")
        }
    }

    override fun onResume() {
        super.onResume()
        // kazdu sekundu, resp. ak sme presli aspon 10 metrov
        //lm.requestLocationUpdates(provider, 1000, 10, this);
        // cim skor
        try {
            lm.requestLocationUpdates(provider, 0, 0f, this)
        } catch (e: SecurityException) {
            Log.e("MyLoc", "security exception: " + e.message)
        }

    }

    override fun onPause() {
        super.onPause()
        // patri sa to vypnut
        lm.removeUpdates(this)
    }

    //@TargetApi(Build.VERSION_CODES.M)
    private fun addPermission(permissionsList: MutableList<String>, permission: String): Boolean {
        if (applicationContext.checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
            permissionsList.add(permission)
            // Check for Rationale Option
            if (!shouldShowRequestPermissionRationale(permission)) return false
        }
        return true
    }

    private fun showMessageOKCancel(message: String, okListener: DialogInterface.OnClickListener) {
        AlertDialog.Builder(this@MainActivity)
            .setMessage(message)
            .setPositiveButton("OK", okListener)
            .setNegativeButton("Cancel", null)
            .create()
            .show()
    }

    private fun addPermissions() {
        // the only way we insert the dummy contact if if we are below M.
        // Else we continue on and prompt the user for permissions
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return
        }

        val permissionsNeeded = ArrayList<String>()

        val permissionsList = ArrayList<String>()
        if (!addPermission(permissionsList, Manifest.permission.ACCESS_FINE_LOCATION))
            permissionsNeeded.add("GPS")
        if (permissionsList.size > 0) {
            if (permissionsNeeded.size > 0) {
                // Need Rationale
                var message = "You need to grant access to " + permissionsNeeded[0]
                for (i in 1 until permissionsNeeded.size)
                    message = message + ", " + permissionsNeeded[i]
                showMessageOKCancel(message,
                    DialogInterface.OnClickListener { dialog, which ->
                        //@Override
                        requestPermissions(permissionsList.toTypedArray<String>(),
                            REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS)
                    })
                return
            }
            requestPermissions(permissionsList.toTypedArray<String>(),
                REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        when (requestCode) {
            REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS -> {
                val perms = HashMap<String, Int>()
                // Initial
                perms[Manifest.permission.ACCESS_FINE_LOCATION] = PackageManager.PERMISSION_GRANTED
                //perms.put(Manifest.permission.READ_CONTACTS, PackageManager.PERMISSION_GRANTED);
                //perms.put(Manifest.permission.WRITE_CONTACTS, PackageManager.PERMISSION_GRANTED);
                // Fill with results
                for (i in permissions.indices)
                    perms[permissions[i]] = grantResults[i]
                // Check for ACCESS_FINE_LOCATION
                if (perms[Manifest.permission.ACCESS_FINE_LOCATION] == PackageManager.PERMISSION_GRANTED &&
                    //perms.get(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED &&
                    //perms.get(Manifest.permission.WRITE_CONTACTS) == PackageManager.PERMISSION_GRANTED &&
                    true) {
                    // All Permissions Granted
                } else {
                    // Permission Denied
                    Toast.makeText(this@MainActivity, "Some Permission is Denied", Toast.LENGTH_SHORT)
                        .show()
                }
            }
            else -> super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        }
    }


    override fun onLocationChanged(arg0: Location) {
        Log.d("MyMap",
            "onLocationChanged:" + arg0.latitude + ":"
                    + arg0.longitude)
        updateLocation(arg0)
    }

    override fun onProviderDisabled(arg0: String) {
        Log.d("MyMap", "onProviderDisabled:$arg0")
    }

    override fun onProviderEnabled(arg0: String) {
        Log.d("MyMap", "onProviderEnabled:$arg0")
    }

    override fun onStatusChanged(arg0: String, arg1: Int, arg2: Bundle) {
        Log.d("MyMap", "onStatusChanged")
    }

}