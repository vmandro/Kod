package com.example.cvicenie9

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.*
import android.content.pm.PackageManager
import android.location.Criteria
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.preference.PreferenceManager.getDefaultSharedPreferences
import android.provider.ContactsContract
import android.telephony.SmsManager
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.example.cvicenie9.R
import com.example.cvicenie9.databinding.ActivityMainBinding
import java.lang.Exception
import java.text.SimpleDateFormat
import java.util.*

@Suppress("DEPRECATION")
class MainActivity : AppCompatActivity(), LocationListener {
    val TAG = "SOS"
    // callback codes
    internal val REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS = 777
    internal val RESULT_PICK_CONTACT = 888

    private lateinit var binding : ActivityMainBinding
    // GPS
    lateinit var lm : LocationManager
    lateinit var provider : String
    lateinit var lastLocation : Location  // last known location

    // wifi
    lateinit var wifiManager : WifiManager
    // ------------- WIFI
    val broadcastReceiver = object : BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        override fun onReceive(context: Context?, intent: Intent?) {
            val scanList = wifiManager.scanResults
            binding.wifiTV.text = scanList
                .map { it.SSID }
                .filter{it.isNotEmpty()}
                .toSet()
                .joinToString(separator = ", ")
        }
    }

    // prefs
    lateinit var sharedPrefs : SharedPreferences
    val userNameSPKey = "username"
    val userNameSPDefaultValue = "NULL"

    val phoneNumberSPKey = "phonenumber"
    val phoneNumberSPDefaultValue = "123"

    val useWifiSPKey = "useWifi"
    val useGPSSPKey = "useGPS"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        // ----- Preferences & Settings
        sharedPrefs = getDefaultSharedPreferences(this)
        sharedPrefs.getString(userNameSPKey, userNameSPDefaultValue)
        sharedPrefs.getString(phoneNumberSPKey, phoneNumberSPDefaultValue)
        // ----- permissions
        addPermissions()

        // ----- GPS
        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        provider = LocationManager.GPS_PROVIDER
        displayPreferences()
        // ----- WIFI
        if (sharedPrefs.getBoolean(useWifiSPKey, true)) {
            wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            if (!wifiManager.isWifiEnabled) {
                wifiManager.isWifiEnabled = true
            }
            registerReceiver(broadcastReceiver, IntentFilter(
                WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)
            )
        }
    }
    @SuppressLint("MissingPermission")
    fun setupLocationManager() {
        val criteria = Criteria()
        criteria.isAltitudeRequired = false
        criteria.accuracy = Criteria.ACCURACY_COARSE
        criteria.powerRequirement = Criteria.POWER_LOW
        criteria.isBearingRequired = false
        criteria.isSpeedRequired = false
        if (sharedPrefs.getBoolean(useGPSSPKey, true)) {
            provider = LocationManager.GPS_PROVIDER
        } else {
            provider = lm.getBestProvider(criteria, false) ?: LocationManager.GPS_PROVIDER
        }
        if (!lm.isProviderEnabled(provider)) {
            val gpsSettingIntent =
                Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            startActivity(gpsSettingIntent)
        }
        try {
            val loc = lm.getLastKnownLocation(provider)
            if (loc != null)
                lastLocation = loc
            Log.d(TAG, "$lastLocation")
        } catch (e: Exception) {
            Log.e(TAG, e.toString())
        }
    }

    // Setting menu -----------------------------------------------
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.settings, menu)
        return true
    }
    val RESULT_SETTINGS = 999
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.getItemId()) {
            R.id.menu_settings -> {
                val i = Intent(this, SettingActivity::class.java)
                startActivityForResult(i, RESULT_SETTINGS)
            }
        }
        return true
    }
    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent? ) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            RESULT_SETTINGS -> displayPreferences()
            RESULT_PICK_CONTACT -> {
                if (resultCode == RESULT_OK) {
                    try {
                        val uri: Uri? = data?.data
                        if (uri != null) {
                            val cursor = contentResolver.query(uri, null, null, null, null)
                            if (cursor != null) {
                                cursor.moveToFirst()
                                val phoneIndex: Int =
                                    cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                                val nameIndex: Int =
                                    cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                                sharedPrefs = getDefaultSharedPreferences(this)
                                val editor = sharedPrefs.edit()
                                editor.putString(userNameSPKey, cursor.getString(nameIndex))
                                editor.putString(phoneNumberSPKey, cursor.getString(phoneIndex))
                                editor.commit()
                                displayPreferences()
                            }
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                } else {
                    Log.e("Failed", "Not able to pick contact")
                }
            }
        }
    }
    /*
        podla sharedPreferencies zobrazi/nastavi views
     */
    fun displayPreferences() {
        sharedPrefs = getDefaultSharedPreferences(this)
        val uname = sharedPrefs.getString(userNameSPKey, userNameSPDefaultValue)
        //Toast.makeText(this,"${uname}", Toast.LENGTH_LONG).show()
        val pnumber = sharedPrefs.getString(phoneNumberSPKey, phoneNumberSPDefaultValue)
        binding.scanWifiBtn.visibility = if (sharedPrefs.getBoolean(useWifiSPKey, true)) View.VISIBLE else View.GONE
        binding.iceTV.text = "ICE:$uname/$pnumber"
        setupLocationManager()
        binding.locateGpsBtn.text = provider
    }
    //----- permissions
    private val permissions = mapOf(
        "GPS-F" to Manifest.permission.ACCESS_FINE_LOCATION,
        "SMS"   to Manifest.permission.SEND_SMS,
        "WIFI1" to Manifest.permission.ACCESS_WIFI_STATE,
        "WIFI2" to Manifest.permission.CHANGE_NETWORK_STATE,
        "INTERNET" to Manifest.permission.INTERNET
    )

    private fun addPermissions() {
        // ak minSDK bude >= 23, tak toto je zbytocny riadok
        val permissionsNeeded = mutableListOf<String>()
        val permissionsList = mutableListOf<String>()

        // asi kandidat na prepisanie krajsie, vivat filter benovsky !
        for ((pname, pvalue) in permissions) {
            if (addPermission(permissionsList, pvalue))
                permissionsNeeded.add(pname)
        }

        if (permissionsList.size > 0) {
            if (permissionsNeeded.size > 0) {
                showMessageOKCancel(
                    "You need to grant access to: ${permissionsNeeded.joinToString(separator = ", ")}",
                    DialogInterface.OnClickListener { dialog, which ->
                        requestPermissions(permissionsList.toTypedArray<String>(),
                            REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS)
                    })
                return
            }
            requestPermissions(permissionsList.toTypedArray<String>(),
                REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS)
        }
    }
    @RequiresApi(Build.VERSION_CODES.M)
    private fun addPermission(permissionsList: MutableList<String>,
                              permission: String): Boolean {
        if (applicationContext.checkSelfPermission(permission)
            != PackageManager.PERMISSION_GRANTED) {
            permissionsList.add(permission)
            if (!shouldShowRequestPermissionRationale(permission)) return true
        }
        return false
    }
    private fun showMessageOKCancel(message: String, okListener: DialogInterface.OnClickListener) {
        AlertDialog.Builder(this@MainActivity)
            .setMessage(message)
            .setPositiveButton("OK", okListener)
            .setNegativeButton("Cancel", null)
            .create()
            .show()
    }

    // ---- GPS
    override fun onProviderDisabled(arg0: String) {
        Log.d(TAG, "onProviderDisabled:$arg0")
    }

    override fun onProviderEnabled(arg0: String) {
        Log.d(TAG, "onProviderEnabled:$arg0")
    }

    override fun onStatusChanged(arg0: String, arg1: Int, arg2: Bundle) {
        Log.d(TAG, "onStatusChanged")
    }
     override fun onLocationChanged(loc: Location) {
        lastLocation = loc
        Log.d(TAG, "onLocationChanged: lat:${loc.latitude}, long: ${loc.longitude}")
         lastLocation.display()
    }
    override fun onResume() {
        super.onResume()
        try {
            lm.requestLocationUpdates(provider, 2000, 10f, this)
        } catch (e: SecurityException) {
            Log.e(TAG, "security exception: " + e.message)
        }
    }
    override fun onPause() {
        super.onPause()
        // patri sa to vypnut
        lm.removeUpdates(this)
    }
    //-------------- SEND SMS
    fun Date.toString(format: String, locale: Locale = Locale.getDefault()): String {
        val formatter = SimpleDateFormat(format, locale)
        return formatter.format(this)
    }

    fun getCurrentDateTime(): Date {
        return Calendar.getInstance().time
    }

    fun sendSmsClicked(v : View) {
        val smsManager = SmsManager.getDefault()
        sharedPrefs = getDefaultSharedPreferences(this)
        val uname = sharedPrefs.getString(userNameSPKey, userNameSPDefaultValue)
        val pnumber = sharedPrefs.getString(phoneNumberSPKey, phoneNumberSPDefaultValue)
        repeat ((sharedPrefs.getString("repCount", "0")?:"0").toInt()) {
            val message = "$it...Ahoj $uname, moja poloha " +
                    "v case ${getCurrentDateTime().toString("yyyy/MM/dd HH:mm:ss")} " +
                    "je: ${lastLocation.latitude}, ${lastLocation.longitude}"
            smsManager.sendTextMessage(pnumber, null, message, null, null)
        }

        /*
        val intent = Intent(Intent.ACTION_VIEW)
        intent.data = Uri.parse("sms:")
        intent.putExtra("sms_body", message)
        intent.setType("vnd.android-dir/mms-sms")
        startActivity(intent)
        */
    }
    //-------------- GPS
    fun Location.display() {
        binding.lastLocationTV.text = "${"%.4f".format(latitude)}, ${"%.4f".format(longitude)}/$provider"
    }
    @SuppressLint("MissingPermission")
    fun gpsClicked(v : View) {
        val loc = lm.getLastKnownLocation(provider)
        Toast.makeText(this@MainActivity, loc.toString(), Toast.LENGTH_SHORT).show()
        if (loc != null) {
            lastLocation = loc
            lastLocation.display()
        }
    }
    //-------------- WIFI
    fun scanWifiClicked(v : View) {
        wifiManager.startScan()
    }
    //-------------- CONTACT PICKER
    fun contactPickerClicked(v : View) {
        val contactPickerIntent = Intent(Intent.ACTION_PICK,
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI)
        startActivityForResult(contactPickerIntent, RESULT_PICK_CONTACT)
    }
}