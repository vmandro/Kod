package com.example.pikatchumvvm

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import com.example.pikatchumvvm.databinding.FragmentMainBinding
import com.example.pikatchumvvm.BR.*

class MainFragment : Fragment() {
    companion object {  // statická metoda
        fun newInstance() = MainFragment()
    }
    private lateinit var viewModel: PikaViewModel
    lateinit var binding : FragmentMainBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {
        //return inflater.inflate(R.layout.main_fragment, container, false)
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_main, container, false)
        binding.setLifecycleOwner(this)
        return binding.root
    }
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(PikaViewModel::class.java)
        binding.setVariable(pikaViewModel, viewModel)
        viewModel.addDrawables(Repository.allDravables(requireContext()))
        //binding.executePendingBindings()
        //
        val finishObserver = Observer<Boolean> {
                 result -> activity?.finish()
        }
        viewModel.finish.observe(viewLifecycleOwner, finishObserver)
        }
}