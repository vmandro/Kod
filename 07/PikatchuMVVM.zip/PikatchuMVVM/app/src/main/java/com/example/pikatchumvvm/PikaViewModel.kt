package com.example.pikatchumvvm

import android.graphics.drawable.Drawable
import android.os.CountDownTimer
import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class PikaViewModel: ViewModel() {
    val TAG = "PIKA"
    val index : MutableLiveData<Int> = MutableLiveData()
    val time : MutableLiveData<Int> = MutableLiveData()
    val currentImg: MutableLiveData<Drawable> = MutableLiveData()
    val finish: MutableLiveData<Boolean> = MutableLiveData()
    var list = mutableListOf<Drawable>()

    init {
        Log.d(TAG, "PikaModelView created")
        index.value = 0
        time.value = 0
        list = mutableListOf<Drawable>()
        object : CountDownTimer(20000,1000) {
            override fun onTick(p0: Long) {
                time.postValue((time.value?:0)+1)
            }
            override fun onFinish() {
                finish.value = true
            }
        }.start()
    }
    fun nextValue() {
        index.value = ((index.value?:0)+1)%(list.size)
        updateCurrentImg()
    }
    fun prevValue() {
        var v = index.value?:0
        v--
        index.value = v
        if (v < 0)
            index.value = list.size - 1
        updateCurrentImg()
    }
    fun addDrawables(images: List<Drawable>) {
        list.addAll(images)
        updateCurrentImg()
    }
    fun updateCurrentImg() {
        if (list.count() > 0)
            currentImg.value = list[index.value?:0]
    }
}