package com.example.jetpack1.ui.main

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.jetpack1.R
import com.example.jetpack1.databinding.MainFragmentBinding

class MainFragment : Fragment() {
    companion object {  // statická metoda
        fun newInstance() = MainFragment()
    }
    private lateinit var binding : MainFragmentBinding
    private lateinit var viewModel: MainViewModel
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {
        binding = MainFragmentBinding.inflate(inflater, container, false)
        //return inflater.inflate(R.layout.main_fragment, container, false)
        return binding.root
    }
    @Deprecated("Deprecated in Java")
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)
        binding.apply {
            convertBtn.setOnClickListener {
                if (inputAmount.text.isNotEmpty()) {
                    viewModel.setInputCurrencyAmount(inputAmount.text.toString())
                    viewModel.convertUSD2EURO = usd2euro.isChecked
                    outputAmount.setText("%.2f".format(viewModel.outputCurrencyAmount))
                }
            }
        }
    }
}