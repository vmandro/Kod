package com.example.jetpack1.ui.main

import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {
    val dolar2euroRate = 0.95f
    var convertUSD2EURO = true
    var inputCurrencyAmount = 0f
    var outputCurrencyAmount = 0f

    //fun setConvertUSD2EURO(usd2euro : Boolean) { }
    fun setInputCurrencyAmount(value : String) {
        inputCurrencyAmount = value.toFloat()
        outputCurrencyAmount =  if  (convertUSD2EURO) inputCurrencyAmount * dolar2euroRate
                                else inputCurrencyAmount / dolar2euroRate
    }
    //fun getOutputCurrencyAmount(): Float = outputCurrencyAmount
}