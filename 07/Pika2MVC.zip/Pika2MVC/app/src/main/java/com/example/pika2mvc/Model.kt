package com.example.pika2mvc

import android.graphics.drawable.Drawable
import java.util.*

class Model : Observable {
    var indx = 0
    var list = arrayOf<Drawable>()

}