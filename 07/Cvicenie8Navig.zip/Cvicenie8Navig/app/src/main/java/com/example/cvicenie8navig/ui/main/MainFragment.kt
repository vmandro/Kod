package com.example.cvicenie8navig.ui.main

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.Navigation
import com.example.cvicenie8navig.R
import com.example.cvicenie8navig.databinding.MainFragmentBinding


class MainFragment : Fragment() {

    companion object {
        fun newInstance() = MainFragment()
    }

    private lateinit var viewModel: MainViewModel
    private lateinit var binding : MainFragmentBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding  = MainFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)

//        val controller = NavHostFragment.findNavController(this)
//        controller.navigate(R.id.action_forgot)
        binding.apply {
            loginBtn.setOnClickListener {
                val laction = MainFragmentDirections.actionLogin()
                laction.userEmail = userEmailEDT.text.toString()
                laction.password = userPasswordEDT.text.toString()
                Navigation.findNavController(it).navigate(laction)
            }

            forgetBtn.setOnClickListener {
                val faction = MainFragmentDirections.actionForgot()
                Navigation.findNavController(it).navigate(faction)
            }
            registerBtn.setOnClickListener {
                Navigation.findNavController(it).navigate(R.id.action_register)
            }
        }
    }

}