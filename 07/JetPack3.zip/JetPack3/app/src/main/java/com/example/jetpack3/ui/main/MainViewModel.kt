package com.example.jetpack3.ui.main

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {
    val dolar2euroRate = 0.95f
    var usd2euroChecked : MutableLiveData<Boolean> = MutableLiveData()
    var euro2usdChecked : MutableLiveData<Boolean> = MutableLiveData()
    var inputCurrencyAmount : MutableLiveData<String> = MutableLiveData()
    var outputCurrencyAmount : MutableLiveData<Float> = MutableLiveData()
    init {
        usd2euroChecked.value = true
        euro2usdChecked.value = false
        inputCurrencyAmount.value = ""
        outputCurrencyAmount.value = 0f
    }
    fun convertValue() {
        inputCurrencyAmount.let {
            if ((it.value?:"").isNotEmpty()) {
                if (usd2euroChecked.value?:false)
                    //outputCurrencyAmount.value = it.value?.toFloat()?.times(dolar2euroRate)
                    outputCurrencyAmount.value = (it.value?:"0").toFloat() * dolar2euroRate
                else
                    //outputCurrencyAmount.value = it.value?.toFloat()?.div(dolar2euroRate)
                    outputCurrencyAmount.value = (it.value?:"0").toFloat() / dolar2euroRate
            } else {
                outputCurrencyAmount.value = 0f
            }
        }
    }
}