package com.example.jetpacknav.ui.main

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.Navigation
import com.example.jetpacknav.databinding.MainFragmentBinding

class MainFragment : Fragment() {

    companion object {
        fun newInstance() = MainFragment()
    }
    private lateinit var viewModel: MainViewModel
    private lateinit var _binding: MainFragmentBinding
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding= MainFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)
//        val action = MainFragmentDirections.actionMainFragmentToBlankFragment(R.id.action_mainFragment_to_blankFragment)
//        action.setMessage(sourceText.text.toString())
//        action.setSize(44)
//        NavHostFragment.findNavController(this)

        binding.apply {
            button.setOnClickListener {
                val action = MainFragmentDirections.actionMainFragmentToBlankFragment(
                    size = sizeText.text.toString().toInt(),
                    message = sourceText.text.toString()
                )
                Navigation.findNavController(it).navigate(action)

//            val action2 = MainFragmentDirections.actionMainFragmentToBlankFragment2()
//            Navigation.findNavController(it).navigate(action2)
            }

            button2.setOnClickListener {
                val action = MainFragmentDirections.actionMainFragmentToBlankFragment2()
                Navigation.findNavController(it).navigate(action)
            }
        }
    }
}