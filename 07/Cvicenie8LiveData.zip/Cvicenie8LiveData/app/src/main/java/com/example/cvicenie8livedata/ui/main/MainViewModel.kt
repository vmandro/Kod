package com.example.cvicenie8livedata.ui.main

import android.view.View
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {
    private var args : MutableList<Int> = mutableListOf()
    private var ops : MutableList<Char> = mutableListOf()
    var display : MutableLiveData<String> = MutableLiveData()
    var isHexaVisible : MutableLiveData<Int> = MutableLiveData()

    init {
        display.value = ""
        isHexaVisible.value = View.VISIBLE
    }

    fun eval(args : List<Int>, ops : List<Char>) : Int {
        var res = args[0]
        (1 until args.size).forEach{
            i ->
            res = when (ops[i-1]) {
                '+' -> res + args[i]
                '*' -> res * args[i]
                '-' -> res - args[i]
                '/' -> res % args[i]
                else -> res
            }
        }
        return res
    }

    fun setHexaMode(isHexa : Boolean) {
        isHexaVisible.value = if (isHexa) View.VISIBLE else View.GONE
    }
    fun pressedButton(ch : Char) {
        when (ch) {
            in '0'..'9', in 'A'..'F' -> {
                display.value += ch
            }
            '=' -> {
                args.add((display.value?:"0").toInt())
                val res = eval(args, ops)
                display.value = res.toString()
                args.clear()
                ops.clear()
            }
            else -> {   // operator +-*/
                args.add((display.value?:"0").toInt())
                ops.add(ch)
                display.value = ""
            }
        }
    }
}