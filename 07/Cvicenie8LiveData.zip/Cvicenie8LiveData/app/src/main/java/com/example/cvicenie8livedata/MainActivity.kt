package com.example.cvicenie8livedata

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.cvicenie8livedata.ui.main.MainFragment

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity)
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.container1, MainFragment.newInstance())
                .replace(R.id.container2, MainFragment.newInstance())
                .commitNow()
        }
    }
}