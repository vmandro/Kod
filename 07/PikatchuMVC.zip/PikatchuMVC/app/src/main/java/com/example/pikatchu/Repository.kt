package com.example.pikatchu

import android.content.Context
import androidx.core.content.ContextCompat

class Repository {
    companion object {
        fun allDravables(context : Context) =
            listOf(R.drawable.butterfree,R.drawable.golbat, R.drawable.kakuna,
                R.drawable.raichu, R.drawable.venomoth,  R.drawable.venusaur,
                R.drawable.pok0, R.drawable.pok1, R.drawable.pok2, R.drawable.pok3,
                R.drawable.pok4, R.drawable.pok5, R.drawable.pok6)
                .map { ContextCompat.getDrawable(context.applicationContext, it)!! }
    }
}