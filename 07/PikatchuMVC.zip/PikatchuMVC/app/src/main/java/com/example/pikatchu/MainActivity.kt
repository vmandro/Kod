package com.example.pikatchu

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.pikatchu.databinding.ActivityMainBinding
import java.util.*

                    // Controller
class MainActivity : AppCompatActivity(), Observer {
	lateinit var myModel: Model
    lateinit var myView: MyView
    private lateinit var binding : ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater) // inflate layout
        setContentView(binding.root)
        myModel = Model()
        myModel.addObserver(this)   // model potrebuje pointer na Observera
        myModel.addDrawables(Repository.allDravables(this))
        // Repository potrebuju context :(
        myView = MyView(binding, this)   // views potrebuju context MainActivity
    }

    // interface Observer
    override fun update(arg0: Observable, arg1: Any?) {
       myView.update(myModel.currentDrawable)
    }
}