package com.example.pikatchu

import android.graphics.drawable.Drawable
import java.util.*

class Model() : Observable() {
    private var indx = 0
    private var list = mutableListOf<Drawable>()
    fun addDrawables(imgs: List<Drawable>) {
        list.addAll(imgs)
    }
    val currentDrawable: Drawable
        get() = list[indx]

    fun nextValue() {
        indx++
        indx %= list.size
        setChanged()
        notifyObservers()
    }

    fun prevValue() {
        indx--
        if (indx < 0) indx = list.size - 1
        setChanged()
        notifyObservers()
    }
}