package com.example.pikatchu

import android.graphics.drawable.Drawable
import android.util.Log
import android.widget.Toast
import com.example.pikatchu.databinding.ActivityMainBinding

class MyView(val binding: ActivityMainBinding, val main: MainActivity) {  // pointer na Controller
    init {
        binding.prevBtn.setOnClickListener {
            main.myModel.prevValue()
            Log.d("Pikatchu", "previous")
            Toast.makeText(main, "previous", Toast.LENGTH_SHORT).show()
        }
        binding.nextBtn.setOnClickListener {
            main.myModel.nextValue()
            Log.d("Pikatchu", "next")
            Toast.makeText(main, "next", Toast.LENGTH_SHORT).show()
        }
        update(main.myModel.currentDrawable)
    }
    fun update(im:Drawable) {
        binding.imageView1.setImageDrawable(im)
    }
}