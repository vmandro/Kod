package com.example.jetpack2.ui.main

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {
    val dolar2euroRate = 0.95f
    var convertUSD2EURO = true
        set(value) { field = value }

    private val _outputCurrencyAmount : MutableLiveData<Float> = MutableLiveData()
    val outputCurrencyAmount : LiveData<Float>
        get() = _outputCurrencyAmount

    var inputCurrencyAmount = 0f
        set (value : Float) {
            field = value
            _outputCurrencyAmount.value =  if  (convertUSD2EURO) inputCurrencyAmount * dolar2euroRate
            else inputCurrencyAmount / dolar2euroRate
    }



    //fun getOutputCurrencyAmount(): MutableLiveData<Float> = outputCurrencyAmount
}