package com.example.jetpack2.ui.main

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import com.example.jetpack2.R
import com.example.jetpack2.databinding.MainFragmentBinding

class MainFragment : Fragment() {
    companion object {  // statická metoda
        fun newInstance() = MainFragment()
    }
    private lateinit var viewModel: MainViewModel
    private lateinit var binding : MainFragmentBinding
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {
        binding = MainFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)
        binding.apply {
            val resultObserver = Observer<Float> { result ->
                outputAmount.setText("%.2f".format(result))
            }
            viewModel.outputCurrencyAmount.observe(viewLifecycleOwner, resultObserver)
            convertBtn.setOnClickListener {
                if (inputAmount.text.isNotEmpty()) {
                    viewModel.convertUSD2EURO = usd2euro.isChecked
                    viewModel.inputCurrencyAmount = inputAmount.text.toString().toFloat()
                }
            }
        }
    }
}