package com.example.cvicenie7

import android.annotation.SuppressLint
import android.content.ContentUris
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.exifinterface.media.ExifInterface
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import com.example.cvicenie7.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val REQUEST_CODE = 777
    private val TAG = "FOTOS"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        if (savedInstanceState == null) {
//            supportFragmentManager
//                .beginTransaction()
//                .replace(R.id.settings, SettingsFragment())
//                .commit()
//        }
//        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        binding.button.setOnClickListener {
            if (hasImagePermission()) {
                Log.i(TAG, "hladanie fotiek...")
                hladanieFotiek()
            } else {
                requestImagePermission()
            }
        }

        Log.i(TAG, "going to request image permission...")
        if (!hasImagePermission()) {
            requestImagePermission()
        }
    }

    private fun hasImagePermission(): Boolean {
        Log.i(TAG, "has image permission... ?")
        return when {
            Build.VERSION.SDK_INT >= 34 -> {
                checkSelfPermission(android.Manifest.permission.READ_MEDIA_IMAGES) ==
                    PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(android.Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) ==
                    PackageManager.PERMISSION_GRANTED
            }
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> {
                checkSelfPermission(android.Manifest.permission.READ_MEDIA_IMAGES) ==
                    PackageManager.PERMISSION_GRANTED
            }
            else -> {
                checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) ==
                    PackageManager.PERMISSION_GRANTED
            }
        }
    }

    private fun requestImagePermission() {
        Log.i(TAG, "requesting image permission...")
        when {
            Build.VERSION.SDK_INT >= 34 -> {
                requestPermissions(
                    arrayOf(
                        android.Manifest.permission.READ_MEDIA_IMAGES,
                        android.Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
                    ),
                    REQUEST_CODE
                )
            }
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> {
                requestPermissions(
                    arrayOf(android.Manifest.permission.READ_MEDIA_IMAGES),
                    REQUEST_CODE
                )
            }
            else -> {
                requestPermissions(
                    arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE),
                    REQUEST_CODE
                )
            }
        }
    }

    //------------------------------------------
    @SuppressLint("SetTextI18n")
    fun hladanieFotiek() {
        Log.i(TAG, "hladanie fotiek")
        binding.textView.text = ""

        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.MIME_TYPE
        )
        val selection = "${MediaStore.Images.Media.MIME_TYPE} IN (?, ?)"
        val selectionArgs = arrayOf("image/jpeg", "image/png")
        val sortOrder = "${MediaStore.Images.Media.DATE_TAKEN} DESC"
        val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI

        contentResolver.query(
            collection,
            projection,
            selection,
            selectionArgs,
            sortOrder
        )?.use { cursor ->
            val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
            Log.i(TAG, "obrazkov ${cursor.count}")

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idColumn)
                val fileName = cursor.getString(nameColumn) ?: "unknown"
                val imageUri = ContentUris.withAppendedId(collection, id)
                val details = StringBuilder(fileName)

                contentResolver.openInputStream(imageUri)?.use { inputStream ->
                    val exif = ExifInterface(inputStream)
                    listOf(
                        ExifInterface.TAG_APERTURE_VALUE,
                        ExifInterface.TAG_COMPRESSION,
                        ExifInterface.TAG_EXPOSURE_TIME,
                        ExifInterface.TAG_GPS_LATITUDE,
                        ExifInterface.TAG_GPS_LONGITUDE,
                        ExifInterface.TAG_DATETIME
                    ).forEach { tag ->
                        exif.getAttribute(tag)?.let { value ->
                            details.append(", $tag=$value")
                        }
                    }
                }

                Log.i(TAG, "obrazok $details")
                binding.textView.text = "${binding.textView.text}$details\n"
            }
        }
    }
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Log.i(TAG, "onRequest image permission...")
        when(requestCode) {
            REQUEST_CODE -> {
                if (hasImagePermission()) {
                    Log.i(TAG, "Image permission granted")
                } else {
                    Log.i(TAG, "Image permission denied")
                }
            }
        }
    }
}