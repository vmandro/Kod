package com.example.jetpack4.ui.main

import android.os.CountDownTimer
import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.SavedStateHandle

const val ELAPSEDTIMEKEY = "elapsedtimekey"
const val EDITBOXKEY = "editboxkey"

class MainViewModel(private val savedStateHandle: SavedStateHandle) : ViewModel() {
    var edittext : MutableLiveData<String> = savedStateHandle.getLiveData(EDITBOXKEY)
    var elapsedTime : MutableLiveData<Int> = savedStateHandle.getLiveData(ELAPSEDTIMEKEY)
    val TAG = "VM"

    init {
        object : CountDownTimer(100*1000, 1000) {
            override fun onTick(p0: Long) {
                elapsedTime.value = (elapsedTime.value?:0)+1
                savedStateHandle.set(ELAPSEDTIMEKEY, elapsedTime.value)
                savedStateHandle.set(EDITBOXKEY, edittext.value)
            }
            override fun onFinish() {   }
        }.start()
    }

    fun buttonClicked() {
        Log.d(TAG, "button clicked")
        edittext.value += "a"
        savedStateHandle.set(EDITBOXKEY, edittext.value)
    }
}