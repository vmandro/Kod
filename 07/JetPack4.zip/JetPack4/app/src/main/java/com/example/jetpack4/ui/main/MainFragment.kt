package com.example.jetpack4.ui.main

import android.content.Context
//import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.SavedStateViewModelFactory
import androidx.lifecycle.ViewModelProvider
//import androidx.lifecycle.ViewModelProviders
import com.example.jetpack4.R
import com.example.jetpack4.databinding.FragmentMainBinding
import com.example.jetpack4.BR.*
import com.example.jetpack4.MainActivity

class MainFragment : Fragment() {

    companion object {
        fun newInstance() = MainFragment()
    }

    private lateinit var viewModel: MainViewModel
    private var _binding : FragmentMainBinding? = null
    private val binding get() = _binding!!

//    private lateinit var mainActivity : MainActivity
//    override fun onAttach(context: Context) {
//        super.onAttach(context)
//        mainActivity = context as MainActivity
//    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = DataBindingUtil.inflate(inflater, R.layout.fragment_main, container, false)
        binding.lifecycleOwner = this
        return binding.root
    }
    lateinit var mainactivity : MainActivity
    override fun onAttach(context: Context) {
        super.onAttach(context)
        mainactivity = context as MainActivity
    }
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
//        activity?.application.let {
//            val factory = SavedStateViewModelFactory(it, this)
//            viewModel = ViewModelProvider(this, factory).get(MainViewModel::class.java)
//            //viewModel = ViewModelProvider(this).get(MainViewModel::class.java)
//            // v aplikacii
//            // viewModel = ViewModelProvider.AndroidViewModelFactory.getInstance(mainactivity.application).create(MainViewModel::class.java)
//        }

        val factory = SavedStateViewModelFactory(activity?.application, this)
        viewModel = ViewModelProvider(this, factory).get(MainViewModel::class.java)

        //viewModel = ViewModelProvider(this).get(MainViewModel::class.java)
        //viewModel = ViewModelProvider(this, factory).get(MainViewModel::class.java)
        // pridaj import com.example.jetpack4.BR.*
        binding.setVariable(myViewModel,viewModel)
    }
}