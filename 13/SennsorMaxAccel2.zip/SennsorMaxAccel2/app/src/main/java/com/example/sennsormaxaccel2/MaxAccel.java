//package com.example.sensor2;
//
//// Original Java source replaced after conversion to Kotlin.
//// See MaxAccel.kt in the same package for the Kotlin implementation.
