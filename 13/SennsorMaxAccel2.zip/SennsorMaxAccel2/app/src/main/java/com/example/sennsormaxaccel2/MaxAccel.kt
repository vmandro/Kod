package com.example.sennsormaxaccel2

import android.app.Activity
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Timer
import java.util.TimerTask
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.round
import kotlin.math.sqrt

class MaxAccel : AppCompatActivity(), SensorEventListener {

    private var currAcc: Float = 0f
    private var maxAcc: Float = 0f

    private lateinit var sensorManager: SensorManager
    private var timer: Timer? = null
    private lateinit var tvCurrAcc: TextView
    private lateinit var tvMaxAcc: TextView

    override fun onCreate(icicle: Bundle?) {
        super.onCreate(icicle)
        setContentView(R.layout.main)

        tvCurrAcc = findViewById(R.id.acc)
        tvMaxAcc = findViewById(R.id.maxAcc)

        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        val accelerometer: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        accelerometer?.also {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_FASTEST)
        }

        timer = Timer()
        // Use schedule instead of scheduleAtFixedRate to avoid lint warning about cached processes
        timer?.scheduleAtFixedRate(
        //timer?.schedule(object :
             object: TimerTask() {
            override fun run() {
                runOnUiThread {
                    tvCurrAcc.text = getString(R.string.curr_acc_format, currAcc / SensorManager.STANDARD_GRAVITY)
                    tvMaxAcc.text = getString(R.string.max_acc_format, maxAcc / SensorManager.STANDARD_GRAVITY)
                }
            }
        }, 0, 100)
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
        timer?.cancel()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onSensorChanged(event: SensorEvent) {
        val acc = abs(
            sqrt(
                event.values[0].toDouble().pow(2.0) +
                        event.values[1].toDouble().pow(2.0) +
                        event.values[2].toDouble().pow(2.0)
            ) - SensorManager.STANDARD_GRAVITY
        )
        currAcc = round(acc).toFloat()
        if (currAcc > maxAcc) {
            maxAcc = currAcc
        }
    }
}
