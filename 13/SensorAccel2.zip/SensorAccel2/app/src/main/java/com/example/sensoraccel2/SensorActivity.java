//package com.example.sensoraccel2;
//
//import java.io.BufferedOutputStream;
//import java.io.File;
//import java.io.FileNotFoundException;
//import java.io.FileOutputStream;
//import java.io.PrintStream;
//import java.util.List;
//
//import android.app.Activity;
//import android.hardware.Sensor;
//import android.hardware.SensorEvent;
//import android.hardware.SensorEventListener;
//import android.hardware.SensorManager;
//import android.os.Bundle;
//import android.os.Environment;
//import android.util.Log;
//import android.view.Menu;
//import android.widget.TextView;
//
//public class SensorActivity extends Activity implements SensorEventListener {
//	SensorManager sm;
//	Sensor sAcc;
//	TextView tvX;
//	TextView tvY;
//	TextView tvZ;
//	TextView tvTime;
//	TextView tvInfo;
//	long startTime = 0;
//	double speedX = 0;
//	double speedY = 0;
//	double speedZ = 0;
//	PrintStream ps;
//
//	@Override
//	public void onCreate(Bundle savedInstanceState) {
//		super.onCreate(savedInstanceState);
//		setContentView(R.layout.activity_sensor);
//
//		tvX = (TextView) findViewById(R.id.tvX);
//		tvY = (TextView) findViewById(R.id.tvY);
//		tvZ = (TextView) findViewById(R.id.tvZ);
//		tvTime = (TextView) findViewById(R.id.tvTime);
//		tvInfo = (TextView) findViewById(R.id.tvInfo);
//
//		sm = (SensorManager) getSystemService(SENSOR_SERVICE);
//		sAcc = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
//		if (sAcc == null)
//			Log.d("SEN", "nema accelerometer");
//		List<Sensor> lstsen = sm.getSensorList(Sensor.TYPE_ACCELEROMETER);
//		if (lstsen.size() > 0) {
//			tvInfo.setText(sAcc.getName() + ", maxRange:"
//					+ sAcc.getMaximumRange() + ", resol.:"
//					+ sAcc.getResolution() + ", minDelay:" + sAcc.getMinDelay());
//		}
//	}
//
//	public void onAccuracyChanged(Sensor sensor, int accuracy) {
//		Log.d("SEN", "accuracy:" + accuracy);
//	}
//
//	public void onSensorChanged(SensorEvent event) {
//		if (startTime == 0)
//			startTime = event.timestamp;
//
//		tvTime.setText("" + (event.timestamp - startTime));
//		tvX.setText("" + event.values[0]);
//		tvY.setText("" + (event.values[1]));
//		tvZ.setText("" + (event.values[2] - SensorManager.GRAVITY_EARTH));
//		if (ps != null)
//			ps.print(
//					(event.timestamp - startTime) + ";" +
//							event.values[0] + ";" +
//							event.values[1] + ";" +
//							(event.values[2] - SensorManager.GRAVITY_EARTH)
//							+"\n");
//	}
//
//	@Override
//	protected void onResume() {
//		super.onResume();
//		sm.registerListener(this, sAcc,
//		// SensorManager.SENSOR_DELAY_UI
//		// SensorManager.SENSOR_DELAY_FASTEST
//		// SensorManager.SENSOR_DELAY_NORMAL
//				SensorManager.SENSOR_DELAY_GAME);
//		try {
//			ps = new PrintStream(new FileOutputStream(new File(
//					Environment.getExternalStorageDirectory(), "accel.csv")));
//		} catch (FileNotFoundException e) {
//			Log.e("SEN", e.getMessage());
//		}
//
//	}
//
//	@Override
//	protected void onPause() {
//		super.onPause();
//		sm.unregisterListener(this);
//		if (ps != null)
//			ps.flush();
//	}
//
//	@Override
//	public boolean onCreateOptionsMenu(Menu menu) {
//		getMenuInflater().inflate(R.menu.activity_sensor, menu);
//		return true;
//	}
//}
