package com.example.sensoraccel2

import android.app.Activity
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.Menu
import android.widget.TextView
import java.io.File
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.io.PrintStream

class SensorActivity : Activity(), SensorEventListener {
    private lateinit var sm: SensorManager
    private var sAcc: Sensor? = null
    private lateinit var tvX: TextView
    private lateinit var tvY: TextView
    private lateinit var tvZ: TextView
    private lateinit var tvTime: TextView
    private lateinit var tvInfo: TextView
    private var startTime: Long = 0
    private var speedX = 0.0
    private var speedY = 0.0
    private var speedZ = 0.0
    private var ps: PrintStream? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sensor)

        tvX = findViewById(R.id.tvX)
        tvY = findViewById(R.id.tvY)
        tvZ = findViewById(R.id.tvZ)
        tvTime = findViewById(R.id.tvTime)
        tvInfo = findViewById(R.id.tvInfo)

        sm = getSystemService(SENSOR_SERVICE) as SensorManager
        sAcc = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (sAcc == null) Log.d("SEN", "nema accelerometer")
        val lstsen = sm.getSensorList(Sensor.TYPE_ACCELEROMETER)
        if (lstsen.size > 0) {
            sAcc?.let {
                tvInfo.text = "${it.name}, maxRange:${it.maximumRange}, resol.:${it.resolution}, minDelay:${it.minDelay}"
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        Log.d("SEN", "accuracy:$accuracy")
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (startTime == 0L) startTime = event.timestamp

        tvTime.text = "${event.timestamp - startTime}"
        tvX.text = "${event.values[0]}"
        tvY.text = "${event.values[1]}"
        tvZ.text = "${event.values[2] - SensorManager.GRAVITY_EARTH}"
        ps?.print(
            "${event.timestamp - startTime};${event.values[0]};${event.values[1]};${event.values[2] - SensorManager.GRAVITY_EARTH}\n"
        )
    }

    override fun onResume() {
        super.onResume()
        sAcc?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        try {
            ps = PrintStream(FileOutputStream(File(Environment.getExternalStorageDirectory(), "accel.csv")))
        } catch (e: FileNotFoundException) {
            Log.e("SEN", e.message ?: "File not found")
        }
    }

    override fun onPause() {
        super.onPause()
        sm.unregisterListener(this)
        ps?.flush()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.activity_sensor, menu)
        return true
    }
}

