package com.example.cvicenie5

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.util.AttributeSet
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View

class Playground(internal var context: Context, attrs: AttributeSet)
    : View(context, attrs),
    View.OnKeyListener {

    val balls = emptyList<Ball>().toMutableList()
    val blocks = emptyList<Block>().toMutableList()
    var pwidth = 0
    var pheight = 0

    companion object {  // staticke premenne
        var score = 0
    }
    init { // inicializacia
        setBackgroundColor(Color.YELLOW)

    }
    fun addBall() {
        if (pwidth == 0 || pheight == 0)
            return
        balls.add(Ball(context, pwidth, pheight))
    }
    fun addBlock() {
        if (pwidth == 0 || pheight == 0)
            return
        blocks.add(Block(context, pwidth, pheight))
    }
    fun update() {
        for (b in balls)
            b.update(blocks)
    }
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        pwidth = widthMeasureSpec
        pheight = heightMeasureSpec
    }
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        pwidth = w
        pheight = h
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        for (b in balls) {
            if (b.visible)
                b.draw(canvas)
        }
        for (b in blocks) {
             b.draw(canvas)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN) {
            for (b in balls) {
                if (b.isIn(event.x.toInt(), event.y.toInt())) {
                    b.visible = false
                      score += if (b.positive) 20 else 7
                }
            }
        }
        return super.onTouchEvent(event)
    }
    override fun onKey(arg0: View, arg1: Int, arg2: KeyEvent): Boolean {
        when (arg1) {
//            KeyEvent.KEYCODE_DPAD_LEFT -> block.update(-100,0)
//            KeyEvent.KEYCODE_DPAD_RIGHT -> block.update(100,0)
            else -> return false
        }
        invalidate()
        return true
    }
}
