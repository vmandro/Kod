package com.example.cvicenie5

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import kotlin.random.Random

class Block(context : Context, val width : Int, val height : Int) {
        var x = Random.nextInt(width)
        var y = Random.nextInt(height)
        var size = 20 + Random.nextInt(20)
        var speed = 2 + Random.nextInt(8)

    fun update() {
    }
    fun isIn(eventx : Int, eventy : Int) : Boolean = // toto je stvorec, asi by to chcelo rovnicu kruznice
        x <= eventx && eventx <= x+size
                &&
        y <= eventy && eventy <= y+size
   fun draw(canvas: Canvas) {
       val mPaint = Paint()
       mPaint.color = Color.parseColor("#906090")
       //canvas.drawCircle((x+size/2).toFloat(), (y+size/2).toFloat(), (size/2).toFloat(), mPaint)
       canvas.drawRect(x.toFloat(),y.toFloat(), (x+size).toFloat(), (y+size).toFloat(), mPaint)
   }
}