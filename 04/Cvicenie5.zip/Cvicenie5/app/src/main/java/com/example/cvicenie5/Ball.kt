package com.example.cvicenie5

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import kotlin.random.Random

class Ball(context : Context, val width : Int, val height : Int) {
        var x = Random.nextInt(width)
        var y = Random.nextInt(height)
        var size = 50 + Random.nextInt(50)
        var speed = 2 + Random.nextInt(8)
        var dx = 0
        var dy = 0
        var positive = Random.nextBoolean()
        var visible = true

    companion object { // staticky blok
        var ballCounter = 0
        lateinit var bitmap : Bitmap
    }
    init {
        do {
            dx = Random.nextInt(2 * speed + 1) - speed
            dy = Random.nextInt(2 * speed + 1) - speed
        } while (dx == 0 && dy == 0)
        ballCounter++
        bitmap = BitmapFactory.decodeResource(context.resources, R.drawable.pokeball)
    }
    fun update(blocks : MutableList<Block>) {
        if (blocks.any { collide(it)}) {
            dx = -dx
            dy = -dy
        } else {
            if (x > width - size) dx = -dx
            else if (x < 0) dx = -dx
            else if (y > height - size) dy = -dy
            else if (y < 0) dy = -dy
        }
        x += dx
        y += dy
    }
    // prienik dvoch oblznikov
    fun collide(block : Block) : Boolean =
//        block.isIn(x, y) || block.isIn(x, y+size) || block.isIn(x+size, y) || block.isIn(x+size, y+size)
          x < block.x + block.size &&
          x + size > block.x &&
          y < block.y + block.size &&
          y + size > block.y


    fun isIn(eventx : Int, eventy : Int) : Boolean = // toto je stvorec, asi by to chcelo rovnicu kruznice
        x <= eventx && eventx <= x+size
                &&
        y <= eventy && eventy <= y+size

   fun draw(canvas: Canvas) {
       val mPaint = Paint()
       mPaint.color = Color.parseColor("#906090")
       //canvas.drawCircle((x+size/2).toFloat(), (y+size/2).toFloat(), (size/2).toFloat(), mPaint)
       canvas.drawBitmap(bitmap, null, Rect(x,y,x+size, y+size), mPaint)
   }
}