package com.example.cvicenie5

import android.media.AudioManager
import android.media.MediaPlayer
import android.media.SoundPool
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    var paused = false
    lateinit var mp : MediaPlayer
    lateinit var soundPool : SoundPool
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        mp = MediaPlayer()
        soundPool = SoundPool(10, AudioManager.STREAM_MUSIC, 0)
        val shootID = soundPool.load(assets.openFd("shoot.ogg"),0)

        object : CountDownTimer(100000, 20) { // 50 Hz
            override fun onFinish() {
                mp = MediaPlayer.create(this@MainActivity, R.raw.tada)
                mp.start()
                Toast.makeText(this@MainActivity, "Game over", Toast.LENGTH_LONG).show()
                finish()
            }
            override fun onTick(p0: Long) {
                if (!paused) {
                    runOnUiThread {
                        val playground = findViewById<Playground>(R.id.playground)
                        playground.update()
                        playground.invalidate()
                    }
                }
            }
        }.start()
        val timer = object : CountDownTimer(100000, 1000) { // 1 Hz
            override fun onFinish() {
                Toast.makeText(this@MainActivity, "Game over", Toast.LENGTH_LONG).show()
                finish()
            }
            override fun onTick(p0: Long) {
                    runOnUiThread {
                        val playground = findViewById<Playground>(R.id.playground)
                        //try {
                            playground.addBall()
                            playground.addBlock()
                            soundPool.play(shootID, 1f, 1f, 1, 0, 1f)
                        //} catch (e : Exception) {      }
                        val scoreTV = findViewById<TextView>(R.id.scoretv)
                        scoreTV.setText("${Playground.score}")
                        playground.invalidate()
                    }
            }
        }.start()
    }

    override fun onPause() {
        super.onPause()
        //mp.release()
        soundPool.release()
    }
}