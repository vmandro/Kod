package com.example.gobblet2

data class Playground(
    val left : Array<Cell>,
    val board : Array<Array<Cell>>,
    val right : Array<Cell>)