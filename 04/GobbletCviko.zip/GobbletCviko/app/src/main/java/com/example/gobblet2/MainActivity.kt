package com.example.gobblet2

import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.gobblet2.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    val pg = Playground(
        arrayOf(Cell(mutableListOf(4,3,2,1)), Cell(mutableListOf(4,3,2,1)), Cell(mutableListOf(4,3,2,1))),
        Array(4){ Array(4) { Cell(mutableListOf()) } },
        arrayOf(Cell(mutableListOf(-4,-3,-2,-1)), Cell(mutableListOf(-4,-3,-2,-1)), Cell(mutableListOf(-4,-3,-2,-1)))
    )
    lateinit var whites : List<Button>
    lateinit var blacks : List<Button>
    lateinit var blackIcons : List<Drawable>
    lateinit var whiteIcons : List<Drawable>
    lateinit var emptyIcon : Drawable
    var player = false // black
    var click = 0
    var moveFrom = 0
    var moveTo = 0

    private lateinit var board : Array<Array<Button>>
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        //setContentView(R.layout.activity_main)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.apply {
            board = arrayOf(
                arrayOf(button0, button1, button2, button3),
                arrayOf(button4, button5, button6, button7),
                arrayOf(button8, button9, button10, button11),
                arrayOf(button12, button13, button14, button15)
            )
            whites = listOf(buttonL1, buttonL2, buttonL3)
            blacks = listOf(buttonR1, buttonR2, buttonR3)

        }
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        emptyIcon = ContextCompat.getDrawable(this,R.drawable.empty)!!
        blackIcons = listOf(
            ContextCompat.getDrawable(applicationContext, R.drawable.b1,  )!!,
            ContextCompat.getDrawable(applicationContext, R.drawable.b2,  ),
            ContextCompat.getDrawable(applicationContext, R.drawable.b3,  ),
            ContextCompat.getDrawable(applicationContext, R.drawable.b4,  )
        )
        whiteIcons = listOf(
            ContextCompat.getDrawable(applicationContext, R.drawable.w1,  )!!,
            ContextCompat.getDrawable(applicationContext, R.drawable.w2,  ),
            ContextCompat.getDrawable(applicationContext, R.drawable.w3,  ),
            ContextCompat.getDrawable(applicationContext, R.drawable.w4,  ),
        )

        display()
    }
    fun display() {
        Log.d("Gobblet", pg.toString())

        binding.screen.setBackgroundColor(Color.GRAY)
        if (player)
            binding.grid.setBackgroundColor(Color.BLACK)
        else
            binding.grid.setBackgroundColor(Color.WHITE)
        for (i in 0..2) {
            whites[i].foreground = getIcon(pg.left[i].gobblets[0])
        }
        for (i in 0..2)
            blacks[i].foreground = getIcon(pg.right[i].gobblets[0])
        for (i in 0..3)
            for (j in 0..3)
                board[i][j].foreground =
                    if (pg.board[i][j].gobblets.size == 0) emptyIcon else
                        getIcon(pg.board[i][j].gobblets[0])
    }
    fun onClick(v : View) {
        // todo
    }
    fun getIcon(n : Int) : Drawable?=
         if (n > 0) whiteIcons[n - 1]
                else if (n < 0) blackIcons[-n - 1]
                else emptyIcon

}