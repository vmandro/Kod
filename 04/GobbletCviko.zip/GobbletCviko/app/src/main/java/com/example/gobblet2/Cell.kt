package com.example.gobblet2


data class Cell(val gobblets : MutableList<Int>)
