package com.example.gobbletcviko


data class Cell(val gobblets : MutableList<Int>)
