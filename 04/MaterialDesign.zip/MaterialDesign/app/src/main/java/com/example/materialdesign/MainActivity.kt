package com.example.materialdesign

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ArrayAdapter

import android.widget.CheckedTextView
import com.example.materialdesign.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar
import java.text.SimpleDateFormat
import java.util.Date

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    var listItems = ArrayList<String>()
    lateinit var adapter : ArrayAdapter<String>
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.apply {
            setSupportActionBar(toolbar)

            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_list_item_checked,
                listItems
            )
            contentMain.listView.adapter = adapter
            contentMain.listView.setOnItemClickListener { adapterView, view, index, l ->
                val hodnota = adapterView.getItemAtPosition(index)
                (view as CheckedTextView).toggle()
            }
            fab.setOnClickListener {
                val format: SimpleDateFormat = SimpleDateFormat("HH:mm:ss MM/dd/yyyy")
                var itemText = ""
                try {
                    itemText =
                        resources.getStringArray(R.array.potraviny)[listItems.size] + "\t\t\t(${
                            format.format(
                                Date()
                            )
                        })"
                } catch (e: Exception) {
                    itemText = "no more items"
                }
                listItems.add(itemText)
                adapter.notifyDataSetChanged()
                Snackbar.make(it, "Add to list $itemText", Snackbar.LENGTH_LONG)
                    .setAction("Undo",
                        {
                            if (listItems.size > 0) {
                                listItems.removeAt((listItems.size - 1))
                            }
                            adapter.notifyDataSetChanged()
                            Snackbar.make(it, "last removed", Snackbar.LENGTH_SHORT)
                                .setAction("Action", null).show()
                        }
                    ).show()
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }
}
