package com.example.recycleviewexample

data class ItemsViewModel2(val firstName: String, val lastName : String) {
}