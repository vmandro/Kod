package com.example.recycleviewexample

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.recycleviewexample.ItemsViewModel
import com.example.recycleviewexample.R

class CustomAdapter(private val mList: List<ItemsViewModel>) : RecyclerView.Adapter<CustomAdapter.ViewHolder>() {

    // vytvorí view zodpovedajúce jednému riadku zoznamu, bez hodnôt, template riadku
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.row, parent, false)
        return ViewHolder(view)
    }

    // previaže prázdny holder s dátami adaptéra, pomocou vstupu mList
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.textView.text = mList[position].text
    }

    // počet riadkov zobrazených v zozname
    override fun getItemCount(): Int {
        return mList.size
    }

    // jeden riadok zoznamu
    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textView = itemView.findViewById<TextView>(R.id.textView)
        init {
            itemView.setOnClickListener {
                Log.i("TAG", "item selected ${textView.text}")
                Toast.makeText(itemView.context, "item selected ${textView.text}", Toast.LENGTH_SHORT).show()
            }
        }
    }
}