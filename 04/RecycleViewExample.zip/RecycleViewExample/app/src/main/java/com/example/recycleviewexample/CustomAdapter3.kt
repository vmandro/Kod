package com.example.recycleviewexample

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.recycleviewexample.R

class CustomAdapter3(private val mList: List<ItemsViewModel3>) : RecyclerView.Adapter<CustomAdapter3.ViewHolder>() {
    //private lateinit var binding: Row3Binding
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.row3, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.prenom.text = mList[position].krstne
        holder.nomDeFamille.text = mList[position].priezvisko
        holder.icone.setImageResource(mList[position].obrazok)
    }

    override fun getItemCount(): Int {
        return mList.size
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
//        val prenom = itemView.firstName
//        val nomDeFamille = itemView.lastName
//        val icone = itemView.imageView
        val prenom = itemView.findViewById<TextView>(R.id.firstName)
        val nomDeFamille = itemView.findViewById<TextView>(R.id.lastName)
        val icone = itemView.findViewById<ImageView>(R.id.imageView)
        init {
            itemView.setOnClickListener {
                Log.d("TAG", "item selected ${prenom.text} ${nomDeFamille.text}")
            }
        }
    }
}