package com.example.recycleviewexample

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.recycleviewexample.R

class CustomAdapter2(private val mList: List<ItemsViewModel2>) : RecyclerView.Adapter<CustomAdapter2.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.row2, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
//        holder.firstView.setOnClickListener {
//            Log.d("TAG","item selected ${mList[position]} ${mList[position].lastName}")
//        }
        holder.firstView.text = mList[position].firstName
        holder.lastView.text = mList[position].lastName
    }

    override fun getItemCount(): Int {
        return mList.size
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val firstView = itemView.findViewById<TextView>(R.id.firstName)
        val lastView = itemView.findViewById<TextView>(R.id.lastName)
        init {
            itemView.setOnClickListener {
                Log.d("TAG", "item selected ${firstView.text} ${lastView.text}")
            }
        }
    }
}