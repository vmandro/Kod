package com.example.recycleviewexample

data class ItemsViewModel(val text: String) { }