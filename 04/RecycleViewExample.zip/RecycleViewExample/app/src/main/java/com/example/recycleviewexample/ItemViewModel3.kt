package com.example.recycleviewexample

data class ItemsViewModel3(val krstne: String, val priezvisko : String, val obrazok : Int) {}