package com.example.recycleviewexample

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView


class CustomAdapter1(private val data: List<ItemsViewModel1>) : RecyclerView.Adapter<CustomAdapter1.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.row1, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.prenon.text = data[position].krstne
        holder.nomDeFamille.text = data[position].priezvisko
        holder.icone.setImageResource(data[position].obrazok)
    }

    override fun getItemCount(): Int {
        return data.size
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val prenon = itemView.findViewById<TextView>(R.id.firstName1)
        val nomDeFamille = itemView.findViewById<TextView>(R.id.lastName1)
        val icone = itemView.findViewById<ImageView>(R.id.imageView2)
        init {
            itemView.setOnClickListener {
                Log.i("TAG", "item selected ${prenon.text} ${nomDeFamille.text}")
            }
        }
    }
}