package com.example.recycleviewexample

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.recycleviewexample.R
import com.example.recycleviewexample.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // jednoduchy priklad item obsahuje jediny String
        binding.rv.layoutManager = LinearLayoutManager(this)
        binding.rv.adapter = CustomAdapter(
            listOf(
            ItemsViewModel("peter"),
            ItemsViewModel("pavel"),
            ItemsViewModel("anna")
        ))

//----------------------------------------------------
// v row1 chyba CardView, v koreni je ConstraintLayout
//        binding.rv.layoutManager = LinearLayoutManager(this)
//        binding.rv.adapter = CustomAdapter1(
//            listOf(
//                ItemsViewModel1("John","Lennon", R.drawable.lennon),
//                ItemsViewModel1("Ringo","Star", R.drawable.star),
//                ItemsViewModel1("Paul","McCartney", R.drawable.cartney),
//                ItemsViewModel1("George","Harrison", R.drawable.harrison)
//            )
//        )


//----------------------------------------------------
        binding.rv1.layoutManager =
            //LinearLayoutManager(this)
            GridLayoutManager(this,2)
        binding.rv1.adapter = CustomAdapter2(
            listOf(
                ItemsViewModel2("John","Lennon"),
                ItemsViewModel2("Ringo","Star"),
                ItemsViewModel2("Paul","McCartney"),
                ItemsViewModel2("George","Harrison")
            ))

//----------------------------------------------------
        binding.rv2.layoutManager = LinearLayoutManager(this)
        binding.rv2.adapter = CustomAdapter3(
            listOf(
                ItemsViewModel3("John","Lennon", R.drawable.lennon),
                ItemsViewModel3("Ringo","Star", R.drawable.star),
                ItemsViewModel3("Paul","McCartney", R.drawable.cartney),
                ItemsViewModel3("George","Harrison", R.drawable.harrison)
            ))

    }
}
