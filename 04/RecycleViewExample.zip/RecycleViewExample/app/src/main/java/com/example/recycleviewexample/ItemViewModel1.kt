package com.example.recycleviewexample

data class ItemsViewModel1(val krstne : String, val priezvisko : String, val obrazok : Int) { }