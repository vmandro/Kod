package com.example.recycleviewexample

data class ItemsViewModel1(val krstne : String, val priezviske : String, val obrazok : Int) { }