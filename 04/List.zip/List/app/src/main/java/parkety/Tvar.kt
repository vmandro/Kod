package com.example.parkety
import android.view.MotionEvent

class Tvar(private val stvorceky: List<Stvorcek>) {
    fun onDraw() {
        for (stvorcek in stvorceky)
            stvorcek.onDraw()
    }
    fun onTouched(motionEvent: MotionEvent): Boolean {
        if (isIn(motionEvent)) {
            var reDraw = false
            for (stvorcek in stvorceky)
                reDraw = reDraw or stvorcek.onTouched(motionEvent)
            return reDraw
        } else
            return false
    }
    private fun isIn(motionEvent: MotionEvent) =
        stvorceky.any { it.isIn(motionEvent)}
//        var isIn = false
//        for (stvorcek in stvorceky)
//            isIn = isIn or stvorcek.isIn(motionEvent)
//        return isIn
//    }
}
