package com.example.parkety

import android.graphics.Paint
import android.graphics.Rect
import android.util.Log
import android.view.MotionEvent

class Stvorcek(x: Int, y: Int, sizex: Int, sizey: Int, private val c: Int) {
    private var x: Float = 0F
    private var y: Float = 0F
    private val sizeX: Float
    private val sizeY: Float
    private var dragged = false    // ci sa draguje
    private var dragx: Float = 0F
    private var dragy: Float = 0F  // bod, kam som pichol prstom na zaciatku dragovania
    private var dragStartX: Float = 0F
    private var gragStartY: Float = 0F  // pociatocna poloha stvorceka x, y pri dragovani
    private var lastX: Float = 0F
    private var lastY: Float = 0F

    private val w: Int = 0
    private val h: Int = 0
    private val w10: Int = 0
    private val h10: Int = 0
    private val TAG = "Parkety"
    init {
        this.x = CanvasView.toPixelX(x)
        this.y = CanvasView.toPixelY(y)
        this.sizeX = CanvasView.toPixelX(sizex)
        this.sizeY = CanvasView.toPixelY(sizey)
    }

    fun onDraw() {
        val r = Rect(x.toInt() + 1, y.toInt() + 1, (x + sizeX - 1).toInt(), (y + sizeY - 1).toInt())
        val p = Paint()
        p.color = c
        CanvasView.c!!.drawRect(r, p)
    }

    // vrati true, ak je dovod prekreslit
    fun onTouched(event: MotionEvent): Boolean {
        val action = event.action
        val newX = event.x
        val newY = event.y
        val dx = Math.abs(newX - lastX)
        val dy = Math.abs(newY - lastY)
        lastX = newX
        lastY = newY
        Log.d(TAG, "action:" + action)
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
            if (!dragged) {
                Log.d(TAG, "DOWN $x,$y")
                dragged = true
                dragStartX = x
                gragStartY = y
                dragx = newX
                dragy = newY
                return false
            }
        } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP
                || action == MotionEvent.ACTION_CANCEL) { // toto nefunguje dobre
            Log.d(TAG, "UP")
            if (dragged) {
                Log.d(TAG, "is dragged $x,$y")
                x = dragStartX + (newX - dragx)     // posun
                y = gragStartY + (newY - dragy)
                x = CanvasView.toPixelX(CanvasView.toLogicX(x))  // zaokruhli na mrezovy bod
                y = CanvasView.toPixelY(CanvasView.toLogicY(y))
                dragged = false
                return true
            }
        } else if (action == MotionEvent.ACTION_MOVE) {
            if (dx >= TOLERANCE || dy >= TOLERANCE) {
                Log.d(TAG, "MOVE $x,$y")
                x = dragStartX + (newX - dragx)     // posun
                y = gragStartY + (newY - dragy)
            }
            return true
        }
        return false

    }

    fun isIn(event: MotionEvent): Boolean {
        return (x <= event.x && event.x <= x + sizeX
                &&
                y <= event.y && event.y <= y + sizeY)
    }

    companion object {
        private val TOLERANCE = 5f
    }
}
