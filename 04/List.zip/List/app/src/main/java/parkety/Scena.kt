package com.example.parkety

import android.view.MotionEvent

class Scena(private val list: List<Tvar>) {
    fun onTouched(motionEvent: MotionEvent): Boolean {
        var reDraw = false
        for (t in list) {
            reDraw = reDraw or t.onTouched(motionEvent)
        }
        return reDraw
    }

    fun onDraw() {
        for (t in list)
            t.onDraw()
    }
}
