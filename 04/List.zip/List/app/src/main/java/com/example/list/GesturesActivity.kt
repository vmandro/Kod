package com.example.list


import android.gesture.*
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GestureDetectorCompat
import com.example.list.databinding.ActivityGesturesBinding

class GesturesActivity : AppCompatActivity(),
    GestureDetector.OnGestureListener,
    GestureDetector.OnDoubleTapListener
    //, GestureOverlayView.OnGesturePerformedListener
    {
    lateinit var gDetector: GestureDetectorCompat
    lateinit var gLibrary: GestureLibrary
    private lateinit var binding : ActivityGesturesBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGesturesBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //setContentView(R.layout.activity_gestures)

        gDetector = GestureDetectorCompat(this, this)
        gDetector.setOnDoubleTapListener(this)
        gLibrary = GestureLibraries.fromRawResource(
            this,
            //R.raw.gestures
            //R.raw.gestures1
            R.raw.gestures2
        )
        if (gLibrary.load() == false) {
            finish()
        }
        binding.gOverlay.addOnGesturePerformedListener {
        overlay: GestureOverlayView, gesture: Gesture ->
            val predictions: ArrayList<Prediction> = gLibrary.recognize(gesture)
            predictions.let {
                if (it.size > 0 && it[0].score > 1.0) {
                    val action = it[0].name
                    Toast.makeText(this, action, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onDown(event: MotionEvent): Boolean {
        binding.gestureStatusText.text = "onDown"
        return true
    }

    override fun onFling(event1: MotionEvent, event2: MotionEvent,
                         velocityX: Float, velocityY: Float): Boolean {
        binding.gestureStatusText.text = "onFling, vx:$velocityX, vy:$velocityY"
        return true
    }

    override fun onLongPress(event: MotionEvent) {
        binding.gestureStatusText.text = "onLongPress"
    }

    override fun onScroll(e1: MotionEvent, e2: MotionEvent,
                          distanceX: Float, distanceY: Float): Boolean {
        binding.gestureStatusText.text = "onScroll, dx: $distanceX, dy: $distanceY"
        return true
    }

    override fun onShowPress(event: MotionEvent) {
        binding.gestureStatusText.text = "onShowPress"
    }

    override fun onSingleTapUp(event: MotionEvent): Boolean {
        binding.gestureStatusText.text = "onSingleTapUp"
        return true
    }

    override fun onDoubleTap(event: MotionEvent): Boolean {
        binding.gestureStatusText.text = "onDoubleTap"
        return true
    }

    override fun onDoubleTapEvent(event: MotionEvent): Boolean {
        binding.gestureStatusText.text = "onDoubleTapEvent"
        return true
    }

    override fun onSingleTapConfirmed(event: MotionEvent): Boolean {
        binding.gestureStatusText.text = "onSingleTapConfirmed"
        return true
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        gDetector.onTouchEvent(event)
        return super.onTouchEvent(event)
    }
}