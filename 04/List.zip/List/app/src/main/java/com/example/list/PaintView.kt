package com.example.list

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.widget.Button


class PaintView(internal var context: Context, attrs: AttributeSet) :
    View(context, attrs) {

    private val mPaint: Paint
    private var lastX: Float = 0.toFloat()
    private var lastY: Float = 0.toFloat()
    private val mPath: Path
    private var useBezier: Boolean = false
    init {
        mPath = Path()
        mPaint = Paint()
        mPaint.setAntiAlias(true)
        mPaint.setColor(Color.BLACK)
        mPaint.setStyle(Paint.Style.STROKE)
        mPaint.setStrokeJoin(Paint.Join.ROUND)
        mPaint.setStrokeWidth(4f)
    }

    override protected fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        var mCanvas = Canvas(Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888))
    }

    override protected fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawPath(mPath, mPaint)
    }

    private fun startTouch(x: Float, y: Float) {
        mPath.moveTo(x, y)
        lastX = x
        lastY = y
    }
    private val TOLERANCE = 5f
    private fun moveTouch(x: Float, y: Float) {
        val dx = Math.abs(x - lastX)
        val dy = Math.abs(y - lastY)
        if (dx >= TOLERANCE || dy >= TOLERANCE) {
            if (useBezier)
                mPath.quadTo(lastX, lastY, (x + lastX) / 2, (y + lastY) / 2)
            else
                mPath.lineTo(x, y);
            lastX = x
            lastY = y
        }
    }
    private fun upTouch() {
            mPath.lineTo(lastX, lastY)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                startTouch(x, y)
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                moveTouch(x, y)
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                upTouch()
                invalidate()
            }
        }
        return true
    }

    fun clearCanvas(b : Button) {
        mPath.reset()
        invalidate()
        useBezier = !useBezier
        if (!useBezier) {
            b.text = "clear (use bezier)"
        } else {
            b.text = "clear (use lines)"
        }
    }
}