package com.example.list

import android.app.Activity
import android.os.Bundle
import android.util.Log
import android.view.*
import android.widget.ImageView
import android.app.Fragment
import com.example.list.databinding.FragmentImageBinding

class FragmentImage : Fragment() {
    private var controller: FragmentActivity? = null
    internal var container: ViewGroup? = null
    //lateinit var iv: ImageView
    private lateinit var binding : FragmentImageBinding
    private var i = 0
    val TAG = "Fragment"

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        Log.d(TAG, "onCreated FragmentImage")
        this.container = container
        //binding = FragmentImageBinding.inflate(layoutInflater)
        //binding = FragmentImageBinding.inflate(inflater, container, false)
        //binding = FragmentImageBinding.inflate(inflater)
        setHasOptionsMenu(true)
        return inflater.inflate(R.layout.fragment_image, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        Log.d(TAG, "onActivityCreated FragmentImage")
    }

    init {
        Log.d(TAG, "new FragmentImage")
        i = 0
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        Log.d("Canvas", "createOptionMenu")
        inflater.inflate(R.menu.activity_fragmentimage, menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.prev) {
            prevPicture()
            return true
        } else if (item.itemId == R.id.next) {
            nextPicture()
            return true
        } else
            return super.onOptionsItemSelected(item)
    }

    override fun onStart() {
        super.onStart()
        Log.d(TAG, "onStart FragmentImage")
        updatePicture()
    }

    fun updatePicture() {
        Log.d(TAG, "update FragmentImage $i")
        if (controller != null) {
            i = i % controller!!.pikas.size
//            var imageView = container!!.findViewById(R.id.imageView) as ImageView
//            imageView.setImageDrawable(controller!!.pikas[i])
            binding.imageView.setImageDrawable(controller!!.pikas[i])
        }
    }

    fun nextPicture() {
        Log.d(TAG, "next FragmentImage")
        if (controller != null)
            i = (i + 1) % controller!!.pikas.size
        updatePicture()
    }

    fun prevPicture() {
        Log.d(TAG, "prev FragmentImage")
        if (controller != null) {
            i--
            if (i < 0)
                i = controller!!.pikas.size - 1
        }
        updatePicture()
    }

    override fun onAttach(activity: Activity) {
        super.onAttach(activity)
        Log.d(TAG, "onAttach FragmentImage")
        controller = activity as FragmentActivity
    }

    override fun onResume() {
        super.onResume()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        Log.d(TAG, "onSaveInstance FragmentImage")
    }

    override fun onDetach() {
        super.onDetach()
        Log.d(TAG, "onDetach FragmentImage")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "onDestroy FragmentImage")
    }

    override fun onPause() {
        Log.d(TAG, "onPause FragmentImage")
        super.onPause()
    }

}
