package com.example.list

import android.content.Context
import android.view.SurfaceHolder
import android.view.SurfaceView

class SurfaceEmptyExample(context: Context) : SurfaceView(context) , SurfaceHolder.Callback  {
    init {
        holder.addCallback(this)
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        TODO("Not yet implemented")
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        TODO("Not yet implemented")
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        TODO("Not yet implemented")
    }


}