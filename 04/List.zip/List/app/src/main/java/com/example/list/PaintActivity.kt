package com.example.list

import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.list.databinding.ActivityPaintBinding

class PaintActivity : AppCompatActivity() {
    private lateinit var binding : ActivityPaintBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPaintBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //setContentView(R.layout.activity_paint)
    }
    fun onClickClearButton(v : View) {
        binding.signatureCanvas.clearCanvas(v as Button)
    }
}
