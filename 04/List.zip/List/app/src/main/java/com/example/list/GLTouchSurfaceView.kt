package com.example.list

import android.content.Context
import android.graphics.PixelFormat
import android.opengl.GLSurfaceView
import android.view.MotionEvent

internal class GLTouchSurfaceView(context: Context) : GLSurfaceView(context) {
    private val TOUCH_SCALE_FACTOR = 180.0f / 320
    private val TRACKBALL_SCALE_FACTOR = 36.0f
    var cr: GLCubeRenderer
    private var mPreviousX: Float = 0F
    private var mPreviousY: Float = 0F

    init {
        cr = GLCubeRenderer(true)
        this.setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        this.setRenderer(cr)
        this.renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY
        this.holder.setFormat(PixelFormat.TRANSPARENT)

    }

    override fun onTrackballEvent(e: MotionEvent): Boolean {
        cr.mAngleX += e.x * TRACKBALL_SCALE_FACTOR
        cr.mAngleY += e.y * TRACKBALL_SCALE_FACTOR
        requestRender()
        return true
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x
        val y = e.y
        when (e.action) {
            MotionEvent.ACTION_MOVE -> {
                val dx = x - mPreviousX
                val dy = y - mPreviousY
                cr.mAngleX += dx * TOUCH_SCALE_FACTOR
                cr.mAngleY += dy * TOUCH_SCALE_FACTOR
                requestRender()
            }
        }
        mPreviousX = x
        mPreviousY = y
        return true
    }
}