package com.example.list

import android.R
import android.os.Bundle
import android.view.View
import android.widget.Toolbar
import androidx.appcompat.app.AppCompatActivity


class GameActivity : AppCompatActivity() {
    lateinit var cv: CanvasView
    private val TAG = "CanvasActivity"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(GamePanel(this))
    }
}