package com.example.list

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.view.menu.MenuBuilder
import com.example.list.databinding.ActivityCanvasBinding

class CanvasActivity : AppCompatActivity() {
    val TAG = "CanAct"
    private lateinit var binding: ActivityCanvasBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCanvasBinding.inflate(layoutInflater)
        Log.i(TAG, "create")
        //setContentView(R.layout.activity_canvas)
        setContentView(binding.root)
        binding.canvasView1.ac = this
    }

    @SuppressLint("RestrictedApi")
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.activity_canvas, menu)
        (menu as? MenuBuilder)?.setOptionalIconsVisible(true)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        binding.apply {
            when (item.getItemId()) {
                R.id.pause -> {
                    Log.i(TAG, "pause")
                    canvasView1.paused = true
                    return true
                }

                R.id.play -> {
                    Log.i(TAG, "play")
                    canvasView1.paused = false
                    return true
                }

                R.id.stop -> {
                    Log.i(TAG, "stop")
                    canvasView1.stopped = true
                    return true
                }

                else -> return super.onOptionsItemSelected(item)
            }
        }
    }
}