package com.example.list

import android.opengl.GLSurfaceView
import javax.microedition.khronos.opengles.GL10

internal class GLCubeRenderer(private val mTranslucentBackground: Boolean) :
    GLSurfaceView.Renderer {
    private val mCube: GLCube
    var mAngleX: Float = 0F
    var mAngleY: Float = 0F

    init {
        mCube = GLCube()
    }

    override fun onSurfaceCreated(gl: GL10, eglConfig: javax.microedition.khronos.egl.EGLConfig) {
        gl.glDisable(GL10.GL_DITHER)
        gl.glHint(GL10.GL_PERSPECTIVE_CORRECTION_HINT, GL10.GL_FASTEST)
        if (mTranslucentBackground) {
            gl.glClearColor(0f, 0f, 0f, 0f)
        } else {
            gl.glClearColor(1f, 1f, 1f, 1f)
        }
        gl.glEnable(GL10.GL_CULL_FACE)
        gl.glShadeModel(GL10.GL_SMOOTH)
        gl.glEnable(GL10.GL_DEPTH_TEST)
    }

    override fun onDrawFrame(gl: GL10) {
        gl.glClear(GL10.GL_COLOR_BUFFER_BIT or GL10.GL_DEPTH_BUFFER_BIT)
        gl.glMatrixMode(GL10.GL_MODELVIEW)
        gl.glLoadIdentity()
        gl.glTranslatef(0f, 0f, -5.0f)
        gl.glRotatef(mAngleX, 0f, 1f, 0f)
        gl.glRotatef(-mAngleY, 1f, 0f, 0f)
        gl.glEnableClientState(GL10.GL_VERTEX_ARRAY)
        gl.glEnableClientState(GL10.GL_COLOR_ARRAY)
        mCube.draw(gl)
    }

    override fun onSurfaceChanged(gl: GL10, width: Int, height: Int) {
        gl.glViewport(0, 0, width, height)
        val ratio = width.toFloat() / height
        gl.glMatrixMode(GL10.GL_PROJECTION)
        gl.glLoadIdentity()
        gl.glFrustumf(-ratio, ratio, -1f, 1f, 1f, 10f)
    }
}
