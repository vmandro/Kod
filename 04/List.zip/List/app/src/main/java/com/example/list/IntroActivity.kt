package com.example.list

import android.content.Intent
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Environment
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.IOException


class IntroActivity : AppCompatActivity() {

    val TAG = "IntroActivity"
    lateinit var mp : MediaPlayer  // globalna premenna inicializovana neskor
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_intro)
        object: CountDownTimer(4000,1000) {
          override fun onTick(millisUntilFinished: Long) {}
          override fun onFinish() {
             startActivity(Intent(this@IntroActivity, MainActivity::class.java))
          }
        }.start()
        try {
            // ak je muzicka lokalna, v res/raw/tada.wav
//            mp = MediaPlayer.create(this, R.raw.tada)
//            mp.isLooping = true
//            mp.start()

                // ak je muzička na webe, jej dotiahnutie može niečo trvať, potom cez Uri
            mp = MediaPlayer()
            val uri = Uri.parse("https://dai.fmph.uniba.sk/courses/VMA/wave.mp3")
            mp.setAudioStreamType(AudioManager.STREAM_MUSIC)
            mp.setOnPreparedListener { mp.start()}
            mp.setDataSource(getApplicationContext(), uri)
            mp.prepare()	 // tu sa spustí doťahovanie súboru
    //---------------------------------------
    //        mp.setDataSource("/mnt/sdcard/Music/tada.wav")
    //        mp.setDataSource("/mnt/sdcard/Music/wave.mp3")
    //        mp.setDataSource("/storage/sdcard0/Music/wave.mp3")
    //        mp.setDataSource("/Removable/SD/Music/wave.mp3")

                // ak je súbor na danom zariadeni
//            val filePath = Environment.getExternalStorageDirectory().toString() + "/Music/tada.wav"
//            Log.i(TAG, filePath) // vždy si zalogujte cestu,
//            // aby ste vedeli, kde súbor hľadá
//            mp = MediaPlayer()
//            mp.setDataSource(filePath) // hneď viete, prečo to nehrá...
//            //mp.setDataSource("/storage/emulated/0/Music/tada.wav") // lepsie ako toto
////                        // device dependent riesenie
//            mp.setOnPreparedListener { mp.start() }
//            mp.prepare()

            // sound player
            val sp = SoundPlayer(this)
        } catch (e :IOException) {
            e.printStackTrace()
            Toast.makeText(this, "file open error, ${e.message}", Toast.LENGTH_SHORT).show()
        }


    }
    override fun onPause() {
        super.onPause()
        mp.release()
        finish()
    }
}