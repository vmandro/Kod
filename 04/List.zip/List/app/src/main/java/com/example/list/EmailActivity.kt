package com.example.list

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.list.databinding.ActivityEmailBinding


class EmailActivity : AppCompatActivity() {

    private val TAG = "EmailActivity"
    private lateinit var binding: ActivityEmailBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEmailBinding.inflate(layoutInflater)
        //setContentView(R.layout.activity_email)
        setContentView(binding.root)
        binding.btnSend.setOnClickListener {
            val emailString = binding.edtEmail.text.toString()
            val subjectString = binding.edtSubject.text.toString()
            val bodyString = binding.edtBody.text.toString()
            Toast.makeText(
                this@EmailActivity, "posielam mail cez mail-klienta",
                Toast.LENGTH_LONG
            ).show()

            val intent = Intent(android.content.Intent.ACTION_SEND)
            intent.type = "text/plain"
            //intent.extras?.putString(android.content.Intent.EXTRA_SUBJECT, subjectString)
            intent.putExtra(android.content.Intent.EXTRA_SUBJECT, subjectString)
            intent.putExtra(android.content.Intent.EXTRA_EMAIL,
                arrayOf(emailString) // pole adresatov
            )
            intent.putExtra(android.content.Intent.EXTRA_TEXT, bodyString)
            // startActivity(intent);
            startActivityForResult(intent, REQUEST_SEND_EMAIL)
        }
    }
    private val REQUEST_SEND_EMAIL = 777

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        // Check which request we're responding to
        if (requestCode == REQUEST_SEND_EMAIL) {
            Toast.makeText(
                this@EmailActivity, "email poslany, alebo aj nie",
                Toast.LENGTH_SHORT
            ).show();
        }
    }
}