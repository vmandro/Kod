package com.example.list

class SurfaceEmptyThread(val surfaceEmptyExample: SurfaceEmptyExample) : Thread() {
    private var running = false
    private var paused = false
    private var stopped = false
    private val TAG = "SurfaceEmptyThread"

    override fun run() {
        val surfaceHolder = surfaceEmptyExample.holder
        while (running) {
            if (!paused) {
                if (!surfaceHolder.surface.isValid) {
                    continue
                }
                val canvas = surfaceHolder.lockCanvas()
                surfaceEmptyExample.draw(canvas)
                surfaceHolder.unlockCanvasAndPost(canvas)
            }
        }
    }

    fun setRunning(running: Boolean) {
        this.running = running
    }

    fun setPaused(paused: Boolean) {
        this.paused = paused
    }

    fun setStopped(stopped: Boolean) {
        this.stopped = stopped
    }
}