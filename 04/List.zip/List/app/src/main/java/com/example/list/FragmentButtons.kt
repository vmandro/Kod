package com.example.list

import android.app.Activity
import android.app.Fragment
//import androidx.fragment.app.Fragment
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button

class FragmentButtons : Fragment() {
    private var controller: FragmentActivity? = null
    private var container: ViewGroup? = null
    val TAG = "Fragment"
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        Log.d(TAG, "onCreated in FragmentButtons")
        this.container = container
        return inflater.inflate(R.layout.fragment_buttons, container, false)
    }

    override fun onAttach(activity: Activity) {
        super.onAttach(activity)
        Log.d(TAG, "onAttach in FragmentButtons")
        controller = activity as FragmentActivity
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        Log.d(TAG, "onActivityCreated in FragmentButtons")
    }

    init {
        Log.d(TAG, "new of FragmentButtons")
    }

    override fun onStart() {
        super.onStart()
        Log.d(TAG, "onStart in FragmentButtons")
        val prev = container!!.findViewById(R.id.prevBtn) as Button
        prev.setOnClickListener { controller?.prev() }
        val next = container!!.findViewById(R.id.nextBtn) as Button
        next.setOnClickListener { controller?.next() }
        val quit = container!!.findViewById(R.id.quitBtn) as Button
        quit.setOnClickListener { controller?.quit() }

    }

    override fun onResume() {

        super.onResume()
        Log.d(TAG, "onResume in FragmentButtons")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        Log.d(TAG, "onSaveInstance in FragmentButtons")
    }

    override fun onDetach() {
        super.onDetach()
        Log.d(TAG, "onDetach in FragmentButtons")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "onDestroy in FragmentButtons")
    }
}
