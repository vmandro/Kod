package com.example.list

import android.os.Bundle
import android.preference.PreferenceActivity

@Suppress("DEPRECATION")
class SettingActivity : PreferenceActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        addPreferencesFromResource(R.xml.settings)
    }
}