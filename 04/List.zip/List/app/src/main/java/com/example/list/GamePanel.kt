package com.example.list

import android.content.Context
import android.graphics.*
import android.preference.PreferenceManager
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.widget.Toast

class GamePanel(context : Context) : SurfaceView(context), SurfaceHolder.Callback {
	var count = 0
	var frames = 0
	var skipped = 0
	var killed = 0
	lateinit  var thread : GameThread

	var pikaList = mutableListOf<Pika>()

	init {
		// adding the callback (this) to the surface holder to intercept events
		holder.addCallback(this)
		//getHolder().addCallback(this)

//		holder.addCallback (object : SurfaceHolder.Callback {
//			override fun surfaceCreated(holder: SurfaceHolder) {
//				thread.start()
//			}
//			override fun surfaceChanged(
//				holder: SurfaceHolder, format: Int, width: Int, height: Int
//			) {	}
//			override fun surfaceDestroyed(holder: SurfaceHolder) {
//				var retry = true;
//				thread.running = false;
//				while (retry) {
//					try {
//						thread.join()
//						retry = false
//					} catch (e :InterruptedException) {
//					}
//				}
//			}
//		})

		var PIKATCHUS = 0
		val settings = // context.getSharedPreferences("settings", Context.MODE_PRIVATE)
			PreferenceManager.getDefaultSharedPreferences(context)

		try {
			PIKATCHUS = Integer.parseInt(settings.getString("prefCount", "5000"))
		} catch (e : Exception) {
			PIKATCHUS = 5000
		}
		val pikas = listOf<Bitmap>(
			BitmapFactory.decodeResource(resources, R.drawable.pika0),
			BitmapFactory.decodeResource(resources, R.drawable.pika1),
			BitmapFactory.decodeResource(resources, R.drawable.pika2),
			BitmapFactory.decodeResource(resources, R.drawable.pika3),
			BitmapFactory.decodeResource(resources, R.drawable.pika4),
			BitmapFactory.decodeResource(resources, R.drawable.pika5),
			BitmapFactory.decodeResource(resources, R.drawable.pika6),
			BitmapFactory.decodeResource(resources, R.drawable.pika7)
		)
		for (i in 0 until PIKATCHUS) {
			pikaList.add(Pika(pikas[i % pikas.size]))
		}
		setFocusable(true)
		thread = GameThread(this)
	}

	override fun surfaceCreated(holder: SurfaceHolder) {
		thread.start()
	}

	override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
	}

	override fun surfaceDestroyed(holder: SurfaceHolder) {
		var retry = true;
		thread.running = false;
		while (retry) {
			try {
				thread.join()
				retry = false
			} catch (e :InterruptedException) {
			}
		}
	}

	override fun onTouchEvent(event: MotionEvent?): Boolean {
		killed = 0;
		for (i in 0 until pikaList.size) {
			if (event?.getAction() == MotionEvent.ACTION_UP && pikaList[i].y < 40) {
					pikaList[i].killed = true
					killed++
					Toast.makeText(context, "!!!KILLED!!!", Toast.LENGTH_LONG).show()
			}
			if (event?.getAction() == MotionEvent.ACTION_DOWN) {
				pikaList[i].handleActionDown(event.getX().toInt(), event.getY().toInt())

			}
			if (event?.getAction() == MotionEvent.ACTION_MOVE) {
				if (pikaList[i].touched) {
					pikaList[i].x = event.getX()
					pikaList[i].y = event.getY()
				}
			}
			if (event?.getAction() == MotionEvent.ACTION_UP) {
				if (pikaList[i].touched) {
					pikaList[i].touched = false
				}
			}
		}
		return true;
	}

	fun showPika(canvas: Canvas) {
		if (canvas != null) {
			canvas.drawColor(Color.BLACK)
			for (i in 0 until pikaList.size)
				pikaList[i].draw(canvas)
			val paint = Paint()
			paint.setARGB(255, 255, 255, 255)
			paint.setColor(Color.YELLOW)
			paint.setTextSize(36F)
			canvas.drawText(
				"Time(s): $count, FPS: $frames, skipped: $skipped, total: ${pikaList.size}, killed: $killed",
				this.getWidth() / 2F - 100, 30F, paint)
		}
	}
}