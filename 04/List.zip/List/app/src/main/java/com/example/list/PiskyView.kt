package com.example.list

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap


class   PiskyView(context: Context, attrs: AttributeSet) : View(context, attrs) {

    private val SIZE = 11
    private val COUNT = 5
    private val playGround = Array(SIZE) { IntArray(SIZE) }
    private val x_img: Bitmap
    private val o_img: Bitmap
    private var onTurn = 0
    private var minSize: Float = 0F
    private var cellSize: Float = 0F

    init {
        for (x in 0 until SIZE)
            for (y in 0 until SIZE)
                playGround[y][x] = -1
        o_img = ContextCompat.getDrawable(context, R.drawable.o)!!.toBitmap()
        x_img = ContextCompat.getDrawable(context, R.drawable.x)!!.toBitmap()
        //o_img = resources.getDrawable(R.drawable.o).toBitmap()
        //x_img = resources.getDrawable(R.drawable.x).toBitmap()
    }

    private fun check(x: Int, y: Int): Int {
        val p = playGround[y][x]
        var pocet = 1
        var i = y
        while (i >= 0 && playGround[i][x] == p) {
            if (pocet >= COUNT)
                return p
            --i
            pocet++
        }
        pocet = 1
        i = y
        while (i < SIZE && playGround[i][x] == p) {
            if (pocet >= COUNT)
                return p
            ++i
            pocet++
        }
        pocet = 1
        i = x
        while (i >= 0 && playGround[y][i] == p) {
            if (pocet >= COUNT)
                return p
            --i
            pocet++
        }
        pocet = 1
        i = x
        while (i < SIZE && playGround[y][i] == p) {
            if (pocet >= COUNT)
                return p
            ++i
            pocet++
            }
        pocet = 1
        i = 0
        while (x + i >= 0 && y + i >= 0
            && playGround[y + i][x + i] == p
        ) {
            if (pocet >= COUNT)
                return p
            --i
            pocet++
        }
        pocet = 1
        i = 0
        while (x + i < SIZE && y + i < SIZE
            && playGround[y + i][x + i] == p
        ) {
            if (pocet >= COUNT)
                return p
            ++i
            pocet++
        }
        pocet = 1
        i = 0
        while (x - i >= 0 && y + i < SIZE
            && playGround[y + i][x - i] == p
        ) {
            if (pocet >= COUNT)
                return p
            ++i
            pocet++
        }
        pocet = 1
        i = 0
        while (x + i < SIZE && y - i >= 0
            && playGround[y - i][x + i] == p
        ) {
            if (pocet >= COUNT)
                return p
            ++i
            pocet++
        }
        return -1
    }

    override fun performClick(): Boolean {
        return super.performClick()
    }
    override  fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_DOWN) {
            val iX = (e.x / cellSize).toInt()
            val iY = (e.y / cellSize).toInt()
            if (iX >= SIZE || iY >= SIZE)
                return true
            if (playGround[iY][iX] == -1) {
                playGround[iY][iX] = onTurn
                onTurn = 1 - onTurn
                invalidate()
                val winner = check(iX, iY)
                if (winner != -1)
                    Toast.makeText(
                        getContext(),
                        (if (winner == 0) "o" else "x") + " vyhral",
                        Toast.LENGTH_LONG
                    ).show()
            } else
                Toast.makeText(
                    getContext(), "sem nemozes tahat",
                    Toast.LENGTH_LONG
                ).show()

        }
        return true
    }

    val paint = Paint()
    @SuppressLint("DrawAllocation")
    override  protected fun onDraw(canvas: Canvas) {
        minSize = Math.min(getWidth(), getHeight()) - 2F
        cellSize = minSize / SIZE

        canvas.drawColor(Color.WHITE)
        paint.setColor(Color.BLACK)
        paint.setStrokeWidth(1F)
        for (i in 1..SIZE) {
            canvas.drawLine(i * cellSize, 0F, i * cellSize, minSize, paint)
            canvas.drawLine(0F, i * cellSize, minSize, i * cellSize, paint)
        }
        for (y in 0 until SIZE) {
            for (x in 0 until SIZE) {
                if (playGround[y][x] != -1)
                    canvas.drawBitmap(
                        if (playGround[y][x] == 0) o_img else x_img,
                        null,
                        Rect(
                            (x * cellSize + 2).toInt(),
                            (y * cellSize + 2).toInt(),
                            ((x + 1) * cellSize - 2).toInt(),
                            ((y + 1) * cellSize - 2).toInt()
                        ),
                        paint
                    )
            }
        }
    }
}
