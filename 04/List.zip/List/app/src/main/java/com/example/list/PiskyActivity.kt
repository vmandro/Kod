package com.example.list

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity


class PiskyActivity : AppCompatActivity() {

    private val TAG = "PiskyActivity"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pisky)
    }
}