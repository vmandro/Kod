package com.example.list

import android.app.Activity
import android.app.Fragment
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.util.Log
import com.example.list.databinding.ActivityFragmentBinding
import java.util.*

class FragmentActivity : Activity() {
    private var fr1: FragmentButtons? = null
    private var fr2: FragmentImage? = null
    var pikas = ArrayList<Drawable>()
    val TAG = "Fragment"
    private lateinit var binding : ActivityFragmentBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFragmentBinding.inflate(layoutInflater)
        setContentView(binding.root)
        Log.d(TAG, "onCreate in FragmentActivity")
        //setContentView(R.layout.activity_fragment)
        pikas.add(this@FragmentActivity.resources.getDrawable(R.drawable.pika) as Drawable)
        pikas.add(this@FragmentActivity.resources.getDrawable(R.drawable.pok0) as Drawable)
        pikas.add(this@FragmentActivity.resources.getDrawable(R.drawable.pok1) as Drawable)
        pikas.add(this@FragmentActivity.resources.getDrawable(R.drawable.pok2) as Drawable)
        pikas.add(this@FragmentActivity.resources.getDrawable(R.drawable.pok3) as Drawable)
        pikas.add(this@FragmentActivity.resources.getDrawable(R.drawable.pok4) as Drawable)
        /*
        pikas.add((Drawable)FragmentActivity.this.getResources().getDrawable(R.drawable.pok5));
        pikas.add((Drawable)FragmentActivity.this.getResources().getDrawable(R.drawable.pok6));
        pikas.add((Drawable)FragmentActivity.this.getResources().getDrawable(R.drawable.pok7));
        */

        fr2 = FragmentImage()
        fr1 = FragmentButtons()
        binding.fragment1.setOnClickListener {
            Log.d(TAG, "open Fragment 1")
            val fm = fragmentManager
            val fragmentTransaction = fm.beginTransaction()
            fragmentTransaction.replace(R.id.fragment_place, fr1)
            //fragmentTransaction.add(R.id.fragment_place, fr1);
            fragmentTransaction.addToBackStack(null)
            fragmentTransaction.commit()
        }
        binding.fragment2.setOnClickListener {
            Log.d(TAG, "open Fragment 2")
            val fm = fragmentManager
            val fragmentTransaction = fm.beginTransaction()
            fragmentTransaction.replace(R.id.fragment_place, fr2)
            //fragmentTransaction.add(R.id.fragment_place, fr2);
            fragmentTransaction.addToBackStack(null)
            fragmentTransaction.commit()
        }
    }

    override fun onAttachFragment(fragment: Fragment) {
        super.onAttachFragment(fragment)
        Log.d(TAG, "onAttachFragemnt in FragmentActivity " + fragment.javaClass.name)
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "onResume in FragmentActivity")
    }

    override fun onStart() {
        super.onStart()
        Log.d(TAG, "onStart in FragmentActivity")
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
    }

    fun quit() {
        Log.d(TAG, "quit in FragmentActivity")
        finish()
    }

    fun next() {
        Log.d(TAG, "next in FragmentActivity")
        fr2!!.nextPicture()
    }

    fun prev() {
        Log.d(TAG, "prev in FragmentActivity")
        fr2!!.prevPicture()
    }

}
