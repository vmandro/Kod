package com.example.list

import android.app.Activity
import android.graphics.PixelFormat
import android.hardware.Camera.PictureCallback
import android.hardware.Camera.ShutterCallback
import android.os.Bundle
import android.util.Log
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.Window
import android.view.WindowManager

import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.io.IOException

class GLActivity : Activity(), SurfaceHolder.Callback {
    //    private Camera camera;
    private var mSurfaceView: SurfaceView? = null
    lateinit var mSurfaceHolder: SurfaceHolder
    private var mGLSurfaceView: GLTouchSurfaceView? = null
    internal var shutter: ShutterCallback = ShutterCallback {
        // No action to be perfomed on the Shutter callback.
    }
    internal var raw: PictureCallback = PictureCallback { bytes, camera ->
        // No action taken on the raw data. Only action taken on jpeg data.
    }

    internal var jpeg: PictureCallback = PictureCallback { data, camera ->
        var outStream: FileOutputStream? = null
        try {
            outStream = FileOutputStream("/sdcard/test.jpg")
            outStream.write(data)
            outStream.close()
        } catch (e: FileNotFoundException) {
            Log.d("Camera", e.message?:"")
        } catch (e: IOException) {
            Log.d("Camera", e.message?:"")
        }
    }

    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        this.requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        mGLSurfaceView = GLTouchSurfaceView(this)
        addContentView(
            mGLSurfaceView,
            WindowManager.LayoutParams(
                WindowManager.LayoutParams.FILL_PARENT,
                WindowManager.LayoutParams.FILL_PARENT
            )
        )
        mSurfaceView = SurfaceView(this)
        addContentView(
            mSurfaceView,
            WindowManager.LayoutParams(
                WindowManager.LayoutParams.FILL_PARENT,
                WindowManager.LayoutParams.FILL_PARENT
            )
        )
        mSurfaceHolder = mSurfaceView!!.holder
        mSurfaceHolder.addCallback(this)
        mSurfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS)
        mSurfaceHolder.setFormat(PixelFormat.TRANSLUCENT or WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
    }

    //    private void takePicture() {
    //        camera.takePicture(shutter, raw, jpeg);
    //    }

    override fun surfaceChanged(arg0: SurfaceHolder, arg1: Int, arg2: Int, arg3: Int) {
        //        Camera.Parameters p = camera.getParameters();
        //        p.setPreviewSize(arg2, arg3);
        //        try {
        //            camera.setPreviewDisplay(arg0);
        //        } catch (IOException e) {
        //            e.printStackTrace();
        //        }
        //        camera.startPreview();
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        //        camera = Camera.open();
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        //        camera.stopPreview();
        //        camera.release();
    }
}
