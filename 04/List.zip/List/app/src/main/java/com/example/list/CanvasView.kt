package com.example.list

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.util.Log
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import java.util.*

class CanvasView(context: Context, attrs: AttributeSet) : View(context, attrs),
      View.OnTouchListener,
      View.OnKeyListener {

    val TAG = "CanAct"
    var touches = 0
    var touchX = FloatArray(10)
    var touchY = FloatArray(10)
    var colors = intArrayOf(
        Color.RED,
        Color.BLUE,
        Color.GRAY,
        Color.GREEN,
        Color.YELLOW,
        Color.CYAN,
        Color.DKGRAY,
        Color.LTGRAY,
        Color.MAGENTA,
        Color.DKGRAY
    )
    var ballX = 200f; var ballY = 200f

    var paused: Boolean = false
    var stopped:Boolean = false
    var ac: CanvasActivity? = null
    init {
        Log.d(TAG, "CanvasView init")
        setOnTouchListener(this)
        isFocusable = true
        setOnKeyListener(this)
        val th = object : Thread() {
            override fun run() {
                while (!stopped) {
                    if (!paused) {
                        for (i in 0 until touches) {
                            ballX += (touchX[i] - ballX) / touches / 50
                            ballY += (touchY[i] - ballY) / touches / 50
                        }
                        for (i in 0 until touches) {
                            touchX[i] = (ballX + 50 * touchX[i]) / 51
                            touchY[i] = (ballY + 50 * touchY[i]) / 51
                        }
                    } else {
                        Log.d(TAG, "paused")
                    }
                    try {
                        Thread.sleep(100)
                        postInvalidate()
                    } catch (e: InterruptedException) {
                        e.printStackTrace()
                    }

                }
                Log.d(TAG, "going to finish")
                ac!!.finish()
            }
        }
        th.start()
        Log.d(TAG, "CanvasView init finished")
    }

    override protected fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)
        if (canvas != null) {
            Log.d("Canvas", "draw:$touches")
            val p = Paint()
            for (i in 0 until touches) {
                p.setColor(colors[i])
                canvas.drawCircle(touchX[i], touchY[i], 10F, p)
            }
            p.setColor(Color.BLACK)
            canvas.drawCircle(ballX, ballY, 15F, p)
        } else
            Log.d("Canvas", "null")
    }

    override fun onKey(arg0: View, arg1: Int, arg2: KeyEvent): Boolean {
        Log.d("Canvas", "onKeyDown")
        val rnd = Random()
        when (arg1) {
            KeyEvent.KEYCODE_DPAD_LEFT -> ballX -= rnd.nextInt(50)
            KeyEvent.KEYCODE_DPAD_RIGHT -> ballX += rnd.nextInt(50)
            KeyEvent.KEYCODE_DPAD_UP -> ballY -= rnd.nextInt(50)
            KeyEvent.KEYCODE_DPAD_DOWN -> ballY += rnd.nextInt(50)
            KeyEvent.KEYCODE_SPACE -> {
                ballX += rnd.nextInt(100) - 50
                ballY += rnd.nextInt(100) - 50
            }
            else -> return false
        }
        invalidate()
        return true // event handled
    }

    override fun onTouch(v: View, event: MotionEvent): Boolean {
        Log.d("Canvas", "counts:" + event.pointerCount)
        val maskedAction = event.actionMasked
        if (maskedAction == MotionEvent.ACTION_DOWN || maskedAction == MotionEvent.ACTION_POINTER_DOWN) {
            touches = event.pointerCount
            for (i in 0 until event.pointerCount) {
                Log.d("Canvas", "X:" + event.getX(i))
                Log.d("Canvas", "Y:" + event.getY(i))
                touchX[i] = event.getX(i)
                touchY[i] = event.getY(i)
            }
            return true
        } else
            return super.onTouchEvent(event)
    }
}