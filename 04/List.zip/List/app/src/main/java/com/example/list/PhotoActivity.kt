package com.example.list

import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.list.databinding.ActivityPhotoBinding

class PhotoActivity : AppCompatActivity() {
    private lateinit var binding : ActivityPhotoBinding
    private val TAG = "PhotoActivity"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPhotoBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //setContentView(R.layout.activity_photo)
        binding.takePictureBtn.setOnClickListener {
            val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (true || takePictureIntent.resolveActivity(getPackageManager()) != null) {
                Toast.makeText(this@PhotoActivity, "smile ... taking picture", Toast.LENGTH_LONG)
                    .show();
                startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
            } else {
                Toast.makeText(this@PhotoActivity, "sorry ... no picture", Toast.LENGTH_LONG)
                    .show();
            }
        }
    }
    private val REQUEST_IMAGE_CAPTURE = 690

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        // Check which request we're responding to
        if (requestCode == REQUEST_IMAGE_CAPTURE  && resultCode == RESULT_OK) {
            Toast.makeText(this@PhotoActivity, "thanks ... finito", Toast.LENGTH_LONG).show()
            val extras = data?.getExtras()
            val imageBitmap = extras?.get("data") as Bitmap
            binding.pictureImageView.setImageBitmap(imageBitmap)
        } else
            super.onActivityResult(requestCode, resultCode, data)
    }
}