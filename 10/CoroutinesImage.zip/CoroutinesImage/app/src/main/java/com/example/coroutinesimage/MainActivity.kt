package com.example.coroutinesimage

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputBinding
import android.widget.Toast
import com.example.coroutinesimage.databinding.ActivityMainBinding
import kotlinx.coroutines.*
import java.io.InputStream
import java.net.URL

class MainActivity : AppCompatActivity() {

    //private val IMAGE_URL =
    private val IMAGE_URL =
        //"https://dai.fmph.uniba.sk/courses/VMA/ISLAND.JPG"
        "https://dai.fmph.uniba.sk/courses/VMA/ISLAND2.JPG"
        //"https://dai.fmph.uniba.sk/courses/VMA/NikonRaw.NEF"
        //"https://dai.fmph.uniba.sk/courses/VMA/Quebec.tif"
        //    "https://dai.fmph.uniba.sk/courses/VMA/logo.jpg"
        //"https://dai.fmph.uniba.sk/courses/VMA/goco.png"
    // private val IMAGE_URL = "http://dai.fmph.uniba.sk/courses/VMA/android/03Http/KOZA.JPG"   // login/pass
    //private val IMAGE_URL =
    //private val IMAGE_URL =
    //private val IMAGE_URL = "http://dai.fmph.uniba.sk/courses/VMA/goco1.png"


    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater) // view binding
        setContentView(binding.root)
        binding.progressBar.visibility = View.VISIBLE
        val coroutineScope = CoroutineScope(Dispatchers.Main)
        coroutineScope.launch {
            val originalImage = /*coroutineScope.*/async(Dispatchers.IO) {
                // download image from URL
                val options = BitmapFactory.Options().apply {
                    //inJustDecodeBounds = true
                    inSampleSize =1
                }

                URL(IMAGE_URL).openStream().use {
                    BitmapFactory.decodeStream(it, null, options)
                }
//                BitmapFactory.decodeStream(URL(IMAGE_URL).openStream(), null, options);
            }
            val originalBitmap = originalImage.await()
            if (originalBitmap != null) {
                binding.apply {
                    imageView.setImageBitmap(originalBitmap)
                    val filteredImage = /*coroutineScope.*/async(Dispatchers.Default) {
                        toBlackAndWhite(originalBitmap)
                    }
                    val filteredBitmap = filteredImage.await()
                    progressBar.visibility = View.GONE
                    imageView.setImageBitmap(filteredBitmap)
                    imageView.visibility = View.VISIBLE
                }
            } else {
                Toast.makeText(this@MainActivity, "loaded image is null", Toast.LENGTH_LONG).show()
            }
        }
    }
    fun toBlackAndWhite(source: Bitmap): Bitmap {
        val w = source.width
        val h = source.height
        val bitmapArray = IntArray(w*h)
        source.getPixels(bitmapArray, 0, w, 0, 0, w, h) // array from source
        (0 until h).forEach { y->
            (0 until w).forEach { x->
                val index = x+y*w  // index in 2D-matrix
                val R = Color.red(bitmapArray[index])
                val G = Color.green(bitmapArray[index])
                val B = Color.blue(bitmapArray[index])
                val grey = (R + G + B)/3
                bitmapArray[index] = Color.rgb(grey, grey, grey)
            }
        }
        val bitmapOut = Bitmap.createBitmap(w, h, Bitmap.Config.RGB_565)
        bitmapOut.setPixels(bitmapArray, 0, w, 0, 0, w, h) // create output bitmap
        return bitmapOut
    }
}