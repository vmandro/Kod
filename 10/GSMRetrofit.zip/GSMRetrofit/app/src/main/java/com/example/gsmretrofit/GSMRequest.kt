package com.example.gsmretrofit

data class GSMRequest(
    val address: Int,
    val cells: List<Cell>,
    val mcc: Int,
    val mnc: Int,
    val token: String
)