package com.example.gsmretrofit

import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.Headers
import retrofit2.http.POST
interface RestApiInterface {
    @Headers("Content-Type: application/json")
    @POST("process.php")
    fun gsm2latlong(@Body gsmRequest: GSMRequest): Call<GSMResponse>
}