package com.example.gsmretrofit

import android.util.Log
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object ServiceBuilder {
    private val client = OkHttpClient.Builder().build()

    suspend fun get(): RestApiInterface  {
        Log.d("GSM", "ServiceBuilder.get()")
        return Retrofit.Builder()
        .baseUrl("https://eu1.unwiredlabs.com/v2/")
        .addConverterFactory(GsonConverterFactory.create())
        .client(client)
        .build()
        .create(RestApiInterface::class.java)
    }
}