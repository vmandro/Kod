package com.example.gsmretrofit
import com.google.gson.annotations.SerializedName

data class GSMResponse(
    val accuracy: Int,
    val address: String,
    val balance: Int,
    val lat: Double,
    val lon: Double,
    val status: String
)