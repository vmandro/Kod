package com.example.coroutineretrofit2.viewmodel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.coroutineretrofit2.model.Stat
import com.example.coroutineretrofit2.model.StatService
import kotlinx.coroutines.*

class ListViewModel: ViewModel() {
    private val service = StatService.get()
    lateinit var job: Job
    val staty = MutableLiveData<List<Stat>>()

    fun fetch() {
        job = CoroutineScope(Dispatchers.IO).launch {
            Log.d("MODEL", "fetch")
            val response = service.get()
            withContext(Dispatchers.Main) {
                if (response.isSuccessful) {
                    staty.value = response.body()
                    Log.d("MODEL", "staty.value.size: ${staty.value}")
                }else
                    Log.d("MODEL", "Error: ${response.message()}")
            }
        }
    }
    override fun onCleared() {
        super.onCleared()
        job.cancel()
    }
}