package com.example.coroutineretrofit2.view

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.coroutineretrofit2.*
import com.example.coroutineretrofit2.model.Stat
import com.example.coroutineretrofit2.view.ListAdapter.*
import com.example.coroutinesretrofit2.R

//import kotlinx.android.synthetic.main.item_country.view.*

class ListAdapter(var staty: ArrayList<Stat>):
    RecyclerView.Adapter<StatViewHolder>() {
    override fun onBindViewHolder(holder: StatViewHolder, position: Int) {
        holder.bind(staty[position])
    }

    fun updateCountries(newCountries: List<Stat>) {
        staty.clear()
        staty.addAll(newCountries)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int) = StatViewHolder(
        LayoutInflater.from(parent.context).inflate(R.layout.item_country, parent, false)
    )

    override fun getItemCount() = staty.size

    class StatViewHolder(view: View): RecyclerView.ViewHolder(view) {

        private val imageView = view.findViewById<ImageView>(R.id.imageView)
            //view.imageView
        private val stat = view.findViewById<TextView>(R.id.name)
            //view.name
        private val hlmesto = view.findViewById<TextView>(R.id.capital)
            //view.capital
        private val kod = view.findViewById<TextView>(R.id.code)
            //view.code
        private val hranice = view.findViewById<TextView>(R.id.borders)
            //view.borders

        fun bind(country: Stat) {
            stat.text = country.countryName
            hlmesto.text = country.capital
            kod.text = country.code
            hranice.text = country.borders?.joinToString(separator = ",")
            val options = RequestOptions().error(R.mipmap.ic_launcher_round)
            Glide.with(imageView)
                .setDefaultRequestOptions(options)
                .load(country.flag)
                .into(imageView)
        }
    }
}