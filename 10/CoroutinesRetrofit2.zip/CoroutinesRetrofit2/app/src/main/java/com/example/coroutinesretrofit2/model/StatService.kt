package com.example.coroutineretrofit2.model

import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import com.google.gson.annotations.SerializedName

interface StatInterface {
    @GET("vlajky/staty.json")
    suspend fun get(): Response<List<Stat>>
}
//-------------------------
object StatService {
    private val BASE_URL = "https://dai.fmph.uniba.sk/courses/VMA/"

    fun get(): StatInterface {
        return Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(StatInterface::class.java)
    }
}
//-------------------------
data class Stat(
    @SerializedName("name")       /* -> */  val countryName: String?,
    @SerializedName("capital")    /* -> */  val capital: String?,
    @SerializedName("flagPNG")    /* -> */  val flag: String?,
    @SerializedName("latlng")     /* -> */  val latlng: Array<Float>?,
    @SerializedName("borders")    /* -> */  val borders: List<String>?,
    @SerializedName("alpha3Code") /* -> */  val code: String?
)
/*
  {
    "alpha2Code": "SK",
    "alpha3Code": "SVK",
    "altSpellings": [
      "SK",
      "Slovak Republic",
      "Slovensk\u00e1 republika"
    ],
    "area": 49037,
    "borders": [
      "AUT",
      "CZE",
      "HUN",
      "POL",
      "UKR"
    ],
    "callingCodes": [
      "421"
    ],
    "capital": "Bratislava",
    "currencies": [
      {
        "code": "EUR",
        "name": "Euro",
        "symbol": "\u20ac"
      }
    ],
    "demonym": "Slovak",
        "flagPNG": "https://dai.fmph.uniba.sk/courses/VMA/vlajky/svk.png",
    "gini": 26.0,
    "languages": [
      {
        "iso639_1": "sk",
        "iso639_2": "slk",
        "name": "Slovak",
        "nativeName": "sloven\u010dina"
      }
    ],
    "latlng": [
      48.66666666,
      19.5
    ],
    "name": "Slovakia",
    "nativeName": "Slovensko",
    "numericCode": "703",
    "population": 5426252,
    "region": "Europe",
    "regionalBlocs": [
      {
        "acronym": "EU",
        "name": "European Union"
      }
    ],
    "subregion": "Eastern Europe",
    "timezones": [
      "UTC+01:00"
    ],
    "topLevelDomain": [
      ".sk"
    ],
    "translations": {
      "br": "Eslov\u00e1quia",
      "de": "Slowakei",
      "es": "Rep\u00fablica Eslovaca",
      "fa": "\u0627\u0633\u0644\u0648\u0627\u06a9\u06cc",
      "fr": "Slovaquie",
      "hr": "Slova\u010dka",
      "it": "Slovacchia",
      "ja": "\u30b9\u30ed\u30d0\u30ad\u30a2",
      "nl": "Slowakije",
      "pt": "Eslov\u00e1quia"
    },
    "cioc": "SVK"
  },
 */