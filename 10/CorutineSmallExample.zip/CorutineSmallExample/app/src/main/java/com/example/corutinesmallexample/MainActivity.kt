package com.example.corutinesmallexample

import androidx.appcompat.app.AppCompatActivity

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.SeekBar
import com.example.corutinesmallexample.databinding.ActivityMainBinding
//import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.coroutines.*
import kotlin.random.Random


class MainActivity : AppCompatActivity() {

    private var cCount: Int = 1
    private val TAG = "CORSMALL"
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.apply {
            seekBar.setOnSeekBarChangeListener(object :
                SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(
                    seek: SeekBar,
                    progress: Int, fromUser: Boolean
                ) {
                    cCount = progress
                    countText.text = "${cCount} coroutines"
                    beigns.text = ""
                    ends.text = ""
                }

                override fun onStartTrackingTouch(seek: SeekBar) {}
                override fun onStopTrackingTouch(seek: SeekBar) {}
            })
        }
    }

    fun launchCoroutines(view: View) {
        (1..cCount).forEach {
            Log.d(TAG, "$it")
            binding.beigns.append("<$it")
            //CoroutineScope(Dispatchers.Main).launch(Dispatchers.Main) {
            CoroutineScope(Dispatchers.Main).launch {
                val result: Deferred<String> = async { perform2(it) }
                binding.ends.append(result.await())


//                ends.append(perform3(it).await())


//                perform1(it)
//                ends.append("$it>")

            }
        }
    }
    suspend fun perform3(corIndex: Int): Deferred<String> =
        CoroutineScope(Dispatchers.Main).async {
            delay(Random.nextLong(5_000))
            return@async "$corIndex>"
        }

    suspend fun perform2(corIndex: Int): String {
        delay(Random.nextLong(5_000))
        return "$corIndex>"
    }

    suspend fun perform1(corIndex: Int) {
        delay(1_000)
        val x = CoroutineScope(Dispatchers.Main).async {
            val duration = Random.nextLong(2_000)
            delay(duration)
            duration
        }.await()
        Log.d(TAG, "$corIndex has duration $x")
        delay(Random.nextLong(3_000))
    }
}
