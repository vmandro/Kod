import kotlinx.coroutines.*
import java.util.concurrent.atomic.AtomicInteger
import kotlin.system.measureTimeMillis

fun main() {
    runBlocking {
        var state = 0
        val stateContext = newSingleThreadContext("stateContext")
        withContext(Dispatchers.Default) {
        //withContext(stateContext) {
            val time = measureTimeMillis {
                coroutineScope {
                    (1..1000).forEach {
                        launch {
                            (1..1000).forEach {
                                // switch context
                                withContext(stateContext) {
                                    state++
                                }
                            }
                        }
                    }
                }
            }
            println("elasped time: $time ms")
        }
        println("State = $state")
    }
}
