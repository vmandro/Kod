import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.channels.ReceiveChannel
import kotlinx.coroutines.channels.produce
import kotlinx.coroutines.runBlocking

fun main() {
    runBlocking {
        val numbers = naturals(1)
        val squares = square(numbers)
        while (true) {
            val rec = squares.receive()
            if (rec > 1000000)
                break
            println(rec)
        }
        coroutineContext.cancelChildren()
    }
}

fun CoroutineScope.naturals(start : Int) = produce {
    var n = start
    while (true)
        send(n++)
}

fun CoroutineScope.square(numbers: ReceiveChannel<Int>) = produce {
    for (x in numbers)
        send(x * x)
}