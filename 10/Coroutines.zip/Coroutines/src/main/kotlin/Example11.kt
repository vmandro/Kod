import kotlinx.coroutines.*
import java.time.LocalDateTime


fun main() {
    println("${LocalDateTime.now()} Start")
    runBlocking {		  // Start a coroutine, blocking
        launch {  // Start a coroutine, non-blocking
            delay(1000)  	  // wait 1s.
            println("${LocalDateTime.now()} Hello")
            launch {
                // Start a coroutine, non-blocking
                delay(2000)      // wait 1s.
                println("${LocalDateTime.now()} World")
            }
        }
        Thread.sleep(3000) 	  // wait for 3s.
        println("${LocalDateTime.now()} Stop")
    }
    println("${LocalDateTime.now()} Finish")
}