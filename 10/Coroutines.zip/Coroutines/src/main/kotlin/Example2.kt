import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import java.time.LocalDateTime

fun main() {
    println("${LocalDateTime.now()} Start")
    runBlocking {		  // Start a coroutine, blocking
        printHello()
    }
    println("${LocalDateTime.now()} Finish")
}
suspend fun printHello() {
    delay(1000L)
    println("${LocalDateTime.now()} Hello")
}
