import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.runBlocking

fun main() {
    runBlocking {
        println("pred")
        aritmeticka(1,3)
            .take(5)
            .takeWhile {it < 10}
            .collect {
            println(it)
        }
        println("po")
    }
}

fun aritmeticka(a : Int, delta : Int): Flow<Int> = flow {
//    (0..9).forEach {
//        delay(it * 100L)
//        emit(a + it*delta)
//    }

    var x = a
    while (true) {
        delay(x * 100L)
        emit(x)
        x += delta
    }

}