import java.time.LocalDateTime
import java.util.stream.Collectors
import java.util.stream.Stream

fun main() {
    println(Runtime.getRuntime().availableProcessors() )
    println("${LocalDateTime.now()} Start")
    val newList = listOf(1,2,3,4,5,6,7,8,9,10).parallelStream().map {
        Thread.sleep(1000)
        it*it		// return it * it
    }.collect(Collectors.toList())
    println("${LocalDateTime.now()} End")
    newList.forEach { // výpis kolekcie
        println("${LocalDateTime.now()} $it")
    }
}
