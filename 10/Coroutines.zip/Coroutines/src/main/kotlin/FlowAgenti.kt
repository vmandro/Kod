import kotlinx.coroutines.flow.*
import kotlinx.coroutines.runBlocking

fun generator(i : Int) = flow {
    var n = i
    while (true) {
        emit(n++)
    }
}

fun multiply(k : Int, flow: Flow<Int>) = flow<Int> {
    flow.collect {
        emit(it * k)
    }
}

fun mapper(f : (Int)->Int, flow: Flow<Int>) = flow<Int> {
    flow.collect {
        emit(f(it))
    }
}

fun filter(p : (Int)->Boolean, flow: Flow<Int>) = flow<Int> {
    flow.collect {
        if (p(it))
            emit(it)
    }
}
fun sieve(flow: Flow<Int>) = flow<Int> {
    var f = flow
    while(true) {
        val p: Int = f.first(predicate = {true})
        emit(p)
        val newf = flow {
            f.collect {
                if (it % p > 0)
                    emit(it)
            }
        }
        f = newf
    }
}
//fun eratosten(flow : Flow<Int>) : Flow<Int> {
//    var f = flow
//    while (true)
//        f = sieve(f)
//}

fun main() {
    runBlocking {
        //val f = multiply(2, generator(1))
        //val f = mapper({x -> x*2}, generator(1))
        //val f = filter({it%10 == 0}, mapper({it*2},generator(1)))
        //val f = sieve(sieve(sieve(generator(2))))
        val f = sieve(generator(2))
        f.takeWhile { it < 1000 }.collect {
            println(it)
        }
    }
}
