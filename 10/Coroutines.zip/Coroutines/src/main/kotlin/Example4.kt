import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.time.LocalDateTime

fun main() {
    println("${LocalDateTime.now()} Start main")
    GlobalScope.launch {
        println("${LocalDateTime.now()} Start background")
        delay(1000L)
        println("${LocalDateTime.now()} Finish background")
    }
    println("${LocalDateTime.now()} Continue main")
    runBlocking {
        delay(2000L)
        println("${LocalDateTime.now()} Stop main")
    }
}