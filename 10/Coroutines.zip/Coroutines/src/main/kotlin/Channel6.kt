import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

fun main() {
    runBlocking {
        val channel = Channel<Int>(4)
        val sender = launch {
            (1..10).forEach{
                channel.send(it)
                println("sent $it")
                delay(100)
            }
        }
        repeat(10) {
            delay(1000)
            println("received ${channel.receive()}")
        }
        sender.cancel()
    }
}