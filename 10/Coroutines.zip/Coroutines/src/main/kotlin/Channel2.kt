import kotlinx.coroutines.channels.consumeEach
import kotlinx.coroutines.channels.produce
import kotlinx.coroutines.runBlocking

fun main() {
    runBlocking {
        val channel = produce {
            (1..10).forEach { send(it*it) }
        }
//        for(x in channel)
//            println(x)
        channel.consumeEach {
            println(it) }
    }
}
