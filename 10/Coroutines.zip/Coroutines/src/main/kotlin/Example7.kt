import kotlinx.coroutines.*
import java.time.LocalDateTime

fun main() {
    println("${LocalDateTime.now()} Start main")
    runBlocking {
        val status = withTimeoutOrNull(10000L) {
            repeat(30) { i ->
                println("${LocalDateTime.now()} Processing $i ...")
                delay(1000L)
            }
            "Finished"
        }
        println("${LocalDateTime.now()} The processing return status is: $status")
        }
}
