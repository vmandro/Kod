import kotlinx.coroutines.*
import java.time.LocalDateTime

fun main() {
    println("${LocalDateTime.now()} Start main")
    runBlocking {
        val result1 = async { computation1() }
        val result2 = async { computation2() }
        println("${LocalDateTime.now()} Awaiting computations...")
        val result = result1.await() + result2.await()
        println("${LocalDateTime.now()} The result is $result")
    }
    println("${LocalDateTime.now()} Stop main")
}
suspend fun computation1(): Int {
    delay(1000L) // simulated computation
    println("${LocalDateTime.now()} Computation1 finished")
    return 1
}
suspend fun computation2(): Int {
    delay(2000L)
    println("${LocalDateTime.now()} Computation2 finished")
    return 2
}
