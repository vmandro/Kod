import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.SendChannel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

fun main() {
    runBlocking {
        val channel = Channel<String>()
        launch { sendString(channel, 200L, "cor1") }
        launch { sendString(channel, 500L, "cor2") }
        launch { sendString(channel, 300L, "cor3") }
        repeat(70) {
            println(channel.receive())
        }
        coroutineContext.cancelChildren()
    }
}

suspend fun sendString(channel: SendChannel<String>, time: Long, name: String) {
    for (i in 1..30) {
        delay(time)
        channel.send("$name:$i")
    }
}