import kotlinx.coroutines.*
import java.util.concurrent.atomic.AtomicInteger
import kotlin.system.measureTimeMillis

fun main() {
    runBlocking {
        //var state = 0
        var state = AtomicInteger(0)
        withContext(Dispatchers.Default) {
            val time = measureTimeMillis {
                coroutineScope {
                    (1..1000).forEach {
                        launch {
                            (1..1000).forEach {
                                //state++
                                state.getAndIncrement()
                            }
                        }
                    }
                }
            }
            println("elasped time: $time ms")
        }
        println("State = $state")
    }
}
