import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.runBlocking

fun main() {
    runBlocking {
//       mapExample()
//       filterExample()
//       transformExample()
//       takeExample()
//       reduceExample()
//       flowOnExample()
//       zip()
       combine()
    }
}

suspend fun transformExample() {
    (1..10).asFlow()
        .transform {
            emit("string $it")
            emit(it)
        }
        .collect {
            println(it)
        }
}

suspend fun filterExample() {
    (1..10).asFlow()
        .filter {
            it % 2 == 0
        }
        .collect {
            println(it)
        }
}

suspend fun mapExample() {
    (1..10).asFlow()
        .map {
            delay(500L)
            "mapping $it"
        }
        .collect {
            println(it)
        }
}
suspend fun flowOnExample() {
    (1..10).asFlow()
        .flowOn(Dispatchers.IO)
        .collect {
            println(it)
        }
}

suspend fun reduceExample() {
    val size = 10
    val factorial = (1..size).asFlow()
        .reduce { accumulator, value ->
            accumulator * value
        }
    println("$size != $factorial")
}

suspend fun takeExample() {
    (1..10).asFlow()
        .take(2)
        .collect {
            println(it)
        }
}

suspend fun combine() {
    val numbers = (1..5).asFlow().onEach { delay(300L) }
    val values = flowOf("One", "Two", "Three", "Four", "Five")
        .onEach { delay(400L) }
    numbers.combine(values) { a, b ->
        "$a -> $b"
    }.collect { println(it) }
}

suspend fun zip() {
    val english = flowOf("One", "Two", "Three")
    val french = flowOf("Un", "Deux", "Troix")
    english.zip(french) { a, b -> "'$a' in French is '$b'" }
        .collect {
            println(it)
        }
}