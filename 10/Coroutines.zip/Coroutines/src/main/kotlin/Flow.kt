import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.time.LocalDateTime

fun main() {
    val numbers : Flow<Int> = flow {
        listOf(1,2,3,4,5,6,7,8,9,10).forEach{
            emit(it)
            delay(it*100L)
        }
    }  // flow zanika
    runBlocking {
        numbers.collect {
            println("${LocalDateTime.now()} $it")
        }
    }
}