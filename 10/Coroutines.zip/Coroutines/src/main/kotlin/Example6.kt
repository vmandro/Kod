import kotlinx.coroutines.*
import java.time.LocalDateTime

fun main() {
    println("${LocalDateTime.now()} Start main")
    runBlocking {
        val job = launch { // Emulate some batch processing
            repeat(30) { i ->
                println("${LocalDateTime.now()} Processing $i ...")
                delay(1000L)
            }
        }
        delay(10000L)
        println("${LocalDateTime.now()} main: The user requests the cancellation")
        job.cancelAndJoin()
            // cancel the job and wait for it's completion
        println("${LocalDateTime.now()} main: The batch is cancelled")
    }
}
