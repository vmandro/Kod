import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.asFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeoutOrNull

fun main() {
    runBlocking {
        val flow = geometricka(1,2)
        println("pred")
        withTimeoutOrNull(1000L) {
            flow.collect { println(it) }
        }
        println("po")
    }
}

fun geometricka(a : Int, q : Int) = flow {
    var x = 1
    (0..9).forEach {
        delay(400L)
        emit(a*x)
        x *= q
    }
}
