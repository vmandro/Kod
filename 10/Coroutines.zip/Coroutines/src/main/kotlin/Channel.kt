import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

fun main() {
    val channel = Channel<Int>()
    runBlocking{
        launch {
            for (x in channel) {
                println("a:$x")
            }
        }
        launch {
            for (x in channel) {
                println("b:$x")
            }
        }
        listOf(1,2,3,4,5,6,7,8,9,10).forEach{
            println(" :$it")
            channel.send(it)
        }
}


fun main1() {
    val channel = Channel<Int>()
    GlobalScope.launch {
        for (x in channel) {
            println("a:$x")
        }
    }
    GlobalScope.launch {
        for (x in channel) {
            println("b:$x")
        }
    }
    runBlocking {
        listOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 10).forEach {
            println(" :$it")
            channel.send(it)
        }
        delay(1000)
    }
}
}


