import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.atomic.AtomicInteger
import kotlin.system.measureTimeMillis

fun main() {
    runBlocking {
        var state = 0
        val mutex = Mutex()
        withContext(Dispatchers.Default) {
            val time = measureTimeMillis {
                coroutineScope {
                    (1..1000).forEach {
                        launch {
                            (1..1000).forEach {
                                mutex.withLock {
                                    state++
                                }
                            }
                        }
                    }
                }
            }
            println("elasped time: $time ms")
        }
        println("State = $state")
    }
}
