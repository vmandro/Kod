import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.channels.ReceiveChannel
import kotlinx.coroutines.channels.produce
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

fun main() {
    runBlocking {
        val producer = produce {
            var n = 1
            while (true) {
                send(n++)
                delay(100)
            }
        }
        for(consumer in 1..5) {
            launch {
                for (message in producer)
                    println("$consumer <- $message")
            }

        }
        delay(1500L)
        producer.cancel()
    }
}
