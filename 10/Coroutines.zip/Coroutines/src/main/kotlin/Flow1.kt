import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.runBlocking

fun main() {
    runBlocking {
        postupnost().collect {
            println("$it")
        }
    }
}

fun postupnost()
        = flowOf("Jeden", "Dva", "Tri", "Styri")

//        = listOf(1, 2, 3).asFlow()

//        = flow {
//    for (i in 1..10)
//        emit(i)
//}