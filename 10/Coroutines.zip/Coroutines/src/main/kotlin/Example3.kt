import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDateTime

fun main() {
    println("${LocalDateTime.now()} Start")
    GlobalScope.launch {// launch in the background
        "world!".forEach {
            delay(200)
            println("${LocalDateTime.now()} $it")
        }
    }
    println("${LocalDateTime.now()} Hello,")
    Thread.sleep(2000)
    println("${LocalDateTime.now()} Stop")
}