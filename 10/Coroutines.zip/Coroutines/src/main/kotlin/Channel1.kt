import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

fun main() {
    val channel = Channel<Int>()
    runBlocking {
        launch {
            for (x in 1..10)
                channel.send(x * x)
            channel.close()
        }
//        for(i in 1..5)
//            println(channel.receive())
//      alebo
        for (i in channel)
            println(i)
    }
}