import java.time.LocalDateTime
import java.util.stream.Collectors
import java.util.stream.Stream

fun main() {
    println("${LocalDateTime.now()} Start")
    val newList = Stream.of(1,2,3,4,5,6,7,8,9,10)
        .map {
            Thread.sleep(1000)
            it*it		// return it * it
        }.collect(Collectors.toList())
    println("${LocalDateTime.now()} End")
    newList.forEach { // výpis kolekcie
        println("${LocalDateTime.now()} $it")
    }
}
