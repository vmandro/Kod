import java.time.LocalDateTime
import java.util.stream.Stream

fun main() {
    println("${LocalDateTime.now()} Start")
    val list = listOf<Int>(1,2,3,4,5,6,7,8,9,10)
    val newList = //list.stream()
        Stream.of(1,2,3,4,5,6,7,8,9,10)
        .map {
            Thread.sleep(1000)
            it*it		// return it * it
        }
    println("${LocalDateTime.now()} End")
    newList.forEach { // výpis kolekcie
        println("${LocalDateTime.now()} $it")
    }
}
