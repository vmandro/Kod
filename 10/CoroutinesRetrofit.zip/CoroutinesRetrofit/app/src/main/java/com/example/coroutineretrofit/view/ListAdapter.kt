package com.example.coroutineretrofit.view

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.coroutineretrofit.*
import com.example.coroutineretrofit.model.Stat
import com.example.coroutineretrofit.view.ListAdapter.*
import kotlinx.android.synthetic.main.item_country.view.*

class ListAdapter(var staty: ArrayList<Stat>):
    RecyclerView.Adapter<StatViewHolder>() {
    override fun onBindViewHolder(holder: StatViewHolder, position: Int) {
        holder.bind(staty[position])
    }

    fun updateCountries(newCountries: List<Stat>) {
        staty.clear()
        staty.addAll(newCountries)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int) = StatViewHolder(
        LayoutInflater.from(parent.context).inflate(R.layout.item_country, parent, false)
    )

    override fun getItemCount() = staty.size

    class StatViewHolder(view: View): RecyclerView.ViewHolder(view) {
        private val imageView = view.imageView
        private val stat = view.name
        private val hlmesto = view.capital
        private val kod = view.code
        private val hranice = view.borders

        fun bind(country: Stat) {
            stat.text = country.countryName
            hlmesto.text = country.capital
            kod.text = country.code
            hranice.text = country.borders?.joinToString(separator = ",")
            val options = RequestOptions().error(R.mipmap.ic_launcher_round)
            Glide.with(imageView)
                .setDefaultRequestOptions(options)
                .load(country.flag)
                .into(imageView)
        }
    }
}