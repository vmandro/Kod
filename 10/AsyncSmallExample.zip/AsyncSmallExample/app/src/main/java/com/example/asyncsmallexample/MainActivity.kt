package com.example.asyncsmallexample

import android.graphics.Color
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.asyncsmallexample.databinding.ActivityMainBinding
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var binding : ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
    var numberOfAsyncTasks = 0
    fun buttonClick(view: View) {
//        var i = 0
//        while (i <= 20) {
//            try {
//                Thread.sleep(1000)
//                i++
//            }
//            catch (e: Exception) {
//                e.printStackTrace()
//            }
//        }

       val task1 = MyTask().execute()  // serial run of AsyncTask
//
//        val task = MyTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)

        val cpu_cores = Runtime.getRuntime().availableProcessors()
    }

    private inner class MyTask : AsyncTask<String, Int, String>() {
        var color : Int = Color.BLACK
        var index = 0
        override fun onPreExecute() {
            val R = 128+Random().nextInt(128)
            val G = 128+Random().nextInt(128)
            val B = 128+Random().nextInt(128)
            val A = 255//128+Random().nextInt(128)
            color = (A shl 24) or (R shl 16) or (G shl 8) or B
            index = ++numberOfAsyncTasks
        }

        override fun doInBackground(vararg params: String): String {
            for (i in 0..10) {
                try {
                    Thread.sleep(1000)
                    publishProgress(i)
                }
                catch (e: Exception) {
                    return(e.localizedMessage)
                }
            }
            return "Button Pressed"
        }

        override fun onProgressUpdate(vararg values: Int?) {
            super.onProgressUpdate(*values)
            val counter = values.get(0)
            binding.myTextView.setTextColor(color)
            binding.myTextView.text = "$index.Counter = $counter"
        }

        override fun onPostExecute(result: String) {
            binding.myTextView.setTextColor(color)
            binding.myTextView.text = result
        }
    }
}