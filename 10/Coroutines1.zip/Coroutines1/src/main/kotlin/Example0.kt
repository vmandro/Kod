import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.time.LocalDateTime

fun main() {
    println("${LocalDateTime.now()} Start")
    GlobalScope.launch {  // Start a coroutine, non-blocking
        delay(1000)  	  // wait 1s.
        println("${LocalDateTime.now()} Hello")
    }
    Thread.sleep(3000) 	  // wait for 3s.
    println("${LocalDateTime.now()} Stop")
    runBlocking {		  // Start a coroutine, blocking
        delay(4000L)
    }
    println("${LocalDateTime.now()} Finish")
}