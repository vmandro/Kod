package com.example.coroutinesmallexample2

import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.inputmethod.InputBinding
import androidx.activity.ActivityFlags
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.coroutinesmallexample2.databinding.ActivityMainBinding
import kotlinx.coroutines.delay
import kotlinx.coroutines.*
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.Dispatchers.Main
import java.util.concurrent.atomic.AtomicLong
import java.util.stream.Collectors
import kotlin.coroutines.CoroutineContext

class MainActivity : AppCompatActivity(),  CoroutineScope {
    val TAG = "COROUTINES"
    private val job = //SupervisorJob()
        Job()
    override val coroutineContext: CoroutineContext
        get() = Dispatchers.Main + job

    override fun onDestroy() {
        super.onDestroy()
        coroutineContext.cancelChildren()
    }
    private val scopeMainThread = CoroutineScope(job + Dispatchers.Main)
    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_main)
        enableEdgeToEdge()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val myTextView = binding.myTextView


        runBlocking {
            launch {
                // context of the parent, main runBlocking coroutine
                Log.d(
                    TAG,
                    "main runBlocking      : I'm working in thread ${Thread.currentThread().name}"
                )
            }
            launch(Dispatchers.Unconfined) {
                // not confined -- will work with main thread
                Log.d(
                    TAG,
                    "Unconfined            : I'm working in thread ${Thread.currentThread().name}"
                )
            }
            launch(Dispatchers.Default) {
                // will get dispatched to DefaultDispatcher
                Log.d(
                    TAG,
                    "Default               : I'm working in thread ${Thread.currentThread().name}"
                )
            }
            launch(newSingleThreadContext("MyOwnThread")) {
                // will get its own new thread
                Log.d(
                    TAG,
                    "newSingleThreadContext: I'm working in thread ${Thread.currentThread().name}"
                )
            }
        }
        //GlobalScope.
        launch (Dispatchers.Default) {
            myTextView.text = "GUI from coroutine"
        }

        val c = AtomicLong()
        Log.d(TAG, "1000 threads start")
        for (i in 1..1_000L) {   // 1_000_000L
//            thread(start = true) {
//                c.addAndGet(i)
//            }
            //c.addAndGet(async { workload(i)}.await())

//            async {
//                c.addAndGet(workload(i))
//            }
        }
        Log.d(TAG, "1000 threads finish ${c.get()}")

        /*
                CoroutineScope(Main).launch {
                    delay(2000L)
                    //val status = withTimeoutOrNull(10000L) {
                        repeat(30) { i ->
                            Log.d(TAG, "Processing $i ...")
                            withContext(Main) {
                                myTextView.text = "Processing $i ..."
                            }
                            delay(1000L)
                        }
                      // "Finished"
                    //}
                    //Log.d(TAG, "The processing return status is: $status")
                }
        */

    }
    fun buttonClick0(view : View) {
        Log.d(TAG, "#${Runtime.getRuntime().availableProcessors()}")
        Log.d(TAG, "Start")
        val list = listOf<Int>(1,2,3,4,5,6,7,8,9,10)
        //val newList = list.stream().map { it*it }
        val newList = list.parallelStream().map {
            Thread.sleep(1000)
            it*it
        }.collect(Collectors.toList())
        Log.d(TAG, "End")
        newList.forEach { Log.d(TAG, it.toString()) }
    }
//    2019-11-26 08:59:32.832 21304-21304/com.example.coroutinesmallexample D/COROUTINES: Start
//    2019-11-26 08:59:32.834 21304-21304/com.example.coroutinesmallexample D/COROUTINES: End
//    2019-11-26 08:59:33.839 21304-21304/com.example.coroutinesmallexample D/COROUTINES: 1
//    2019-11-26 08:59:34.841 21304-21304/com.example.coroutinesmallexample D/COROUTINES: 4
//    2019-11-26 08:59:35.842 21304-21304/com.example.coroutinesmallexample D/COROUTINES: 9
//    2019-11-26 08:59:36.844 21304-21304/com.example.coroutinesmallexample D/COROUTINES: 16
//    2019-11-26 08:59:37.846 21304-21304/com.example.coroutinesmallexample D/COROUTINES: 25
//    2019-11-26 08:59:38.849 21304-21304/com.example.coroutinesmallexample D/COROUTINES: 36
//    2019-11-26 08:59:39.851 21304-21304/com.example.coroutinesmallexample D/COROUTINES: 49
//    2019-11-26 08:59:40.854 21304-21304/com.example.coroutinesmallexample D/COROUTINES: 64
//    2019-11-26 08:59:41.856 21304-21304/com.example.coroutinesmallexample D/COROUTINES: 81
//    2019-11-26 08:59:42.858 21304-21304/com.example.coroutinesmallexample D/COROUTINES: 100

    // .collectors(toList())
//    2019-11-26 09:02:23.363 21473-21473/com.example.coroutinesmallexample D/COROUTINES: Start
//    2019-11-26 09:02:33.389 21473-21473/com.example.coroutinesmallexample D/COROUTINES: End
//    2019-11-26 09:02:33.389 21473-21473/com.example.coroutinesmallexample D/COROUTINES: 1
//    2019-11-26 09:02:33.389 21473-21473/com.example.coroutinesmallexample D/COROUTINES: 4
//    2019-11-26 09:02:33.389 21473-21473/com.example.coroutinesmallexample D/COROUTINES: 9
//    2019-11-26 09:02:33.389 21473-21473/com.example.coroutinesmallexample D/COROUTINES: 16
//    2019-11-26 09:02:33.389 21473-21473/com.example.coroutinesmallexample D/COROUTINES: 25
//    2019-11-26 09:02:33.389 21473-21473/com.example.coroutinesmallexample D/COROUTINES: 36
//    2019-11-26 09:02:33.390 21473-21473/com.example.coroutinesmallexample D/COROUTINES: 49
//    2019-11-26 09:02:33.390 21473-21473/com.example.coroutinesmallexample D/COROUTINES: 64
//    2019-11-26 09:02:33.390 21473-21473/com.example.coroutinesmallexample D/COROUTINES: 81
//    2019-11-26 09:02:33.390 21473-21473/com.example.coroutinesmallexample D/COROUTINES: 100

    // parallelStream
//    2019-11-26 09:04:06.410 21611-21611/com.example.coroutinesmallexample D/COROUTINES: Start
//    2019-11-26 09:04:09.420 21611-21611/com.example.coroutinesmallexample D/COROUTINES: End
//    2019-11-26 09:04:09.420 21611-21611/com.example.coroutinesmallexample D/COROUTINES: 1
//    2019-11-26 09:04:09.420 21611-21611/com.example.coroutinesmallexample D/COROUTINES: 4
//    2019-11-26 09:04:09.420 21611-21611/com.example.coroutinesmallexample D/COROUTINES: 9
//    2019-11-26 09:04:09.420 21611-21611/com.example.coroutinesmallexample D/COROUTINES: 16
//    2019-11-26 09:04:09.420 21611-21611/com.example.coroutinesmallexample D/COROUTINES: 25
//    2019-11-26 09:04:09.420 21611-21611/com.example.coroutinesmallexample D/COROUTINES: 36
//    2019-11-26 09:04:09.421 21611-21611/com.example.coroutinesmallexample D/COROUTINES: 49
//    2019-11-26 09:04:09.421 21611-21611/com.example.coroutinesmallexample D/COROUTINES: 64
//    2019-11-26 09:04:09.421 21611-21611/com.example.coroutinesmallexample D/COROUTINES: 81
//    2019-11-26 09:04:09.422 21611-21611/com.example.coroutinesmallexample D/COROUTINES: 100
    // https://simply-how.com/kotlin-coroutines-by-example-guide
    fun buttonClick1(view : View) {
        Log.d(TAG, "Start")
        GlobalScope.
        launch {  // Start a coroutine
            delay(1000)  // wait 1s.
            Log.d(TAG, "Hello")
        }
        Thread.sleep(3000) // wait for 3s.
        Log.d(TAG, "Stop")
        runBlocking {
            delay(4000L)
        }
        Log.d(TAG, "Finish")
    }
    //-----------------------------------------
    fun buttonClick2(view : View) {
        Log.d(TAG, "Start")
        runBlocking {
            printHello()
        }
        Log.d(TAG, "Finish")
    }
    suspend fun printHello() {
        delay(1000L)
        Log.d(TAG,"Hello")
    }
    //-------------------------------------
    fun buttonClick3(view : View) {
        Log.d(TAG,"The main program is started")
        GlobalScope.
        launch {
            Log.d(TAG,"Background processing started")
            delay(1000L)
            Log.d(TAG,"Background processing finished")
        }
        Log.d(TAG,"The main program continues")
        runBlocking {
            delay(2000L)
            Log.d(TAG,"The main program is finished")
        }
    }
    //-----------------------------
    fun buttonClick4(view : View) {
        runBlocking {
            val result1 = async { computation1() }
            val result2 = async { computation2() }
            Log.d(TAG, "Awaiting computations...")
            val result = result1.await() + result2.await()
            Log.d(TAG, "The result is $result")
        }
    }
    suspend fun computation1(): Int {
        delay(1000L) // simulated computation
        Log.d(TAG,"Computation1 finished")
        return 1
    }

    suspend fun computation2(): Int {
        delay(2000L)
        Log.d(TAG,"Computation2 finished")
        return 2
    }
    //-----------------------
    fun buttonClick5(view : View) {
        runBlocking {
            val job = launch {
                // Emulate some batch processing
                repeat(30) { i ->
                    Log.d(TAG, "Processing $i ...")
                    delay(1000L)
                }
            }
            delay(10000L)
            Log.d(TAG, "main: The user requests the cancellation of the processing")
            job.cancelAndJoin() // cancel the job and wait for it's completion
            Log.d(TAG, "main: The batch processing is cancelled")
        }
    }
    //-----------------------------
    fun buttonClick6(view : View) {
        runBlocking {
            val status = withTimeoutOrNull(10000L) {
                repeat(30) { i ->
                    Log.d(TAG, "Processing $i ...")
                    delay(1000L)
                }
                "Finished"
            }
            Log.d(TAG, "The processing return status is: $status")
        }
    }
    //-----------------------------
    fun buttonClick7(view : View) {
        GlobalScope.
        launch {
            val status = withTimeoutOrNull(10000L) {
                repeat(30) { i ->
                    Log.d(TAG, "Processing $i ...")
                    GlobalScope.launch(Dispatchers.Main) {
                        //scopeMainThread.launch {
                        //withContext(Dispatchers.Unconfined) {
                        binding.myTextView.text = "Processing $i ..."
                    }
                    delay(1000L)
                }
                "Finished"
            }
            Log.d(TAG, "The processing return status is: $status")
        }
    }
//    11-24 16:50:14.751 17130-17130/com.example.coroutinesmallexample D/COROUTINES: Start
//    11-24 16:50:15.799 17130-17185/com.example.coroutinesmallexample D/COROUTINES: Hello
//    11-24 16:50:16.794 17130-17130/com.example.coroutinesmallexample D/COROUTINES: Stop

    // ak odstranite Thread.sleep(2000)
//    11-24 16:52:12.860 17308-17308/com.example.coroutinesmallexample D/COROUTINES: Start
//    11-24 16:52:12.911 17308-17308/com.example.coroutinesmallexample D/COROUTINES: Stop
//    11-24 16:52:13.923 17308-17357/com.example.coroutinesmallexample D/COROUTINES: Hello

    // s runBlocking
//    11-24 16:54:33.541 17769-17769/com.example.coroutinesmallexample D/COROUTINES: Start
//    11-24 16:54:34.616 17769-17815/com.example.coroutinesmallexample D/COROUTINES: Hello
//    11-24 16:54:35.604 17769-17769/com.example.coroutinesmallexample D/COROUTINES: Stop

    fun buttonClick99(view : View) {
        val c = AtomicLong()
        Log.d(TAG, "million threads start")
        for (i in 1..1_000L) {
            //    for (i in 1..1_000_000L)
//            thread(start = true) {
//                c.addAndGet(1)
//            }

//            GlobalScope.launch {
//                c.addAndGet(1)
//            }
            Log.d(TAG, "${i}")
            GlobalScope.async {
                c.addAndGet(workload(i))
            }
        }
        Log.d(TAG, "million threads finish ${c.get()}")


// threads:
//        11-24 16:58:42.381 17938-17938/com.example.coroutinesmallexample D/COROUTINES: million threads start
//        11-24 16:58:42.652 17938-17947/com.example.coroutinesmallexample I/System: FinalizerDaemon: finalize objects = 1
//        11-24 16:58:52.674 17938-17947/com.example.coroutinesmallexample I/System: FinalizerDaemon: finalize objects = 101
//        11-24 16:59:00.081 17938-17949/com.example.coroutinesmallexample I/art: Background sticky concurrent mark sweep GC freed 10963(428KB) AllocSpace objects, 0(0B) LOS objects, 39% free, 4MB/8MB, paused 6.751ms total 37.744ms
//        11-24 17:08:53.839 17938-17949/com.example.coroutinesmallexample I/art: Background partial concurrent mark sweep GC freed 10620(414KB) AllocSpace objects, 0(0B) LOS objects, 39% free, 4MB/8MB, paused 9.267ms total 41.089ms
//        11-24 17:09:02.563 17938-17947/com.example.coroutinesmallexample I/System: FinalizerDaemon: finalize objects = 14
//        11-24 17:09:05.508 17938-17938/com.example.coroutinesmallexample D/COROUTINES: million threads finish 499998500001
//        11-24 17:09:05.509 17938-17938/com.example.coroutinesmallexample I/Choreographer: Skipped 34371 frames!  The application may be doing too much work on its main thread.

        // coroutines
//        11-24 17:16:40.311 22617-22617/com.example.coroutinesmallexample D/COROUTINES: million threads start
//        11-24 17:16:40.568 22617-22626/com.example.coroutinesmallexample I/System: FinalizerDaemon: finalize objects = 1
//        11-24 17:16:50.790 22617-22626/com.example.coroutinesmallexample I/System: FinalizerDaemon: finalize objects = 114
//        11-24 17:16:59.037 22617-22617/com.example.coroutinesmallexample D/COROUTINES: million threads finish 500000500000


    }


    suspend fun workload(n : Long) : Long {
        delay(1000)
        return n
    }
}
