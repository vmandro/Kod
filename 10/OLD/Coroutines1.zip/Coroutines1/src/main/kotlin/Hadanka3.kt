import java.time.LocalDateTime
import java.util.stream.Collectors

fun main() {
    println("${LocalDateTime.now()} Start")
    val list = listOf<Int>(1,2,3,4,5,6,7,8,9,10)
    val newList = list.parallelStream().map {
        Thread.sleep(1000)
        it*it		// return it * it
    }.collect(Collectors.toList())
    println("${LocalDateTime.now()} End")
    newList.forEach { // výpis kolekcie
        println("${LocalDateTime.now()} End")
    }
}
