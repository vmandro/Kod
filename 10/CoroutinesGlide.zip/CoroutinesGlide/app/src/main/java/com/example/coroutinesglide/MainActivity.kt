package com.example.coroutinesglide

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.Drawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.core.graphics.set
import kotlinx.coroutines.*
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.*
import com.example.coroutinesglide.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {

    //private val IMAGE_URL =
    private val IMAGE_URL =
    //    "https://dai.fmph.uniba.sk/courses/VMA/ISLAND.JPG"
    "https://dai.fmph.uniba.sk/courses/VMA/ISLAND2.JPG"
    //"https://dai.fmph.uniba.sk/courses/VMA/NikonRaw.NEF"
   // "https://dai.fmph.uniba.sk/courses/VMA/Quebec.tif"

    //private val IMAGE_URL = "https://dai.fmph.uniba.sk/courses/VMA/ISLAND2.JPG"
    // private val IMAGE_URL = "http://dai.fmph.uniba.sk/courses/VMA/android/03Http/KOZA.JPG"   // login/pass
    //private val IMAGE_URL = "http://dai.fmph.uniba.sk/courses/VMA/logo.jpg"
    //private val IMAGE_URL = "http://dai.fmph.uniba.sk/courses/VMA/goco.png"
    //private val IMAGE_URL = "http://dai.fmph.uniba.sk/courses/VMA/goco1.png"

//    http://dai.fmph.uniba.sk/courses/VMA/
//    http://dai.fmph.uniba.sk/courses/VMA/ISLAND.JPG
//    http://dai.fmph.uniba.sk/courses/VMA/ISLAND2.JPG
//    http://dai.fmph.uniba.sk/courses/VMA/android/03Http/KOZA.JPG
//    http://dai.fmph.uniba.sk/~borovan/rosnicka/
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding
            .inflate(layoutInflater)
        setContentView(binding.root)

// simple solution
//        Glide.with(this)
//            .load(IMAGE_URL)
//            .into(imageView)

        CoroutineScope(Dispatchers.Main).launch {
            Glide.with(this@MainActivity)
                .asBitmap()
                .error(R.mipmap.ic_launcher_round)
                .load(IMAGE_URL)
                .into(object : CustomTarget<Bitmap>() {
                    override fun onResourceReady(
                        resource: Bitmap,
                        transition: Transition<in Bitmap>?
                    ) {
                        binding.apply {
                            progressBar.visibility = View.GONE
                            imageViewOriginal.setImageBitmap(resource)
                            imageViewOriginal.visibility = View.VISIBLE
                            imageView.setImageBitmap(
                                //   toBlackAndWhite(resource)
                                pixelize(25, resource)
                            )
                            imageView.visibility = View.VISIBLE
                        }
                    }
                    override fun onLoadCleared(placeholder: Drawable?) { }
                })
        }
    }
    fun toBlackAndWhite(source: Bitmap): Bitmap {
        val w = source.width
        val h = source.height
        val bitmapArray = IntArray(w*h)
        source.getPixels(bitmapArray, 0, w, 0, 0, w, h) // array from source
        (0 until h).forEach { y->
            (0 until w).forEach { x->
                val index = x+y*w  // index in 2D-matrix
                val R = Color.red(bitmapArray[index])
                val G = Color.green(bitmapArray[index])
                val B = Color.blue(bitmapArray[index])
                val grey = (R + G + B)/3
                bitmapArray[index] = Color.rgb(grey, grey, grey)
            }
        }
        val bitmapOut = Bitmap.createBitmap(w, h, Bitmap.Config.RGB_565)
        bitmapOut.setPixels(bitmapArray, 0, w, 0, 0, w, h) // create output bitmap
        return bitmapOut
    }

    fun pixelize(pixelSize : Int, source: Bitmap): Bitmap {
        val w = source.width
        val h = source.height
        val bitmapOut = Bitmap.createBitmap(w, h, Bitmap.Config.RGB_565)
        (0 until h step pixelSize).forEach { y->
            (0 until w step pixelSize).forEach { x->
                val color = source.getColor(x, y).toArgb()
                (0 until pixelSize).forEach { dx->
                    (0 until pixelSize).forEach { dy ->
                        val xx = Math.max(0, x - dx)
                        val yy = Math.max(0, y - dy)
                        bitmapOut.setPixel(xx,yy, color)
                    }
                }
            }
        }
        return bitmapOut
    }

}